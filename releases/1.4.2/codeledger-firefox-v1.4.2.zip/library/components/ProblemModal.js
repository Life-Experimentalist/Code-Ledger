/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  h,
  useState,
  useEffect,
  useCallback,
} from "../../vendor/preact-bundle.js";
import { htm } from "../../vendor/preact-bundle.js";
const html = htm.bind(h);

import { Storage } from "../../core/storage.js";
import { createDebugger } from "../../lib/debug.js";
const dbg = createDebugger("ProblemModal");
import { cleanCode, highlightCode } from "../../lib/syntax-highlight.js";
import {
  getChatsByProblem,
  saveAIChat,
  updateAIChat,
} from "../../core/ai-chat-storage.js";
import { buildAIChatContext } from "../../lib/ai-chat-context.js";
import { AIReviewPanel } from "../../ui/components/AIReviewPanel.js";
import { MultiLineAIChatInput } from "../../ui/components/MultiLineAIChatInput.js";
import { AIMarkdownRenderer } from "../../ui/components/AIMarkdownRenderer.js";
import { ModelStatusBar } from "../../ui/components/ModelStatusBar.js";
import { modalTabRegistry } from "../../core/modal-tab-registry.js";
import { expandChatVariables } from "../../lib/chat-variables.js";
import { CONSTANTS } from "../../core/constants.js";
// Side-effect: registers LeetCode tabs into modalTabRegistry
import "../../handlers/platforms/leetcode/modal-tabs.js";

function renderMarkdown(md) {
  if (!md) return "";
  let html = String(md)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    // fenced code blocks
    .replace(
      /```[\w]*\n?([\s\S]*?)```/g,
      (_, code) =>
        `<pre class="my-3 p-3 bg-black/60 rounded-lg border border-white/10 overflow-x-auto text-xs font-mono text-slate-200 leading-relaxed">${code.trimEnd()}</pre>`,
    )
    // inline code
    .replace(
      /`([^`\n]+)`/g,
      '<code class="px-1 py-0.5 rounded bg-white/10 text-cyan-300 text-[0.85em] font-mono">$1</code>',
    )
    // bold
    .replace(
      /\*\*(.+?)\*\*/g,
      '<strong class="text-white font-semibold">$1</strong>',
    )
    // italic
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    // headings
    .replace(
      /^### (.+)$/gm,
      '<h3 class="text-sm font-bold text-white mt-4 mb-1">$1</h3>',
    )
    .replace(
      /^## (.+)$/gm,
      '<h2 class="text-sm font-bold text-slate-100 mt-4 mb-1 uppercase tracking-wide">$1</h2>',
    )
    .replace(
      /^# (.+)$/gm,
      '<h1 class="text-base font-bold text-white mt-4 mb-2">$1</h1>',
    )
    // unordered lists: accumulate items into <ul>
    .replace(/((?:^[*\-] .+\n?)+)/gm, (block) => {
      const items = block
        .trim()
        .split("\n")
        .map(
          (l) =>
            `<li class="ml-4 list-disc">${l.replace(/^[*\-] /, "").trim()}</li>`,
        )
        .join("");
      return `<ul class="my-2 space-y-0.5 text-slate-300">${items}</ul>`;
    })
    .replace(/((?:^\d+\. .+\n?)+)/gm, (block) => {
      const items = block
        .trim()
        .split("\n")
        .map(
          (l) =>
            `<li class="ml-4 list-decimal">${l.replace(/^\d+\. /, "").trim()}</li>`,
        )
        .join("");
      return `<ol class="my-2 space-y-0.5 text-slate-300">${items}</ol>`;
    })
    // horizontal rule
    .replace(/^---+$/gm, '<hr class="my-3 border-white/10"/>')
    // paragraphs: wrap consecutive non-empty lines not already in a block tag
    .replace(/^(?!<[houpl]|<hr|<pre)(.+)$/gm, '<p class="mb-1">$1</p>');
  return html;
}

export const PLATFORM_META = {
  leetcode: {
    favicon:
      "https://assets.leetcode.com/static_assets/public/icons/favicon.ico",
    label: "LeetCode",
    color: CONSTANTS.PLATFORMS.leetcode.color,
    url: (slug) => CONSTANTS.PLATFORMS.leetcode.problemsBase + slug + "/",
  },
  geeksforgeeks: {
    favicon: "https://www.geeksforgeeks.org/favicon.ico",
    label: "GeeksForGeeks",
    color: CONSTANTS.PLATFORMS.geeksforgeeks.color,
    url: (slug) => CONSTANTS.PLATFORMS.geeksforgeeks.practiceBase + slug,
  },
  codeforces: {
    favicon: "https://codeforces.com/favicon.ico",
    label: "Codeforces",
    color: CONSTANTS.PLATFORMS.codeforces.color,
    url: (slug) => CONSTANTS.PLATFORMS.codeforces.problemsBase + slug,
  },
};

function _fmtElapsed(secs) {
  if (!secs || secs <= 0) return null;
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = secs % 60;
  if (h > 0) return `${h}h ${m}m ${s}s`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

const DIFF_CLASS = {
  Easy: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
  Medium: "bg-amber-500/15 text-amber-400 border-amber-500/30",
  Hard: "bg-rose-500/15 text-rose-400 border-rose-500/30",
};

const CHAT_KEY = (slug) => `cl-chat-${slug}`;

// Session-level memory of the last active tab — survives problem navigation but not page reload.
let _lastModalTab = "overview";

export function ProblemModal({
  problem,
  onClose,
  onUpdate,
  onDelete,
  problemList = [],
  onNavigateProblem,
  onOpenGraphProblem,
  onNavigate,
}) {
  const [activeTab, setActiveTab] = useState("overview");
  const [copied, setCopied] = useState(false);
  const [chatMessages, setChatMessages] = useState([]);
  const [chatInput, setChatInput] = useState("");
  const [chatPending, setChatPending] = useState(false);
  const [chatError, setChatError] = useState("");
  const [chatId, setChatId] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const [reviewBusy, setReviewBusy] = useState(false);
  const [reviewError, setReviewError] = useState("");
  const [queueStatus, setQueueStatus] = useState(null);
  const [queueStatusError, setQueueStatusError] = useState("");
  const [queueActionBusy, setQueueActionBusy] = useState(false);
  const [removeFromQueueBusy, setRemoveFromQueueBusy] = useState(false);
  const [settings, setSettings] = useState({});
  const [notes, setNotes] = useState(problem?.notes || "");

  // Save notes when they change
  const handleNotesChange = async (newNotes) => {
    setNotes(newNotes);
    try {
      const updated = { ...problem, notes: newNotes };
      await Storage.saveProblem(updated);
      onUpdate?.(updated);
    } catch (_) {}
  };
  const [methods, setMethods] = useState(problem?.methods || []);
  const [selectedMethodIdx, setSelectedMethodIdx] = useState(0);
  const [showAddMethod, setShowAddMethod] = useState(false);
  const [newMethodTitle, setNewMethodTitle] = useState("");
  const [newMethodDesc, setNewMethodDesc] = useState("");

  const handleAddMethod = async () => {
    if (!newMethodTitle.trim()) return;
    const langName = problem.lang?.name || "solution";
    const newMethod = {
      title: newMethodTitle,
      language: langName,
      description: newMethodDesc,
      code: "",
      timestamp: Date.now(),
    };
    const updatedMethods = [...methods, newMethod];
    setMethods(updatedMethods);
    setShowAddMethod(false);
    setNewMethodTitle("");
    setNewMethodDesc("");
    try {
      const updated = { ...problem, methods: updatedMethods };
      await Storage.saveProblem(updated);
      onUpdate?.(updated);
    } catch (_) {}
  };

  const handleDeleteMethod = async (idx) => {
    const updatedMethods = methods.filter((_, i) => i !== idx);
    setMethods(updatedMethods);
    setSelectedMethodIdx(
      Math.min(selectedMethodIdx, updatedMethods.length - 1),
    );
    try {
      const updated = { ...problem, methods: updatedMethods };
      await Storage.saveProblem(updated);
      onUpdate?.(updated);
    } catch (_) {}
  };

  useEffect(() => {
    Storage.getSettings()
      .then(setSettings)
      .catch(() => {});
  }, []);

  const fetchQueueStatus = useCallback(() => {
    if (typeof chrome === "undefined" || !chrome.runtime?.id) {
      setQueueStatus(null);
      return Promise.resolve(null);
    }
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(
        { type: "GET_AI_REVIEW_QUEUE_STATUS" },
        (resp) => {
          if (chrome.runtime.lastError || !resp?.ok) {
            setQueueStatus(null);
            setQueueStatusError(
              resp?.error || chrome.runtime.lastError?.message || "",
            );
            resolve(null);
            return;
          }
          setQueueStatus(resp);
          setQueueStatusError("");
          resolve(resp);
        },
      );
    });
  }, []);

  useEffect(() => {
    fetchQueueStatus();
    const timer = setInterval(fetchQueueStatus, 30000);
    return () => clearInterval(timer);
  }, [fetchQueueStatus]);

  // Update notes when problem changes
  useEffect(() => {
    setNotes(problem?.notes || "");
    setMethods(problem?.methods || []);
    setSelectedMethodIdx(0);
    setShowAddMethod(false);
  }, [problem?.id]);

  // Reset (or restore) tab and load chat history when problem changes
  useEffect(() => {
    if (
      settings?.remember_modal_tab &&
      _lastModalTab &&
      _lastModalTab !== "overview"
    ) {
      // Check if the remembered tab exists for this problem
      const regTabs = modalTabRegistry.getTabs(
        problem?.platform || "leetcode",
        problem,
      );
      const available = new Set([
        ...regTabs.map((t) => t.id),
        "notes",
        ...(problem?.methods?.length > 0 ? ["methods"] : []),
      ]);
      setActiveTab(available.has(_lastModalTab) ? _lastModalTab : "overview");
    } else {
      setActiveTab("overview");
    }
    if (problem) {
      setChatMessages([]);
      setChatInput("");
      setChatError("");
      setChatId(null);

      if (problem.titleSlug) {
        getChatsByProblem(problem.titleSlug)
          .then((chats) => {
            const latest = chats?.[0];
            if (!latest) return;
            setChatId(latest.id);
            setChatMessages(latest.messages || []);
          })
          .catch(() => {});
      }
    }
  }, [problem?.titleSlug, problem?.id, settings?.remember_modal_tab]);

  // Escape to close
  useEffect(() => {
    if (!problem) return;
    const onKey = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [problem, onClose]);

  const isExtension = typeof chrome !== "undefined" && !!chrome.runtime?.id;
  const problemIndex = problemList.findIndex(
    (entry) =>
      (entry?.id || entry?.titleSlug) === (problem?.id || problem?.titleSlug),
  );
  const canNavigate = problemList.length > 1 && problemIndex >= 0;

  // Arrow key navigation (← prev, → next)
  useEffect(() => {
    if (!problem || !canNavigate) return;
    const onKey = (e) => {
      if (e.key === "ArrowLeft") {
        e.preventDefault();
        onNavigateProblem?.(
          problemList[
            (problemIndex - 1 + problemList.length) % problemList.length
          ],
        );
      }
      if (e.key === "ArrowRight") {
        e.preventDefault();
        onNavigateProblem?.(
          problemList[(problemIndex + 1) % problemList.length],
        );
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [problem, canNavigate, problemIndex, problemList, onNavigateProblem]);

  if (!problem) return null;

  const meta = PLATFORM_META[problem.platform] || {
    label: problem.platform || "Unknown",
    color: "#64748b",
    url: () => "#",
    favicon: null,
  };
  const problemUrl = meta.url(problem.titleSlug || problem.id || "");

  // Sort tags by importance: first by tag type (algorithms before data structures, etc),
  // then alphabetically within each type. Priority: algorithms, data-structures, concepts, misc
  const _tagPriority = {
    algorithms: 0,
    sorting: 1,
    searching: 1,
    "dynamic-programming": 2,
    greedy: 2,
    backtracking: 2,
    graph: 3,
    tree: 3,
    "linked-list": 4,
    array: 4,
    "hash-table": 4,
    string: 5,
    math: 6,
    "bit-manipulation": 7,
  };
  const topics = (
    Array.isArray(problem.tags) && problem.tags.length > 0
      ? problem.tags.sort((a, b) => {
          const aPri = _tagPriority[String(a).toLowerCase()] ?? 999;
          const bPri = _tagPriority[String(b).toLowerCase()] ?? 999;
          if (aPri !== bPri) return aPri - bPri;
          return String(a).localeCompare(String(b));
        })
      : problem.topic
        ? [problem.topic]
        : []
  ).filter((t) => t && t !== "Untagged");
  const diffClass =
    DIFF_CLASS[problem.difficulty] ||
    "bg-white/5 text-slate-400 border-white/10";
  const langName = problem.lang?.name || problem.language || null;

  const copyCode = async () => {
    if (!problem.code) return;
    try {
      await navigator.clipboard.writeText(cleanCode(problem.code));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (_) {}
  };

  // Siblings: same problem solved in a different language or on a different platform
  const siblings = problemList.filter((p) => {
    if (!p || p.id === problem.id) return false;
    const sameSlug = p.titleSlug && p.titleSlug === problem.titleSlug;
    const sameCanonical =
      p.canonical?.id && p.canonical.id === problem.canonical?.id;
    return sameSlug || sameCanonical;
  });

  // Handle refresh of problem statement from handler
  const handleRefreshData = useCallback(async () => {
    if (refreshing) return;
    setRefreshing(true);
    try {
      const id = encodeURIComponent(problem.titleSlug || problem.id || "");
      const url = `${problemUrl}${problemUrl.includes("?") ? "&" : "?"}codeledger_fetch=1&cl_fetch_id=${id}`;
      window.open(url, "_blank", "noopener,noreferrer,width=800,height=600");

      let fetched = false;
      for (let i = 0; i < 20; i++) {
        await new Promise((r) => setTimeout(r, 500));
        try {
          const updated = await Storage.getProblem(
            problem.id || problem.titleSlug,
          );
          if (
            updated?.problemStatement &&
            updated.problemStatement !== problem.problemStatement
          ) {
            onUpdate?.(updated);
            fetched = true;
            break;
          }
        } catch (_) {}
      }
      if (!fetched) {
        setChatError("Refresh timeout. Check the opened tab and try again.");
        setTimeout(() => setChatError(""), 5000);
      }
    } catch (e) {
      setChatError("Refresh failed: " + (e.message || e));
      setTimeout(() => setChatError(""), 5000);
    } finally {
      setRefreshing(false);
    }
  }, [problem, refreshing, onUpdate, problemUrl]);

  const sendChat = async () => {
    const rawText = chatInput.trim();
    if (!rawText || chatPending) return;

    const text = await expandChatVariables(rawText, {
      problem,
      userCode: problem.code || "",
      hints: problem.hints || [],
      similar: problem.similar || [],
      constraints: problem.constraints || "",
    });

    const userMsg = { role: "user", content: text, ts: Date.now() };
    const updatedMsgs = [...chatMessages, userMsg];
    setChatMessages(updatedMsgs);
    setChatInput("");
    setChatPending(true);
    setChatError("");

    try {
      const context = buildAIChatContext({
        surface: "problem-modal",
        problem,
        text,
        code: problem.code || "",
        lang: problem.lang,
        aiReview: problem.aiReview || "",
        problemStatement: problem.problemStatement || "",
        hints: problem.hints || [],
        similar: problem.similar || [],
        constraints: problem.constraints || "",
        attachedProblemSlugs: problem.titleSlug ? [problem.titleSlug] : [],
        attachedProblems: problem.titleSlug
          ? [
              {
                slug: problem.titleSlug,
                title: problem.title || problem.titleSlug,
                platform: problem.platform || "leetcode",
                url: problemUrl,
              },
            ]
          : [],
      });

      const response = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
          {
            type: "AI_CHAT",
            messages: updatedMsgs.map(({ role, content }) => ({
              role,
              content,
            })),
            context,
          },
          (resp) => {
            if (chrome.runtime.lastError)
              reject(new Error(chrome.runtime.lastError.message));
            else if (resp?.ok) resolve(resp.response);
            else reject(new Error(resp?.error || "AI failed"));
          },
        );
      });

      const aiMsg = {
        role: "assistant",
        content: response,
        ts: Date.now(),
      };
      const finalMsgs = [...updatedMsgs, aiMsg];
      setChatMessages(finalMsgs);

      const meta = {
        problemTitle: problem.title || "",
        problemTags: Array.isArray(problem.tags) ? problem.tags : [],
        attachedProblemSlugs: problem.titleSlug ? [problem.titleSlug] : [],
        attachedProblems: problem.titleSlug
          ? [
              {
                slug: problem.titleSlug,
                title: problem.title || problem.titleSlug,
                platform: problem.platform || "leetcode",
                url: problemUrl,
              },
            ]
          : [],
        surface: "problem-modal",
        requestType: context.requestType || "",
        usedCommands: context.usedCommands || [],
        requestTemplate: text,
        summary: text.slice(0, 120),
      };

      if (chatId) {
        await updateAIChat(chatId, finalMsgs, meta);
      } else {
        const newChatId = await saveAIChat(
          problem.titleSlug,
          problemUrl,
          finalMsgs,
          problem.platform || "leetcode",
          meta,
        );
        setChatId(newChatId);
      }
    } catch (e) {
      setChatError(e.message);
    } finally {
      setChatPending(false);
    }
  };

  const handleGenerateAIReview = async () => {
    if (reviewBusy) return;
    if (!problem?.code) {
      setReviewError(
        "No code saved for this problem. Solve it on the platform first.",
      );
      return;
    }
    if (typeof chrome === "undefined" || !chrome.runtime?.id) {
      setReviewError("Extension not available.");
      return;
    }
    setReviewBusy(true);
    setReviewError("");
    try {
      dbg.log(
        `Requesting AI review for problem ${problem.id || problem.titleSlug}`,
      );
      const TIMEOUT_MS = 90000;
      // Keep the MV3 service worker alive for the duration of the request.
      // An open runtime port prevents Chrome from terminating the SW mid-call.
      let keepAlivePort = null;
      let keepAliveTimer = null;
      try {
        keepAlivePort = chrome.runtime.connect({ name: "ai-review-keepalive" });
        keepAliveTimer = setInterval(() => {
          try {
            keepAlivePort?.postMessage({ type: "ping" });
          } catch (_) {}
        }, 20000);
      } catch (_) {}
      const releaseKeepalive = () => {
        clearInterval(keepAliveTimer);
        try {
          keepAlivePort?.disconnect();
        } catch (_) {}
        keepAlivePort = null;
      };

      const result = await new Promise((resolve, reject) => {
        let settled = false;
        const timer = setTimeout(() => {
          if (settled) return;
          settled = true;
          releaseKeepalive();
          dbg.warn("AI review request timed out for UI request");
          reject(new Error("AI review timed out"));
        }, TIMEOUT_MS);

        chrome.runtime.sendMessage(
          { type: "REGENERATE_AI_REVIEW", problem },
          (resp) => {
            if (settled) return;
            settled = true;
            clearTimeout(timer);
            releaseKeepalive();
            if (chrome.runtime.lastError) {
              dbg.warn(
                "REGENERATE_AI_REVIEW message error:",
                chrome.runtime.lastError.message,
              );
              reject(new Error(chrome.runtime.lastError.message));
            } else if (resp?.ok) {
              dbg.log(
                `AI review response received for ${problem.id || problem.titleSlug}`,
              );
              resolve(resp);
            } else {
              dbg.warn("REGENERATE_AI_REVIEW failed:", resp?.error);
              reject(new Error(resp?.error || "AI review failed"));
            }
          },
        );
      });

      if (result?.problem) {
        onUpdate?.(result.problem);
      }
      setActiveTab("review");
    } catch (e) {
      setReviewError(e.message || String(e));
    } finally {
      setReviewBusy(false);
    }
  };

  const handleRunAIReviewQueueNow = async () => {
    if (queueActionBusy) return;
    if (typeof chrome === "undefined" || !chrome.runtime?.id) {
      setQueueStatusError("Extension not available.");
      return;
    }
    setQueueActionBusy(true);
    setQueueStatusError("");
    try {
      const result = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
          { type: "PROCESS_REVIEW_QUEUE_NOW" },
          (resp) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else if (resp?.ok) {
              resolve(resp);
            } else {
              reject(new Error(resp?.error || "Failed to start queue"));
            }
          },
        );
      });
      if (result?.ok) {
        await fetchQueueStatus();
      }
    } catch (e) {
      setQueueStatusError(e.message || String(e));
    } finally {
      setQueueActionBusy(false);
    }
  };

  const handleRemoveFromQueue = async () => {
    if (removeFromQueueBusy || !problem?.id) return;
    if (typeof chrome === "undefined" || !chrome.runtime?.id) return;
    setRemoveFromQueueBusy(true);
    try {
      await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          { type: "REMOVE_QUEUE_ITEMS_BY_PROBLEM", problemId: problem.id },
          (resp) => {
            void chrome.runtime.lastError;
            resolve(resp);
          },
        );
      });
      await fetchQueueStatus();
    } catch (_) {
    } finally {
      setRemoveFromQueueBusy(false);
    }
  };

  const openAIChatsView = () => {
    const chatSlug = String(problem?.titleSlug || problem?.id || "").trim();
    const chatPrompt = chatInput.trim();
    try {
      chrome.runtime.sendMessage({
        type: "OPEN_LIBRARY",
        tab: "ai-chats",
        chatSlug,
        ...(chatPrompt ? { chatPrompt } : {}),
      });
      return;
    } catch (_) {}

    try {
      const params = new URLSearchParams({ tab: "ai-chats" });
      if (chatSlug) params.set("chatSlug", chatSlug);
      if (chatPrompt) params.set("chatPrompt", chatPrompt);
      window.open(
        chrome.runtime.getURL(`library/library.html?${params.toString()}`),
        "_blank",
      );
    } catch (_) {}
  };

  const registryTabs = modalTabRegistry.getTabs(
    problem.platform || "leetcode",
    problem,
  );
  const baseTabs = registryTabs.map((tab) => ({
    id: tab.id,
    label: typeof tab.label === "function" ? tab.label(problem) : tab.label,
  }));
  // Add Notes tab
  const tabs = [
    ...baseTabs,
    ...(methods.length > 0
      ? [{ id: "methods", label: `🔄 Methods (${methods.length})` }]
      : []),
    { id: "notes", label: "📝 Notes" },
  ];

  return html`
    <div
      class="fixed inset-0 z-[9999] flex items-center justify-center p-4"
      style="background:rgba(0,0,0,0.8);backdrop-filter:blur(6px)"
      onClick=${(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        class="relative w-full max-w-[72rem] max-h-[calc(100vh-80px)] flex flex-col bg-[#0d1117] border border-white/10 rounded-2xl shadow-2xl overflow-hidden"
      >
        <!-- ── Header ── -->
        <div
          class="flex items-start gap-3 p-5 border-b border-white/5 shrink-0"
        >
          ${meta.favicon
            ? html`
                <img
                  src=${meta.favicon}
                  alt=""
                  class="w-5 h-5 mt-0.5 object-contain shrink-0"
                  onError=${(e) => {
                    e.target.style.display = "none";
                  }}
                />
              `
            : ""}
          <div class="flex-1 min-w-0">
            <h2 class="text-base font-semibold text-white leading-snug">
              ${problem.title}
            </h2>
            <div class="flex items-center gap-2 mt-1.5 flex-wrap">
              <span
                class="px-1.5 py-0.5 rounded text-[10px] font-bold uppercase border ${diffClass}"
                >${problem.difficulty || "?"}</span
              >
              <span class="text-[10px] text-slate-500">${meta.label}</span>
              ${langName
                ? html`<span class="text-[10px] font-mono text-cyan-500/70"
                    >${langName}</span
                  >`
                : ""}
              ${problem.timestamp
                ? html`<span class="text-[10px] text-slate-600"
                    >${new Date(
                      problem.timestamp < 1e12
                        ? problem.timestamp * 1000
                        : problem.timestamp,
                    ).toLocaleDateString()}</span
                  >`
                : ""}
            </div>
          </div>
          <div class="flex items-center gap-2 shrink-0">
            ${onNavigate
              ? html`
                  <button
                    onClick=${() => {
                      onClose();
                      onNavigate("solutions");
                    }}
                    class="shrink-0 px-3 h-8 flex items-center justify-center rounded-lg text-[10px] font-medium text-slate-300 bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
                    title="Go to Solutions list"
                  >
                    Solutions
                  </button>
                  <button
                    onClick=${() => {
                      onClose();
                      onNavigate("analytics");
                    }}
                    class="shrink-0 px-3 h-8 flex items-center justify-center rounded-lg text-[10px] font-medium text-violet-300 bg-violet-500/10 border border-violet-500/20 hover:bg-violet-500/20 transition-colors"
                    title="Go to Analytics"
                  >
                    Analytics
                  </button>
                  <button
                    onClick=${() => {
                      onClose();
                      onNavigate("graph");
                    }}
                    class="shrink-0 px-3 h-8 flex items-center justify-center rounded-lg text-[10px] font-medium text-cyan-300 bg-cyan-500/10 border border-cyan-500/20 hover:bg-cyan-500/20 transition-colors"
                    title="Go to Knowledge Graph"
                  >
                    Graph
                  </button>
                `
              : onOpenGraphProblem
                ? html`
                    <button
                      onClick=${() => onOpenGraphProblem(problem)}
                      class="shrink-0 px-3 h-8 flex items-center justify-center rounded-lg text-[10px] font-medium text-cyan-300 bg-cyan-500/10 border border-cyan-500/20 hover:bg-cyan-500/20 transition-colors"
                      title="Open this problem in the graph"
                    >
                      Graph ↗
                    </button>
                  `
                : ""}
            ${problem.submissionsUrl ||
            (problem.platform === "leetcode" && problem.titleSlug)
              ? html`
                  <a
                    href=${problem.submissionsUrl ||
                    CONSTANTS.PLATFORMS.leetcode.problemsBase +
                      problem.titleSlug +
                      "/submissions/"}
                    target="_blank"
                    rel="noopener"
                    class="shrink-0 px-3 h-8 flex items-center justify-center rounded-lg text-[10px] font-medium text-amber-300 bg-amber-500/10 border border-amber-500/20 hover:bg-amber-500/20 transition-colors"
                    title="View all submissions for this problem"
                    >Submissions ↗</a
                  >
                `
              : ""}
            ${canNavigate
              ? html`
                  <button
                    onClick=${() =>
                      onNavigateProblem?.(
                        problemList[
                          (problemIndex - 1 + problemList.length) %
                            problemList.length
                        ],
                      )}
                    class="shrink-0 w-8 h-8 flex items-center justify-center rounded-lg text-slate-500 hover:text-white hover:bg-white/10 transition-colors"
                    title="Previous problem"
                  >
                    ←
                  </button>
                  <button
                    onClick=${() =>
                      onNavigateProblem?.(
                        problemList[(problemIndex + 1) % problemList.length],
                      )}
                    class="shrink-0 w-8 h-8 flex items-center justify-center rounded-lg text-slate-500 hover:text-white hover:bg-white/10 transition-colors"
                    title="Next problem"
                  >
                    →
                  </button>
                `
              : ""}
            <button
              onClick=${onClose}
              class="shrink-0 w-8 h-8 flex items-center justify-center rounded-lg text-slate-500 hover:text-white hover:bg-white/10 transition-colors"
            >
              ✕
            </button>
          </div>
        </div>

        <!-- ── Topics ── -->
        ${topics.length
          ? html`
              <div class="flex flex-wrap gap-1.5 px-5 pt-3 shrink-0">
                ${topics.map(
                  (t) => html`
                    <span
                      class="px-2 py-0.5 rounded-full text-[10px] bg-white/5 border border-white/10 text-slate-400"
                      >${t}</span
                    >
                  `,
                )}
              </div>
            `
          : ""}

        <!-- ── Stats row ── -->
        ${problem.runtime ||
        problem.memory ||
        problem.acRate ||
        problem.elapsedSeconds
          ? html`
              <div class="flex gap-6 px-5 pt-3 shrink-0">
                ${problem.runtime
                  ? html`
                      <div class="flex flex-col gap-0.5">
                        <span
                          class="text-[9px] uppercase tracking-wider text-slate-600"
                          >Runtime</span
                        >
                        <span class="text-xs text-slate-300">
                          ${problem.runtime}
                          ${problem.runtimePct
                            ? html`<span class="text-cyan-500/60 text-[10px]">
                                · beats ${problem.runtimePct.toFixed(0)}%</span
                              >`
                            : ""}
                        </span>
                      </div>
                    `
                  : ""}
                ${problem.memory
                  ? html`
                      <div class="flex flex-col gap-0.5">
                        <span
                          class="text-[9px] uppercase tracking-wider text-slate-600"
                          >Memory</span
                        >
                        <span class="text-xs text-slate-300">
                          ${problem.memory}
                          ${problem.memoryPct
                            ? html`<span class="text-cyan-500/60 text-[10px]">
                                · beats ${problem.memoryPct.toFixed(0)}%</span
                              >`
                            : ""}
                        </span>
                      </div>
                    `
                  : ""}
                ${problem.acRate
                  ? html`
                      <div class="flex flex-col gap-0.5">
                        <span
                          class="text-[9px] uppercase tracking-wider text-slate-600"
                          >Accept Rate</span
                        >
                        <span class="text-xs text-slate-300"
                          >${typeof problem.acRate === "number"
                            ? problem.acRate.toFixed(1)
                            : problem.acRate}%</span
                        >
                      </div>
                    `
                  : ""}
                ${problem.elapsedSeconds
                  ? html`
                      <div class="flex flex-col gap-0.5">
                        <span
                          class="text-[9px] uppercase tracking-wider text-slate-600"
                          >Solve Time</span
                        >
                        <span class="text-xs text-slate-300"
                          >${_fmtElapsed(problem.elapsedSeconds)}</span
                        >
                      </div>
                    `
                  : ""}
              </div>
            `
          : ""}

        <!-- ── Siblings (same problem, other language / platform) ── -->
        ${siblings.length
          ? html`
              <div class="flex items-center gap-2 px-5 pt-3 shrink-0 flex-wrap">
                <span
                  class="text-[10px] uppercase tracking-wider text-slate-600 shrink-0"
                  >Also solved as</span
                >
                ${siblings.map((sib) => {
                  const sibMeta = PLATFORM_META[sib.platform] || {
                    label: sib.platform || "?",
                    favicon: null,
                  };
                  const sibLang = sib.lang?.name || sib.language || "?";
                  const isSamePlatform = sib.platform === problem.platform;
                  return html`
                    <button
                      onClick=${() => onNavigateProblem?.(sib)}
                      class="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] bg-white/5 border border-white/10 text-slate-400 hover:text-white hover:bg-white/10 hover:border-white/20 transition-colors"
                      title="Open ${sibMeta.label} / ${sibLang} solution"
                    >
                      ${sibMeta.favicon
                        ? html`<img
                            src=${sibMeta.favicon}
                            alt=""
                            class="w-3 h-3 object-contain"
                            onError=${(e) => {
                              e.target.style.display = "none";
                            }}
                          />`
                        : ""}
                      ${!isSamePlatform
                        ? html`<span class="text-slate-500"
                            >${sibMeta.label}</span
                          >`
                        : ""}
                      <span class="font-mono text-cyan-400/80">${sibLang}</span>
                    </button>
                  `;
                })}
              </div>
            `
          : ""}

        <!-- ── Tabs ── -->
        ${tabs.length > 1
          ? html`
              <div
                class="flex gap-0.5 px-5 pt-3 border-b border-white/5 shrink-0"
              >
                ${tabs.map(
                  (tab) => html`
                    <button
                      onClick=${() => {
                        _lastModalTab = tab.id;
                        setActiveTab(tab.id);
                      }}
                      class="px-3 py-1.5 text-xs rounded-t-lg transition-colors ${activeTab ===
                      tab.id
                        ? "bg-white/10 text-white border border-b-0 border-white/10"
                        : "text-slate-500 hover:text-slate-300"}"
                    >
                      ${tab.label}
                    </button>
                  `,
                )}
              </div>
            `
          : html`<div class="border-b border-white/5 shrink-0"></div>`}

        <!-- ── Tab content ── -->
        <div class="flex-1 overflow-y-auto p-5 min-h-0">
          ${activeTab === "methods"
            ? html`
                <div class="flex flex-col gap-4 h-full">
                  ${methods.map(
                    (method, idx) => html`
                      <div
                        class="p-3 rounded-lg border ${selectedMethodIdx === idx
                          ? "border-cyan-500/50 bg-cyan-500/10"
                          : "border-white/10 bg-white/5"} transition-colors cursor-pointer"
                      >
                        <button
                          onClick=${() => setSelectedMethodIdx(idx)}
                          class="w-full text-left"
                        >
                          <div class="flex items-start justify-between mb-2">
                            <div>
                              <h4 class="font-semibold text-sm text-white">
                                ${method.title}
                              </h4>
                              <span class="text-[10px] font-mono text-cyan-400"
                                >${method.language}</span
                              >
                            </div>
                            <button
                              onClick=${(e) => {
                                e.stopPropagation();
                                handleDeleteMethod(idx);
                              }}
                              class="text-xs px-2 py-1 rounded bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 transition-colors"
                            >
                              Delete
                            </button>
                          </div>
                          ${method.description
                            ? html`<p class="text-[10px] text-slate-400 mb-2">
                                ${method.description}
                              </p>`
                            : ""}
                          <span class="text-[9px] text-slate-600"
                            >${method.timestamp
                              ? new Date(method.timestamp).toLocaleDateString()
                              : "No date"}</span
                          >
                        </button>
                      </div>
                    `,
                  )}
                  <button
                    onClick=${() => setShowAddMethod(true)}
                    class="mt-2 px-3 py-2 rounded-lg text-sm bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/30 transition-colors"
                  >
                    + Add Method
                  </button>
                  ${showAddMethod
                    ? html`
                        <div
                          class="border border-white/10 rounded-lg p-3 bg-white/5"
                        >
                          <label
                            class="text-[10px] uppercase tracking-wider text-slate-500 font-semibold block mb-1"
                          >
                            Method Title
                          </label>
                          <input
                            type="text"
                            value=${newMethodTitle}
                            onInput=${(e) => setNewMethodTitle(e.target.value)}
                            placeholder="e.g., Recursive Approach"
                            class="w-full p-2 rounded text-sm bg-white/5 border border-white/10 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-cyan-500/50 mb-3"
                          />
                          <label
                            class="text-[10px] uppercase tracking-wider text-slate-500 font-semibold block mb-1"
                          >
                            Description (Optional)
                          </label>
                          <textarea
                            value=${newMethodDesc}
                            onInput=${(e) => setNewMethodDesc(e.target.value)}
                            placeholder="Brief description of this approach..."
                            class="w-full h-16 p-2 rounded text-sm bg-white/5 border border-white/10 text-slate-200 placeholder-slate-600 resize-none focus:outline-none focus:border-cyan-500/50 mb-3"
                          />
                          <div class="flex gap-2">
                            <button
                              onClick=${handleAddMethod}
                              class="flex-1 px-3 py-2 rounded text-xs font-semibold bg-emerald-500/30 text-emerald-300 border border-emerald-500/50 hover:bg-emerald-500/40 transition-colors"
                            >
                              Create Method
                            </button>
                            <button
                              onClick=${() => {
                                setShowAddMethod(false);
                                setNewMethodTitle("");
                                setNewMethodDesc("");
                              }}
                              class="px-3 py-2 rounded text-xs text-slate-400 hover:text-slate-200 transition-colors"
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      `
                    : ""}
                </div>
              `
            : activeTab === "notes"
              ? html`
                  <div class="flex flex-col gap-3 h-full">
                    <div>
                      <label
                        class="text-[11px] uppercase tracking-wider text-slate-500 font-semibold block mb-2"
                      >
                        Problem Notes
                      </label>
                      <textarea
                        value=${notes}
                        onInput=${(e) => handleNotesChange(e.target.value)}
                        placeholder="Add notes, observations, or follow-up items..."
                        class="w-full h-64 p-3 rounded-lg bg-white/5 border border-white/10 text-sm text-slate-200 placeholder-slate-600 resize-none focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/30 font-mono"
                      />
                    </div>
                    <div class="text-[10px] text-slate-600">
                      Notes are saved automatically to your problem record.
                    </div>
                  </div>
                `
              : (() => {
                  const renderer = modalTabRegistry.getRenderer(
                    problem.platform || "leetcode",
                    activeTab,
                  );
                  if (!renderer)
                    return html`<p class="text-slate-500 text-sm">
                      No content.
                    </p>`;
                  const onClearChat = async () => {
                    setChatMessages([]);
                    setChatError("");
                    if (chatId) {
                      await updateAIChat(chatId, [], {
                        problemTitle: problem.title || "",
                        problemTags: Array.isArray(problem.tags)
                          ? problem.tags
                          : [],
                        attachedProblemSlugs: problem.titleSlug
                          ? [problem.titleSlug]
                          : [],
                        attachedProblems: problem.titleSlug
                          ? [
                              {
                                slug: problem.titleSlug,
                                title: problem.title || problem.titleSlug,
                                platform: problem.platform || "leetcode",
                                url: problemUrl,
                              },
                            ]
                          : [],
                        surface: "problem-modal",
                        requestType: "",
                        usedCommands: [],
                        requestTemplate: "",
                      }).catch(() => {});
                    }
                  };
                  const ctx = {
                    html,
                    isExtension,
                    onClose,
                    onUpdate,
                    onDelete,
                    refreshing,
                    handleRefreshData,
                    problemUrl,
                    meta,
                    langName,
                    copied,
                    copyCode,
                    chatMessages,
                    chatInput,
                    setChatInput,
                    sendChat,
                    chatPending,
                    chatError,
                    AIMarkdownRenderer,
                    MultiLineAIChatInput,
                    ModelStatusBar,
                    openAIChatsView,
                    onClearChat,
                    chatId,
                    AIReviewPanel,
                    onGenerateAIReview: handleGenerateAIReview,
                    reviewBusy,
                    reviewError,
                    queueStatus,
                    queueError: queueStatusError,
                    onRunQueueNow: handleRunAIReviewQueueNow,
                    runQueueBusy: queueActionBusy,
                    onRemoveFromQueue: handleRemoveFromQueue,
                    removeFromQueueBusy,
                    settings,
                  };
                  return renderer(problem, ctx);
                })()}
        </div>

        <!-- ── Footer ── -->
        <div
          class="border-t border-white/5 px-5 py-3 flex items-center justify-between shrink-0"
        >
          <a
            href=${problemUrl}
            target="_blank"
            rel="noopener"
            class="flex items-center gap-2 text-xs text-cyan-400 hover:text-cyan-300 transition-colors no-underline"
          >
            ${meta.favicon
              ? html`<img
                  src=${meta.favicon}
                  class="w-3.5 h-3.5 object-contain"
                  alt=""
                  onError=${(e) => {
                    e.target.style.display = "none";
                  }}
                />`
              : ""}
            Open on ${meta.label} ↗
          </a>
          <span class="text-[10px] text-slate-700 font-mono"
            >${problem.titleSlug || ""}</span
          >
        </div>
      </div>
    </div>
  `;
}

// ── CodeTab sub-component — shows code or a recovery button when code is missing ──

function CodeTab({ problem, langName, copied, copyCode, onUpdate }) {
  const [recovering, setRecovering] = useState(false);
  const [recoveryError, setRecoveryError] = useState("");

  if (!problem.code) {
    const isExtensionCtx =
      typeof chrome !== "undefined" && !!chrome.runtime?.id;
    return html`
      <div class="flex flex-col items-center gap-4 py-12 text-center">
        <p class="text-slate-500 text-sm">
          Code was not extracted for this submission.
        </p>
        ${isExtensionCtx
          ? html`
              <button
                onClick=${async () => {
                  setRecovering(true);
                  setRecoveryError("");
                  try {
                    const res = await new Promise((resolve) =>
                      chrome.runtime.sendMessage(
                        {
                          type: "TRIGGER_CODE_RECOVERY",
                          problemId: problem.id,
                        },
                        resolve,
                      ),
                    );
                    if (res?.ok && res.code) {
                      const updated = await Storage.getProblem(problem.id);
                      if (updated) onUpdate(updated);
                    } else {
                      setRecoveryError(
                        res?.error || "Recovery failed — no code returned",
                      );
                    }
                  } catch (e) {
                    setRecoveryError(e?.message || "Recovery failed");
                  } finally {
                    setRecovering(false);
                  }
                }}
                disabled=${recovering}
                class="px-4 py-2 rounded-lg bg-cyan-600/15 border border-cyan-500/30 text-cyan-300 text-xs hover:bg-cyan-600/30 disabled:opacity-40 transition-colors"
              >
                ${recovering
                  ? "Recovering code…"
                  : "Recover Code from LeetCode"}
              </button>
              ${recoveryError
                ? html` <p class="text-rose-400 text-xs max-w-xs">
                      ${recoveryError}
                    </p>
                    <a
                      href=${CONSTANTS.PLATFORMS.leetcode.baseUrl}
                      target="_blank"
                      rel="noopener"
                      class="text-[10px] text-cyan-500 hover:text-cyan-300 underline"
                    >
                      Open LeetCode to log in, then retry
                    </a>`
                : ""}
              <p class="text-slate-600 text-[10px] max-w-xs">
                Opens a background LeetCode tab to fetch your latest accepted
                submission. Make sure you are logged into LeetCode first.
              </p>
            `
          : html`<p class="text-slate-600 text-xs">
              Open this problem in the extension to recover the code.
            </p>`}
      </div>
    `;
  }

  const rawLang =
    problem.lang?.slug || problem.lang?.name || problem.language || "";
  const highlighted = highlightCode(problem.code, rawLang);
  return html`<div class="flex flex-col gap-2">
    <div class="flex justify-between items-center">
      <span class="text-[10px] uppercase tracking-wider text-slate-600">
        ${langName || "Solution"}
      </span>
      <button
        onClick=${copyCode}
        class="text-[10px] px-2.5 py-1 rounded bg-white/5 border border-white/10 text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
      >
        ${copied ? "✓ Copied" : "Copy"}
      </button>
    </div>
    <pre
      class="text-xs leading-relaxed overflow-x-auto bg-black/50 rounded-xl border border-white/5 p-4 whitespace-pre font-mono m-0"
      dangerouslySetInnerHTML=${{ __html: highlighted }}
    ></pre>
  </div>`;
}

// ── EditTab sub-component — manages its own edit/delete state ───────────────

function EditTab({ problem, onUpdate, onDelete, onClose }) {
  const initialTags = (() => {
    const fromProblem = Array.isArray(problem.tags) ? problem.tags : [];
    const fallbackTopic =
      problem.topic && problem.topic !== "Untagged" ? [problem.topic] : [];
    return [
      ...new Set(
        [...fromProblem, ...fallbackTopic]
          .map((t) => String(t || "").trim())
          .filter(Boolean),
      ),
    ];
  })();

  const [title, setTitle] = useState(problem.title || "");
  const [difficulty, setDifficulty] = useState(problem.difficulty || "Unknown");
  const [tagList, setTagList] = useState(initialTags);
  const [tagDraft, setTagDraft] = useState("");
  const [notes, setNotes] = useState(problem.notes || "");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const nextTags = (() => {
      const fromProblem = Array.isArray(problem.tags) ? problem.tags : [];
      const fallbackTopic =
        problem.topic && problem.topic !== "Untagged" ? [problem.topic] : [];
      return [
        ...new Set(
          [...fromProblem, ...fallbackTopic]
            .map((t) => String(t || "").trim())
            .filter(Boolean),
        ),
      ];
    })();
    setTitle(problem.title || "");
    setDifficulty(problem.difficulty || "Unknown");
    setTagList(nextTags);
    setTagDraft("");
    setNotes(problem.notes || "");
    setError("");
    setSaved(false);
    setConfirmDelete(false);
    setDeleting(false);
  }, [problem?.id, problem?.titleSlug]);

  const addTagsFromDraft = () => {
    const incoming = tagDraft
      .split(",")
      .map((t) => String(t || "").trim())
      .filter(Boolean);
    if (!incoming.length) return;
    setTagList((prev) => {
      const seen = new Set(prev.map((t) => t.toLowerCase()));
      const merged = [...prev];
      incoming.forEach((tag) => {
        const key = tag.toLowerCase();
        if (!seen.has(key)) {
          merged.push(tag);
          seen.add(key);
        }
      });
      return merged;
    });
    setTagDraft("");
  };

  const removeTag = (tagToRemove) => {
    setTagList((prev) => prev.filter((tag) => tag !== tagToRemove));
  };

  const save = async () => {
    setSaving(true);
    setError("");
    try {
      const newTags = [
        ...new Set(tagList.map((t) => String(t || "").trim()).filter(Boolean)),
      ];
      const updated = {
        ...problem,
        title: title.trim() || problem.title,
        difficulty,
        tags: newTags,
        topic: newTags[0] || problem.topic || "Untagged",
        notes: notes.trim(),
        manuallyEdited: true,
      };
      await Storage.saveProblem(updated);
      const slug = String(updated.titleSlug || updated.id || "").trim();
      const lang =
        updated.lang?.name || updated.lang?.slug || updated.lang?.ext || "";
      const normLang = String(lang).toLowerCase().replace(/\s+/g, "");
      const pendingKey = slug ? (normLang ? `${slug}::${normLang}` : slug) : "";
      if (pendingKey)
        await Storage.markPendingProblemKey(pendingKey).catch(() => {});
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
      onUpdate?.(updated);
    } catch (e) {
      setError("Save failed: " + (e.message || e));
    } finally {
      setSaving(false);
    }
  };

  const doDelete = async () => {
    setDeleting(true);
    try {
      await Storage.deleteProblem(problem.id);
      onDelete?.(problem.id);
      onClose?.();
    } catch (e) {
      setError("Delete failed: " + (e.message || e));
      setDeleting(false);
      setConfirmDelete(false);
    }
  };

  return html` <div class="flex flex-col gap-5">
    <p class="text-[11px] text-slate-500">
      Update metadata for this problem. Changes are saved locally to your
      browser database.
    </p>

    <div class="flex flex-col gap-1.5">
      <label class="text-[11px] uppercase tracking-wider text-slate-500"
        >Title</label
      >
      <input
        type="text"
        value=${title}
        onInput=${(e) => setTitle(e.target.value)}
        class="px-3 py-2 bg-black border border-white/10 rounded-lg text-sm text-white placeholder-slate-600 focus:outline-none focus:border-cyan-500/50"
      />
    </div>

    <div class="flex flex-col gap-1.5">
      <label class="text-[11px] uppercase tracking-wider text-slate-500"
        >Difficulty</label
      >
      <select
        value=${difficulty}
        onChange=${(e) => setDifficulty(e.target.value)}
        class="px-3 py-2 bg-black border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-cyan-500/50"
      >
        ${["Easy", "Medium", "Hard", "Unknown"].map(
          (d) => html`<option value=${d}>${d}</option>`,
        )}
      </select>
    </div>

    <div class="flex flex-col gap-1.5">
      <label class="text-[11px] uppercase tracking-wider text-slate-500"
        >Tag Editor</label
      >
      <div
        class="flex flex-wrap gap-1.5 p-2 bg-black border border-white/10 rounded-lg min-h-[44px]"
      >
        ${tagList.length
          ? tagList.map(
              (tag) => html`
                <span
                  class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] bg-cyan-500/10 border border-cyan-500/25 text-cyan-300"
                >
                  ${tag}
                  <button
                    onClick=${() => removeTag(tag)}
                    class="text-cyan-200/80 hover:text-white leading-none"
                    title="Remove tag"
                  >
                    ✕
                  </button>
                </span>
              `,
            )
          : html`<span class="text-[11px] text-slate-600">No tags yet</span>`}
      </div>
      <div class="flex items-center gap-2 flex-wrap">
        <input
          type="text"
          value=${tagDraft}
          onInput=${(e) => setTagDraft(e.target.value)}
          onKeyDown=${(e) => {
            if (e.key === "Enter" || e.key === ",") {
              e.preventDefault();
              addTagsFromDraft();
            }
          }}
          placeholder="Add tags (comma-separated or Enter)"
          class="px-3 py-2 bg-black border border-white/10 rounded-lg text-sm text-white placeholder-slate-600 focus:outline-none focus:border-cyan-500/50 min-w-[250px]"
        />
        <button
          onClick=${addTagsFromDraft}
          class="px-3 py-2 bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 text-xs rounded-lg transition-colors"
        >
          Add
        </button>
      </div>
      <p class="text-[10px] text-slate-600">
        First tag becomes the primary topic used in analytics and the graph.
      </p>
    </div>

    <!-- Platform metadata (read-only) -->
    <div class="flex flex-col gap-1">
      <span class="text-[10px] uppercase tracking-wider text-slate-500"
        >Metadata</span
      >
      <div class="grid grid-cols-3 gap-2 text-xs">
        ${[
          ["Platform", problem.platform],
          ["Language", problem.lang?.name],
          ["Runtime", problem.runtime],
          ["Memory", problem.memory],
          [
            "Accept Rate",
            problem.acRate
              ? (typeof problem.acRate === "number"
                  ? problem.acRate.toFixed(1)
                  : problem.acRate) + "%"
              : null,
          ],
          [
            "Solved",
            problem.timestamp
              ? new Date(
                  problem.timestamp < 1e12
                    ? problem.timestamp * 1000
                    : problem.timestamp,
                ).toLocaleDateString()
              : null,
          ],
        ].map(([label, val]) =>
          val
            ? html`
                <div class="bg-white/3 rounded p-2">
                  <span class="text-slate-500 text-[10px]">${label}</span>
                  <p class="text-slate-300 mt-0.5">${val}</p>
                </div>
              `
            : "",
        )}
      </div>
    </div>

    <div class="flex flex-col gap-1.5">
      <label class="text-[11px] uppercase tracking-wider text-slate-500"
        >Notes</label
      >
      <textarea
        value=${notes}
        onInput=${(e) => setNotes(e.target.value)}
        rows="4"
        placeholder="Personal notes, approach, key insights…"
        class="px-3 py-2 bg-black border border-white/10 rounded-lg text-sm text-white placeholder-slate-600 focus:outline-none focus:border-cyan-500/50 resize-y font-sans"
      ></textarea>
    </div>

    <div class="flex items-center justify-between mt-1">
      <div>
        ${saved
          ? html`<span class="text-xs text-emerald-400"
              >✓ Saved successfully</span
            >`
          : ""}
        ${error
          ? html`<span class="text-xs text-rose-400">${error}</span>`
          : ""}
      </div>
      <button
        onClick=${save}
        disabled=${saving}
        class="px-4 py-2 bg-cyan-600/30 hover:bg-cyan-600/50 border border-cyan-500/30 text-cyan-300 text-xs rounded-lg transition-colors disabled:opacity-40"
      >
        ${saving ? "Saving…" : "Save changes"}
      </button>
    </div>

    <div class="border-t border-white/5 pt-4 mt-2">
      <p class="text-[10px] text-slate-600 mb-2">
        Danger zone — this removes the problem from your local database
        permanently.
      </p>
      ${confirmDelete
        ? html`
            <div class="flex items-center gap-2">
              <span class="text-xs text-rose-400">Are you sure?</span>
              <button
                onClick=${doDelete}
                disabled=${deleting}
                class="px-3 py-1.5 bg-rose-600/40 hover:bg-rose-600/60 border border-rose-500/30 text-rose-300 text-xs rounded-lg transition-colors disabled:opacity-40"
              >
                ${deleting ? "Deleting…" : "Yes, delete"}
              </button>
              <button
                onClick=${() => setConfirmDelete(false)}
                class="px-3 py-1.5 bg-white/5 hover:bg-white/10 border border-white/10 text-slate-400 text-xs rounded-lg transition-colors"
              >
                Cancel
              </button>
            </div>
          `
        : html`
            <button
              onClick=${() => setConfirmDelete(true)}
              class="px-3 py-1.5 bg-rose-600/10 hover:bg-rose-600/20 border border-rose-500/20 text-rose-400 text-xs rounded-lg transition-colors"
            >
              Delete problem
            </button>
          `}
    </div>
  </div>`;
}

function MethodCard({ method, methodIndex, problem, onUpdate }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [localReview, setLocalReview] = useState(method.aiReview || "");

  const handleGenerateReview = async () => {
    if (busy || !method.code) return;
    if (typeof chrome === "undefined" || !chrome.runtime?.id) {
      setError("Extension not available.");
      return;
    }
    setBusy(true);
    setError("");
    let keepAlivePort = null;
    let keepAliveTimer = null;
    try {
      keepAlivePort = chrome.runtime.connect({ name: "ai-review-keepalive" });
      keepAliveTimer = setInterval(() => {
        try {
          keepAlivePort?.postMessage({ type: "ping" });
        } catch (_) {}
      }, 20000);
    } catch (_) {}
    const release = () => {
      clearInterval(keepAliveTimer);
      try {
        keepAlivePort?.disconnect();
      } catch (_) {}
    };
    try {
      const result = await new Promise((resolve, reject) => {
        let settled = false;
        const timer = setTimeout(() => {
          if (settled) return;
          settled = true;
          release();
          reject(new Error("AI review timed out"));
        }, 90000);
        chrome.runtime.sendMessage(
          {
            type: "REGENERATE_AI_REVIEW",
            problem: {
              ...problem,
              code: method.code,
              lang: { name: method.language || problem.lang?.name },
              _methodIndex: methodIndex,
            },
          },
          (resp) => {
            if (settled) return;
            settled = true;
            clearTimeout(timer);
            release();
            if (chrome.runtime.lastError)
              reject(new Error(chrome.runtime.lastError.message));
            else if (resp?.ok) resolve(resp);
            else reject(new Error(resp?.error || "AI review failed"));
          },
        );
      });
      const methodReview =
        result.problem?.methods?.[methodIndex]?.aiReview || result.review || "";
      setLocalReview(methodReview);
      if (result.problem) onUpdate?.(result.problem);
    } catch (e) {
      setError(e.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  return html`<div class="border border-white/10 rounded-xl overflow-hidden">
    <div
      class="px-4 py-2.5 bg-white/[0.02] border-b border-white/5 flex items-center gap-3"
    >
      <span class="text-xs font-medium text-slate-300">
        ${method.title || `Approach ${methodIndex + 1}`}
      </span>
      ${method.language
        ? html`<span
            class="text-[10px] px-1.5 py-0.5 rounded bg-white/5 text-slate-500"
          >
            ${method.language}
          </span>`
        : ""}
      ${method.description
        ? html`<span
            class="text-[10px] text-slate-600 ml-auto truncate max-w-xs"
          >
            ${method.description}
          </span>`
        : ""}
    </div>
    <pre
      class="text-xs leading-relaxed overflow-x-auto bg-black/50 p-4 whitespace-pre font-mono m-0 max-h-96"
      dangerouslySetInnerHTML=${{
        __html: highlightCode(
          method.code || "// (no code)",
          (method.language || "").toLowerCase(),
        ),
      }}
    ></pre>
    <div class="border-t border-white/10 p-3">
      <${AIReviewPanel}
        review=${localReview}
        onGenerate=${handleGenerateReview}
        loading=${busy}
        error=${error}
      />
    </div>
  </div>`;
}

// ── Global tabs (Code, AI Review, Notes, Edit) registered for all platforms ──
// Platform-specific registrations (e.g. leetcode) override these by tab id.

modalTabRegistry.register("*", [
  {
    id: "code",
    label: "Code",
    show: (p) => !!p.code || p.platform === "leetcode",
    render(problem, { html, langName, copied, copyCode, onUpdate }) {
      return html`<${CodeTab}
        problem=${problem}
        langName=${langName}
        copied=${copied}
        copyCode=${copyCode}
        onUpdate=${onUpdate}
      />`;
    },
  },
  {
    id: "review",
    label: "AI Review",
    show: () => true,
    render(
      problem,
      { html, AIReviewPanel, onGenerateAIReview, reviewBusy, reviewError, onRemoveFromQueue, removeFromQueueBusy },
    ) {
      return html`<${AIReviewPanel}
        review=${problem.aiReview || ""}
        onGenerate=${onGenerateAIReview}
        loading=${reviewBusy}
        error=${reviewError}
        queueStatus=${queueStatus}
        queueError=${queueStatusError}
        onRunQueueNow=${handleRunAIReviewQueueNow}
        runQueueBusy=${queueActionBusy}
        onRemoveFromQueue=${onRemoveFromQueue}
        removeFromQueueBusy=${removeFromQueueBusy}
      />`;
    },
  },
  {
    id: "notes",
    label: "Notes",
    show: (p) => !!p?.notes,
    render(problem, { html }) {
      return html` <div class="prose prose-invert prose-sm max-w-none">
        <pre
          class="whitespace-pre-wrap text-sm text-slate-300 font-sans leading-relaxed"
        >
${problem.notes}</pre
        >
      </div>`;
    },
  },
  {
    id: "methods",
    label: (p) => `Methods (${p.methods?.length || 0})`,
    show: (p) => p.methods?.length > 0,
    render(problem, { html, onUpdate }) {
      return html`<div class="flex flex-col gap-4">
        ${(problem.methods || []).map(
          (method, i) =>
            html`<${MethodCard}
              key=${i}
              method=${method}
              methodIndex=${i}
              problem=${problem}
              onUpdate=${onUpdate}
            />`,
        )}
      </div>`;
    },
  },
  {
    id: "edit",
    label: "Edit",
    render(problem, { html, onUpdate, onDelete, onClose }) {
      return html`<${EditTab}
        problem=${problem}
        onUpdate=${onUpdate}
        onDelete=${onDelete}
        onClose=${onClose}
      />`;
    },
  },
]);
