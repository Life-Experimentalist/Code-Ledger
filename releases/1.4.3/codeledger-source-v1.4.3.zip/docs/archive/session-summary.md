# Session Summary

This file is an archived working log. The active backlog lives in [../reference/backlog.md](../reference/backlog.md), and the canonical release workflow lives in [../guides/RELEASE_GUIDE.md](../guides/RELEASE_GUIDE.md).
