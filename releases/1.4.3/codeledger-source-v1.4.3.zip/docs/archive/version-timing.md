# Version Timing (Legacy Note)

This file is kept only for older links. The canonical release docs are:

- Procedure: [../guides/RELEASE_GUIDE.md](../guides/RELEASE_GUIDE.md)
- Policy: [../guides/release-versioning.md](../guides/release-versioning.md)

Short answer:

- Update the version before release, not after.
- Keep [../../src/manifest.json](../../src/manifest.json) and [../../package.json](../../package.json) on the same version.
- Run `npm run release` or `npm run release -- --dry-run` first.
