#!/usr/bin/env node
import { exec } from "child_process";
import fs from "fs";
import path from "path";

const WATCH_DIRS = process.argv.slice(2).length
  ? process.argv.slice(2)
  : ["src", "worker"];
const debounceMs = 300;
let timer = null;

function runBuild() {
  console.log("Change detected — running dist-only build...");
  // Run lightweight build that only produces the `dist` folders (no packaging)
  const p = exec("node dev/build.js --dist-only", { cwd: process.cwd() });
  p.stdout.pipe(process.stdout);
  p.stderr.pipe(process.stderr);
}

for (const d of WATCH_DIRS) {
  const full = path.join(process.cwd(), d);
  if (!fs.existsSync(full)) continue;
  try {
    fs.watch(full, { recursive: true }, (ev, filename) => {
      if (!filename) return;
      clearTimeout(timer);
      timer = setTimeout(runBuild, debounceMs);
    });
    console.log("Watching", full);
  } catch (e) {
    console.warn("Failed to watch", full, e.message);
  }
}

console.log("Watcher started. Press Ctrl+C to exit.");
