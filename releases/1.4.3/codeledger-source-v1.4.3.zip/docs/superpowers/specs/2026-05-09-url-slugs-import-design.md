# Design: Platform Slugs + URL-ification + GitHub Import + Conflict UI

**Date:** 2026-05-09  
**Status:** Approved — proceeding to implementation plan

---

## 1. Platform-Scoped Problem IDs

### Problem
Two problems named "Two Sum" on LeetCode and GeeksForGeeks both get `titleSlug = "two-sum"`. When stored in IndexedDB (keyPath `"id"`), whichever is saved second overwrites the first. Same collision in the repo file tree, the URL `?problem=` param, and the `committedSlugLangs` map.

### Solution
`id = {platformCode}-{titleSlug}`

| Platform     | Code | Example ID         |
|--------------|------|--------------------|
| LeetCode     | `lc` | `lc-two-sum`       |
| GeeksForGeeks| `gfg`| `gfg-two-sum`      |
| Codeforces   | `cf` | `cf-1234a`         |

- `id` is the IDB primary key (already keyPath `"id"`) and the URL `?problem=` value  
- `titleSlug` remains the raw platform slug (e.g. `"two-sum"`) — unchanged field  
- `platform` remains `"leetcode"` / `"geeksforgeeks"` / `"codeforces"`  
- `canonicalId` (optional, from canonical-mapper) = `"two-sum"` — set when platforms agree

### Platform Code Helper (new in `constants.js`)
```js
PLATFORM_CODE: { leetcode: "lc", geeksforgeeks: "gfg", codeforces: "cf" }
```

And a pure function in `constants.js`:
```js
function makeProblemId(platform, titleSlug) {
  const code = CONSTANTS.PLATFORM_CODE[platform] || platform.slice(0,3);
  return `${code}-${titleSlug}`;
}
```

### File Path Impact
`path-builder.js` currently uses `titleSlug` as the folder name when no canonical is set. After this change it uses the full platform-scoped id:

- No canonical:  `problems/lc-two-sum/lc-two-sum.py`  
- With canonical: `problems/two-sum/leetcode/two-sum.py`  (unchanged)

`solutionPath(id, platform, lang, canonical, settings)` — first arg is now `id` (the platform-scoped slug).

### Data Migration (no IDB schema change needed)
Run in `MigrationManager` on startup (not IDB `onupgradeneeded`):

1. `getAllProblems()` — find records where `id` does not match `/^(lc|gfg|cf)-/`  
2. For each: compute new id, delete old record, insert with new id  
3. Migrate `committedSlugLangs` map: rekeyed to `{newId}::{lang}`  
4. Migration is idempotent (check for prefix before acting)

### Committed-slug tracking
`markSlugLangCommitted(id, langName)` and `isSlugLangCommitted(id, langName)` — rename param from `titleSlug` to `id`, use new platform-scoped id as the key.

---

## 2. URL-ification

### Goal
Every state the user can see is encodable in the URL so reload → same view.

### URL Param Schema

| Param           | Values                                      | View          |
|-----------------|---------------------------------------------|---------------|
| `tab`           | solutions, analytics, graph, settings, ...  | all           |
| `settingsTab`   | general, ai, git, platforms, backups, advanced | settings    |
| `problem`       | `lc-two-sum`                                | modal (any)   |
| `q`             | any string                                  | solutions     |
| `difficulty`    | Easy, Medium, Hard                          | solutions     |
| `platform`      | leetcode, geeksforgeeks, codeforces         | solutions     |
| `language`      | py, js, cpp, …                              | solutions     |
| `sort`          | newest, oldest, difficulty, title, …        | solutions     |
| `tag`           | dynamic-programming, …                      | solutions     |
| `section`       | heatmap, language, difficulty, platform, topic, velocity | analytics |
| `sectionFilter` | the specific value (python, Hard, leetcode, 2026-05-09) | analytics |
| `graphLayout`   | layered, circular, force                    | graph         |

### Changes per file

**`SettingsPageView.js`**  
- Init `activePanel` from `getQueryParam("settingsTab", "general")`  
- On tab click: `updateQueryParams({ settingsTab: id })`

**`ProblemsView.js`** (already passes `filtered` to modal — no list fix needed)  
- Init filter state from URL params (`difficulty`, `platform`, `language`, `sort`, `tag`)  
- On every filter change: `updateQueryParams({ difficulty, platform, language, sort, tag })`  
- On search: already uses `q` — no change needed

**`AnalyticsView.js`**  
- On drill-down open: `updateQueryParams({ section, sectionFilter })`  
- On drill-down close: `updateQueryParams({ section: null, sectionFilter: null, problem: null })`  
- On mount: restore drill-down from `section` + `sectionFilter` params  
- When a problem is opened from drill-down: `updateQueryParams({ problem: p.id })`

**`GraphView.js`**  
- Init layout from `getQueryParam("graphLayout", "layered")`  
- On layout change: `updateQueryParams({ graphLayout })`  
- On problem modal open: `updateQueryParams({ problem: p.id })`  
- Pass **view-filtered** problem list to `ProblemModal` (filter by active graph filters)

**`library.js`**  
- `?problem=` restoration: search `enrichedProblems` by `p.id === slug` first, then `p.titleSlug === slug` (backwards compat)

---

## 3. Modal List Context + Keyboard Navigation

### List Scoping Rules
| Source              | List passed to ProblemModal          |
|---------------------|--------------------------------------|
| ProblemsView        | `filtered` (already correct)         |
| GraphView           | graph-filtered problems only         |
| Analytics drill-down| `drilldown.problems` (already scoped) |
| Analytics "View problems" button | the full drill-down list |

### Keyboard Navigation
`ProblemModal` already has prev/next buttons (`onNavigateProblem`). Add:
- `useEffect` on mount: listen for `keydown` — `ArrowLeft` → prev, `ArrowRight` → next  
- Cleanup listener on unmount  
- Only fires when modal is open (component mounted)

### Analytics "View Problems" Button
Each analytics drill-down panel gets a `View N problems →` button (bottom-right of the panel).  
Clicking opens `ProblemModal` with:
- `problem = drilldown.problems[0]`  
- `problemList = drilldown.problems`  
- `onNavigateProblem` cycles within the list  
- URL updates: `?problem={id}`  

This is the same ProblemModal used everywhere — no new modal component.

---

## 4. GitHub Repo Import + Sync Engine

### Trigger Points
1. **Mandatory during onboarding** — when `linkExistingRepo()` finds an existing `index.json`, import must complete before user reaches the "done" step  
2. **Manual** — "Import from GitHub" button in PanelGit (for re-importing or syncing after changes made outside the extension)  
3. **Periodic sync** — `SyncEngine.performSync()` (currently stub, now real)

### Import Algorithm (`importFromRepo(owner, repo, token)`)
New function in `sync-engine.js`:

```
1. Fetch /repos/{owner}/{repo}/contents/index.json → decode base64 → parse
2. remoteProblems = index.problems  (ensure each has valid platform-scoped id)
3. localProblems  = await Storage.getAllProblems()
4. Categorise:
   - remoteOnly:  id in remote, not in local → safe to insert
   - localOnly:   id in local,  not in remote → safe (already there)
   - conflicts:   id in both, but fields differ (compare JSON)
5. If conflicts.length > 0 → return { remoteOnly, conflicts } to caller (UI shows ConflictResolutionModal)
6. If no conflicts → bulk-insert remoteOnly, return { imported: remoteOnly.length }
7. After resolution: bulk-insert accepted problems
```

Conflict comparison key fields: `title`, `code`, `difficulty`, `tags`, `lang`, `aiReview`  
(timestamps and `id` are excluded from conflict detection)

### SyncEngine.performSync() — real implementation
```
1. importFromRepo(owner, repo, token)
2. If conflicts → push notification "X conflicts detected, visit Git settings to resolve"
3. Else → silently merge remoteOnly into local
4. Also push any localOnly problems that aren't yet in the remote (via git commit)
```

---

## 5. ConflictResolutionModal

### New component: `src/library/components/ConflictResolutionModal.js`

**Props:**
```js
{
  conflicts:    Array<{ local: Problem, remote: Problem }>,
  remoteOnly:   Problem[],   // will be auto-imported after resolution
  onResolve:    (resolved: Problem[]) => void,
  onCancel:     () => void,
  providerName: string,      // "GitHub", "GitLab", etc.
}
```

**UI:**
- Header: "Import from {providerName} — {n} conflict(s)"  
- Progress indicator: "X of N resolved"  
- For each conflict, one row:  
  - Left column: local version (fields: title, difficulty, lang, code snippet, timestamp)  
  - Right column: remote version (same fields)  
  - Highlighted diffs between columns  
  - 3 buttons per row: **Keep Local** / **Keep Remote** / **Keep Both** (only if lang differs)  
- Footer: **Accept All Remote** | **Accept All Local** bulk shortcuts, then **Apply** button (disabled until all resolved)  
- Auto-imports `remoteOnly` problems after Apply (no user action needed for those)

**Keep Both:** allowed when `local.lang.slug !== remote.lang.slug` — stores both as separate records under the same `id` with lang suffix... actually no. "Keep both" only makes sense when they're truly different languages. In that case both records exist independently already (different `id` because id = `{platformCode}-{slug}` and different lang is a different file, not a different record). So "Keep both" = keep both records → import remote alongside local.

Actually wait: two solutions for the same problem + platform but different languages would have the SAME `id` (e.g., `lc-two-sum`). The current schema stores one record per problem (single code field). If someone has both Python and JavaScript solutions for the same LeetCode problem, they'd need separate records.

Resolution: the `id` for multi-language support should be `{platformCode}-{titleSlug}-{langSlug}`. But this is a further change. For now: conflicts are per `id` (one record per platform+problem). "Keep Both" is not applicable since same id = same problem. Remove "Keep Both" option.

**Revised:** Just **Keep Local** / **Keep Remote** per conflict row.

---

## 6. OPENAPI.yaml Update

Add an **Extension URL Scheme** section as a comment appendix to `docs/OPENAPI.yaml`. This documents the browser extension's internal URL params (not HTTP endpoints — as an `x-extension-urls` extension field).

---

## Implementation Order

1. **Constants + makeProblemId** — add `PLATFORM_CODE` map and `makeProblemId()` to `constants.js`  
2. **Platform handlers** — update LeetCode, GFG, CF handlers to set `id = makeProblemId(platform, titleSlug)`  
3. **Data migration** — add `migrateProblemIds()` to `migration-manager.js`, call on app startup  
4. **path-builder.js** — update `solutionPath` and `problemBase` to use `id` (platform-scoped slug) when no canonical  
5. **Storage** — update `markSlugLangCommitted` / `isSlugLangCommitted` to accept `id`  
6. **URL-ification: Settings** — `SettingsPageView.js` reads `settingsTab` on mount  
7. **URL-ification: Solutions filters** — `ProblemsView.js` syncs filters to/from URL  
8. **URL-ification: Analytics** — `AnalyticsView.js` syncs section + sectionFilter  
9. **URL-ification: Graph** — `GraphView.js` syncs layout, passes filtered list to modal  
10. **Keyboard nav in ProblemModal** — add ←/→ keydown listener  
11. **Analytics "View problems" button** — add to each drill-down panel  
12. **ConflictResolutionModal** — new component  
13. **importFromRepo()** — implement in `sync-engine.js`  
14. **SyncEngine.performSync()** — implement real sync  
15. **GitHubOnboardingModal** — make import mandatory when `index.json` found  
16. **PanelGit** — add "Import from GitHub" manual button  
17. **OPENAPI.yaml** — add extension URL scheme appendix  
