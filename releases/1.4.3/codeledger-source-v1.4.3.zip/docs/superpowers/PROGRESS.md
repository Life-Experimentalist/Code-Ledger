# Feature Progress — URL-ification + GitHub Import

## Status: Design / Brainstorming

---

## Features In Scope

### A. URL-ification (full deep-linking)
- Settings tabs persist in URL (`?tab=settings&settingsTab=git`)
- Every modal openable by URL param (`?problem=two-sum`, `?modal=calendar&date=2026-05-09`)
- Analytics drill-down panels URL-tracked
- Graph modal URL-tracked
- All left/right modal navigation scoped to current filtered list

### B. Modal List Context
- ProblemsView: already correct (passes `filtered`)
- GraphView: passes full list — needs to pass view-filtered list
- AnalyticsView: scopes correctly when drill-down opens problem, needs URL persistence
- All analytics section modals (calendar heatmap, frequency dist, etc.) need URL state

### C. GitHub Repo Import (new)
- On first connect to a repo that has CodeLedger data (`index.json` present), import all problems into local IndexedDB
- If local also has problems: **pending clarification on merge strategy**
- After import, offer to reorganize/reformat repo if structure is outdated
- sync-engine.js is currently a stub — needs real implementation

### D. Docs Cleanup ✅
- Removed from git: FINAL_RELEASE_SUMMARY, LAUNCH_COMPLETE, PRE_LAUNCH_CHECKLIST, RELEASE_QUICK_START, LINKEDIN_POST, DEBUG_COMMIT_ON_ACCEPT, PROGRESS, VERSION_TIMING, NEXT_PHASE_ROADMAP
- Added to .gitignore

---

## Open Questions
- [ ] **Q1**: Merge strategy when both local + remote have problems?
- [ ] **Q2**: Should analytics drill-down panels become proper modals or stay inline with URL state?
- [ ] **Q3**: What URL params should identify each analytics section? (heatmap, freq-dist, etc.)

---

## Implementation Order (tentative)
1. Settings tab URL persistence (small, isolated)
2. Modal list context fixes (GraphView + AnalyticsView)
3. Analytics URL state
4. GitHub repo import + sync-engine
5. OPENAPI.yaml update (extension URL scheme appendix)
