# Superpowers

Planning notes and specs for long-running or experimental work.

## Files
- [Progress](PROGRESS.md)
- [Plans](plans/)
- [Specs](specs/)
