# CodeLedger Comprehensive Overhaul — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Refactor problem storage to a flat canonical-slug structure, harden the GitHub commit pipeline, make the problem modal platform-agnostic with a tab registry, fix graph filtering/layout, abstract the platform timer, and clean up dead code across the codebase.

**Architecture:** A new `src/core/path-builder.js` module centralises all path computation and is the single source-of-truth for where files live in the repository. A `src/core/modal-tab-registry.js` module lets every platform handler register its own modal tabs so `ProblemModal` is a pure renderer with no platform-specific logic. A `src/core/platform-timer.js` module decides whether to read a native timer or inject the custom floating timer, so timer logic is never inside individual handlers.

**Tech Stack:** Vanilla ES6 modules, Preact + htm (CDN re-export via `src/vendor/preact-bundle.js`), GitHub Trees API (atomic commits), Chrome extension APIs via `src/lib/browser-compat.js`, Canvas 2D (graph), IndexedDB via `src/core/storage.js`.

---

## File Map

### New files
| Path                                            | Purpose                                                     |
| ----------------------------------------------- | ----------------------------------------------------------- |
| `src/core/path-builder.js`                      | Canonical problem path computation — single source of truth |
| `src/core/modal-tab-registry.js`                | Platform tab registration for ProblemModal                  |
| `src/core/platform-timer.js`                    | Timer abstraction (native vs floating)                      |
| `src/handlers/platforms/leetcode/modal-tabs.js` | LeetCode-specific modal tab definitions                     |
| `docs/FEATURE_REQUESTS_COMPLETED.md`            | Archive of completed features                               |
| `docs/PROGRESS.md`                              | Live project progress tracker                               |

### Modified files
| Path                                            | Changes                                                             |
| ----------------------------------------------- | ------------------------------------------------------------------- |
| `src/core/constants.js`                         | Add `PROBLEMS_DIR_DEFAULT`, `COMMIT_TYPE` enum                      |
| `src/core/knowledge-graph.js`                   | Remove topic-topic ring edges                                       |
| `src/core/storage.js`                           | Add `getProblemPath()`, `setProblemPath()` for path tracking        |
| `src/background/service-worker.js`              | Update `getProblemFiles()` to use path-builder; add rename logic    |
| `src/handlers/_base/BasePlatformHandler.js`     | Add `getNativeElapsed()` stub (returns `null`)                      |
| `src/handlers/platforms/leetcode/index.js`      | Use path-builder, register modal tabs, remove timer injection       |
| `src/handlers/platforms/geeksforgeeks/index.js` | Use path-builder, remove direct timer import                        |
| `src/handlers/platforms/codeforces/index.js`    | Use path-builder, remove direct timer import                        |
| `src/handlers/git/github/index.js`              | Add `DELETE` tree items for path renames; maintenance commit helper |
| `src/library/components/ProblemModal.js`        | Use tab registry; remove hardcoded platform tabs                    |
| `src/library/views/GraphView.js`                | Fix filter (skip topic-topic in edge walk); fix single-topic layout |
| `src/content/handler-loader.js`                 | Inject timer via platform-timer after `handler.init()`              |
| `src/ui/components/SettingsSchema.js`           | Add `problems_dir` text field under GitHub section                  |
| `docs/FEATURE_REQUESTS.md`                      | Keep only in-progress + pending; move completed to archive          |

---

## Task 1: Create `src/core/path-builder.js`

**Files:**
- Create: `src/core/path-builder.js`

This module is the single source of truth for where a problem's files live. All other code that builds file paths imports from here.

**Rules:**
- Problems with a resolved canonical ID → `{root}/{canonicalId}/{platform}/{LangVerbose}.{ext}` + `{root}/{canonicalId}/README.md`
- Problems WITHOUT a canonical ID → `{root}/{slug}/{LangVerbose}.{ext}` + `{root}/{slug}/README.md` (no platform subdir)
- `root` defaults to `"problems"`, overridable via `settings.problems_dir`

- [ ] **Step 1: Create the file**

```js
// src/core/path-builder.js
/**
 * Centralised problem-path computation.
 *
 * Directory layout:
 *   With canonical:    {root}/{canonicalId}/{platform}/{Lang}.{ext}
 *   Without canonical: {root}/{slug}/{Lang}.{ext}          (no platform subdir)
 *   README always at:  {root}/{dir}/README.md
 */

export function problemBase(titleSlug, canonical, settings = {}) {
  const root = (settings?.problems_dir || "problems").replace(/\/+$/, "");
  const dir  = canonical?.canonicalId || titleSlug;
  return `${root}/${dir}`;
}

export function solutionPath(titleSlug, platform, lang, canonical, settings = {}) {
  const base     = problemBase(titleSlug, canonical, settings);
  const filename = `${(lang.verbose || lang.name || "Solution").replace(/\s+/g, "_")}.${lang.ext || "txt"}`;
  if (canonical?.canonicalId) {
    return `${base}/${platform}/${filename}`;
  }
  return `${base}/${filename}`;
}

export function readmePath(titleSlug, canonical, settings = {}) {
  return `${problemBase(titleSlug, canonical, settings)}/README.md`;
}

export function hintsPath(titleSlug, canonical, settings = {}) {
  return `${problemBase(titleSlug, canonical, settings)}/hints.md`;
}

/**
 * Build the complete file list for a solved problem.
 * Mirrors the shape used by service-worker getProblemFiles().
 *
 * @param {object} problem  — stored problem record
 * @param {object} settings — user settings
 * @returns {Array<{path: string, content: string}>}
 */
export function buildProblemFiles(problem, settings = {}) {
  const canonical = problem.canonical || null;
  const lang = problem.lang || { verbose: "Solution", name: "solution", ext: "txt" };
  const verbose = lang.verbose || lang.name || "Solution";
  const ext = lang.ext || "txt";
  const normalLang = { verbose, name: lang.name || verbose, ext };

  const files = [];

  if (problem.code) {
    files.push({
      path: solutionPath(problem.titleSlug || problem.id, problem.platform, normalLang, canonical, settings),
      content: problem.code,
    });
  }

  if (problem.readmeContent) {
    files.push({
      path: readmePath(problem.titleSlug || problem.id, canonical, settings),
      content: problem.readmeContent,
    });
  }

  return files;
}

/**
 * Given an old stored path prefix (old base dir) and new base dir,
 * returns the new path for any file at oldPath.
 * Used during canonical-ID reassignment to compute rename targets.
 *
 * @param {string} oldPath   — e.g. "problems/two-sum/Python3.py"
 * @param {string} oldBase   — e.g. "problems/two-sum"
 * @param {string} newBase   — e.g. "problems/two-sum/leetcode"
 * @returns {string}
 */
export function rebasePath(oldPath, oldBase, newBase) {
  if (!oldPath.startsWith(oldBase + "/")) return oldPath;
  const rel = oldPath.slice(oldBase.length + 1); // strip "problems/two-sum/"
  return `${newBase}/${rel}`;
}
```

- [ ] **Step 2: Commit**

```bash
git add src/core/path-builder.js
git commit -m "feat: add path-builder module — canonical-slug flat storage structure"
```

---

## Task 2: Update `constants.js` — add `PROBLEMS_DIR_DEFAULT` and commit type

**Files:**
- Modify: `src/core/constants.js`

- [ ] **Step 1: Add two new constants**

In `src/core/constants.js`, inside the `CONSTANTS` object, add after `COMMIT_MESSAGE_TEMPLATE`:

```js
  PROBLEMS_DIR_DEFAULT: "problems",

  // Commit type markers — added to commit messages to distinguish maintenance from solves.
  COMMIT_TYPE: {
    SOLVE:       "solve",       // normal problem commit
    MAINTENANCE: "maintenance", // canonical rename, infra recovery, metadata update
    IMPORT:      "import",      // bulk import
  },
```

- [ ] **Step 2: Commit**

```bash
git add src/core/constants.js
git commit -m "feat(constants): add PROBLEMS_DIR_DEFAULT and COMMIT_TYPE enum"
```

---

## Task 3: Update `service-worker.js` — use path-builder for file paths

**Files:**
- Modify: `src/background/service-worker.js` (top imports + `getProblemFiles` function)

The current `getProblemFiles` builds paths as `topics/{topic}/{titleSlug}/{lang}.{ext}`. Replace this with `buildProblemFiles` from path-builder.

- [ ] **Step 1: Add import at top of service-worker.js**

After the last existing import line add:
```js
import { buildProblemFiles } from "../core/path-builder.js";
```

- [ ] **Step 2: Replace `getProblemFiles` function**

Find and replace the entire `getProblemFiles` function (currently lines 43-55):

```js
function getProblemFiles(problem = {}, settings = {}) {
  // Delegate entirely to path-builder — the single source of truth.
  const files = buildProblemFiles(problem, settings);
  if (files.length > 0) return files;

  // Fallback for legacy records that lack readmeContent/code on the object.
  // This keeps pre-migration records committable.
  if (problem.code) {
    const lang = problem.lang || { verbose: "Solution", name: "solution", ext: "txt" };
    const canonical = problem.canonical || null;
    const slug = problem.titleSlug || String(problem.id || "unknown");
    const root = (settings?.problems_dir || "problems").replace(/\/+$/, "");
    const dir  = canonical?.canonicalId || slug;
    const verbose = (lang.verbose || lang.name || "Solution").replace(/\s+/g, "_");
    const ext = lang.ext || "txt";
    const filePath = canonical?.canonicalId
      ? `${root}/${dir}/${problem.platform}/${verbose}.${ext}`
      : `${root}/${dir}/${verbose}.${ext}`;
    return [{ path: filePath, content: problem.code }];
  }
  return [];
}
```

- [ ] **Step 3: Pass settings into getProblemFiles calls in handleSolved**

In `handleSolved`, the call at line ~170 is `getProblemFiles(p)`. Change all calls to pass settings:
```js
// Before:
const filesToCommit = [];
for (const p of pendingProblems) {
  for (const f of getProblemFiles(p)) {

// After:
const filesToCommit = [];
for (const p of pendingProblems) {
  for (const f of getProblemFiles(p, settings)) {
```

Do the same in `handleResyncAll` (two occurrences).

- [ ] **Step 4: Remove `handleLeetCodeImport` dead function**

Delete the entire `handleLeetCodeImport` function (lines ~256-299) — it was superseded by the content-script profile import. Also remove the `LEETCODE_IMPORT` message handler that calls it (lines ~495-502).

- [ ] **Step 5: Commit**

```bash
git add src/background/service-worker.js
git commit -m "refactor(service-worker): use path-builder for file paths; remove dead handleLeetCodeImport"
```

---

## Task 4: Update LeetCode handler — use path-builder in `_buildFileSet`

**Files:**
- Modify: `src/handlers/platforms/leetcode/index.js`

- [ ] **Step 1: Add path-builder import near the top of leetcode/index.js**

After the existing imports add:
```js
import { solutionPath, readmePath, hintsPath } from "../../../core/path-builder.js";
```

- [ ] **Step 2: Replace `_buildFileSet` method**

Replace the entire `_buildFileSet` method with:

```js
_buildFileSet(submission, meta, settings, slug, elapsedSeconds = null) {
  const lang      = resolveLang(submission.lang);
  const topicTags = meta?.topicTags?.map?.(t => t?.name).filter(Boolean) || [];
  const canonical = this._canonical || null;  // populated by _processSubmission after resolve

  const files = [];

  // 1. Solution file
  files.push({
    path: solutionPath(slug, "leetcode", lang, canonical, settings),
    content: submission.code || "// (no code retrieved)",
  });

  // 2. README
  if (settings.leetcode_readme !== false && meta?.content) {
    const stats   = this._formatStats(submission, meta, elapsedSeconds);
    const similar = this._formatSimilar(meta, settings);
    const hints   = this._formatHints(meta, settings);
    const title   = meta?.title || slug;
    files.push({
      path: readmePath(slug, canonical, settings),
      content: [
        `# ${meta.questionFrontendId ? `[${meta.questionFrontendId}] ` : ""}${title}`,
        "",
        `**Difficulty:** ${meta.difficulty || "?"}  |  **Acceptance:** ${meta.acRate ? meta.acRate.toFixed(1) + "%" : "?"}  |  **Likes:** ${meta.likes ?? "?"} / **Dislikes:** ${meta.dislikes ?? "?"}`,
        "",
        `**Tags:** ${(meta.topicTags || []).map(t => `\`${t.name}\``).join(", ") || "—"}`,
        "",
        "## Problem",
        "",
        meta.content
          .replace(/<[^>]+>/g, "")
          .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&")
          .replace(/&#39;/g, "'").replace(/&quot;/g, '"')
          .replace(/\n{3,}/g, "\n\n")
          .trim(),
        "",
        stats,
        similar,
        hints,
      ].filter(Boolean).join("\n"),
    });
  }

  // 3. Hints file (optional)
  if (settings.leetcode_sync_hints && meta?.hints?.length) {
    const title = meta?.title || slug;
    files.push({
      path: hintsPath(slug, canonical, settings),
      content: [
        `# Hints — ${title}`,
        "",
        ...meta.hints.map((h, i) => `### Hint ${i + 1}\n\n${h}\n`),
      ].join("\n"),
    });
  }

  return files;
}
```

- [ ] **Step 3: Expose `_canonical` in `_processSubmission`**

In `_processSubmission`, after the canonical resolve line:
```js
const canonical = canonicalMapper.resolve("leetcode", slug);
```
Add:
```js
this._canonical = canonical; // stored for _buildFileSet
```

- [ ] **Step 4: Include `readmeContent` in the `problem:solved` payload**

In `_processSubmission`, find the `eventBus.emit("problem:solved", { ... })` call. The `files` array already contains the README content. Additionally, set `readmeContent` so the service-worker's fallback path can access it:

After building `files`:
```js
const readmeFile = files.find(f => f.path.endsWith("README.md"));
```

And in the emit payload add:
```js
readmeContent: readmeFile?.content || null,
canonical: canonical ? { id: canonical.canonicalId, title: canonical.canonicalTitle } : null,
```

- [ ] **Step 5: Commit**

```bash
git add src/handlers/platforms/leetcode/index.js
git commit -m "refactor(leetcode): use path-builder for _buildFileSet"
```

---

## Task 5: Update GFG and Codeforces handlers — use path-builder

**Files:**
- Modify: `src/handlers/platforms/geeksforgeeks/index.js`
- Modify: `src/handlers/platforms/codeforces/index.js`

Both handlers currently build paths inline (e.g. `topics/${topic}/${slug}/`). Find the file-building code in each and replace with path-builder calls.

- [ ] **Step 1: GFG — add import and update emit payload**

In `src/handlers/platforms/geeksforgeeks/index.js` add:
```js
import { solutionPath, readmePath } from "../../../core/path-builder.js";
```

Find the `problem:solved` emit in GFG. Locate where `files` is built. Replace the inline path string with:
```js
// In the GFG handler, wherever it builds the file list (search for "topics/" in the file):
const settings = await Storage.getSettings();
const canonical = canonicalMapper.resolve("geeksforgeeks", slug);
const langObj = { verbose: langVerbose, name: langVerbose, ext };
const files = [
  {
    path: solutionPath(slug, "geeksforgeeks", langObj, canonical, settings),
    content: code,
  },
];
// Add README only if problemStatement is available
if (problemStatement) {
  files.push({
    path: readmePath(slug, canonical, settings),
    content: `# ${title}\n\n**Difficulty:** ${difficulty}\n\n## Problem\n\n${problemStatement}`,
  });
}
```

Also add `canonical` and `readmeContent` to the emit payload.

- [ ] **Step 2: Codeforces — same pattern**

In `src/handlers/platforms/codeforces/index.js`, apply the same pattern: add the import, replace inline path building with `solutionPath()` / `readmePath()`, and add `canonical` + `readmeContent` to emit.

- [ ] **Step 3: Commit**

```bash
git add src/handlers/platforms/geeksforgeeks/index.js src/handlers/platforms/codeforces/index.js
git commit -m "refactor(handlers): use path-builder for GFG and Codeforces file paths"
```

---

## Task 6: GitHub handler — canonical rename + maintenance commits

**Files:**
- Modify: `src/handlers/git/github/index.js`

When a problem's canonical ID changes (or is assigned for the first time), the files must move atomically in a single commit: delete old paths, create at new paths.

The rename is triggered when `problem.canonical` is set but the stored `problem._storedBasePath` differs from what path-builder would compute today.

- [ ] **Step 1: Add rename-detection to `service-worker.js`**

In `service-worker.js`, in `handleSolved`, after `Storage.saveProblem(data)` add:

```js
// Detect if canonical path changed since last commit — schedule rename commit
const storedPath = data._storedBasePath;
if (storedPath && data.canonical?.id) {
  const expectedBase = problemBase(data.titleSlug, data.canonical, settings);
  if (storedPath !== expectedBase) {
    await Storage.markRenameNeeded(data.id, { oldBase: storedPath, newBase: expectedBase });
  }
}
```

Add the `Storage.markRenameNeeded` method (see Task 6 Step 4).

- [ ] **Step 2: Add `DELETE` tree items to GitHub commit**

In `src/handlers/git/github/index.js`, update `commit()` to accept an optional `deletes` array in opts:

```js
async commit(files, message, repoName, opts = {}) {
  // ... existing code to get token, owner, name, branch, latestCommitSha ...

  // Build tree: updates first
  const treeItems = files.map((f) => ({
    path: f.path,
    mode: "100644",
    type: "blob",
    content: f.content,
  }));

  // Add deletions: sha: null removes the file from the tree
  if (Array.isArray(opts.deletes)) {
    for (const delPath of opts.deletes) {
      treeItems.push({ path: delPath, mode: "100644", type: "blob", sha: null });
    }
  }

  // ... rest of existing commit code unchanged ...
}
```

- [ ] **Step 3: Add `performRenames` function to service-worker**

In `service-worker.js`, add a new async function after `handleSolved`:

```js
/**
 * Performs pending canonical renames as a single maintenance commit.
 * Called after a normal solve commit completes, or on periodic sync.
 */
async function performPendingRenames() {
  const renames = await Storage.getPendingRenames().catch(() => ([]));
  if (!renames.length) return;

  const settings = await Storage.getSettings();
  const git = registry.getGitProvider(settings.gitProvider || "github");
  if (!git) return;
  const token = await git.getToken().catch(() => null);
  if (!token) return;

  // For each rename: list files at oldBase, create at newBase, delete old
  const filesToAdd = [];
  const pathsToDelete = [];

  for (const r of renames) {
    // Fetch old files from GitHub
    try {
      const owner = settings.github_owner || (await git.apiFetch("/user", token)).login;
      const repo  = (settings.github_repo || "CodeLedger-Sync").replace(/\s+/g, "-");
      const tree  = await git.apiFetch(
        `/repos/${owner}/${repo}/git/trees/main?recursive=1`, token
      );
      const relevant = (tree.tree || []).filter(f =>
        f.type === "blob" && f.path.startsWith(r.oldBase + "/")
      );
      for (const f of relevant) {
        const newPath = f.path.replace(r.oldBase, r.newBase);
        // Fetch blob content
        const blob = await git.apiFetch(`/repos/${owner}/${repo}/git/blobs/${f.sha}`, token);
        const content = atob((blob.content || "").replace(/\n/g, ""));
        filesToAdd.push({ path: newPath, content });
        pathsToDelete.push(f.path);
      }
    } catch (e) {
      coreDebug.warn("Rename preflight failed for", r.oldBase, e.message);
    }
  }

  if (!filesToAdd.length && !pathsToDelete.length) {
    await Storage.clearPendingRenames();
    return;
  }

  try {
    const repo = (settings.github_repo || "CodeLedger-Sync").replace(/\s+/g, "-");
    await git.commit(
      filesToAdd,
      `chore: reorganise ${renames.length} problem(s) to canonical paths [maintenance]`,
      repo,
      { deletes: pathsToDelete }
    );
    await Storage.clearPendingRenames();
    coreDebug.log("Canonical renames committed:", renames.length);
  } catch (e) {
    coreDebug.error("Rename commit failed:", e.message);
  }
}
```

Call `performPendingRenames()` at the end of a successful `handleSolved` commit block (fire-and-forget):
```js
performPendingRenames().catch(() => {});
```

- [ ] **Step 4: Add rename storage helpers to `storage.js`**

In `src/core/storage.js`, add after the existing `clearPendingProblemKeys` method:

```js
async markRenameNeeded(id, { oldBase, newBase }) {
  const all = await this._getRenames();
  const filtered = all.filter(r => r.id !== id);
  filtered.push({ id, oldBase, newBase, ts: Date.now() });
  await browserStorage.local.set({ "cl.renames": JSON.stringify(filtered) });
},

async getPendingRenames() {
  return this._getRenames();
},

async clearPendingRenames() {
  await browserStorage.local.set({ "cl.renames": "[]" });
},

async _getRenames() {
  const raw = await browserStorage.local.get("cl.renames");
  try { return JSON.parse(raw["cl.renames"] || "[]"); } catch { return []; }
},
```

- [ ] **Step 5: Commit**

```bash
git add src/handlers/git/github/index.js src/background/service-worker.js src/core/storage.js
git commit -m "feat(github): canonical rename pipeline — atomic delete+create on canonical ID assignment"
```

---

## Task 7: Add `problems_dir` setting to SettingsSchema

**Files:**
- Modify: `src/ui/components/SettingsSchema.js`

- [ ] **Step 1: Add the field**

In the GitHub section fields array (after `github_pages`), add:

```js
{
  key: "problems_dir",
  label: "Problems root directory",
  type: "text",
  default: "problems",
  description: "Root folder inside your repo where solutions are stored. Default: problems",
  advanced: true,
  placeholder: "problems",
},
```

- [ ] **Step 2: Commit**

```bash
git add src/ui/components/SettingsSchema.js
git commit -m "feat(settings): add configurable problems_dir setting"
```

---

## Task 8: Create `src/core/modal-tab-registry.js`

**Files:**
- Create: `src/core/modal-tab-registry.js`

- [ ] **Step 1: Create the registry**

```js
// src/core/modal-tab-registry.js
/**
 * Platform-agnostic modal tab registry.
 *
 * Usage (in a platform handler or handler init):
 *   import { modalTabRegistry } from "../../../core/modal-tab-registry.js";
 *   modalTabRegistry.register("leetcode", [
 *     { id: "overview", label: "Overview", always: true, render: (problem, ctx) => html`...` },
 *     { id: "code", label: "Code", show: (p) => !!p.code, render: (problem, ctx) => html`...` },
 *   ]);
 *
 * Tab definition shape:
 *   id:     string            — unique tab identifier
 *   label:  string | fn(p)   — tab button text (can be a function for dynamic labels)
 *   show:   fn(problem)       — return false to hide this tab (optional, defaults to always show)
 *   render: fn(problem, ctx)  — returns htm template string
 *
 * ctx shape (passed to render):
 *   { html, useState, useEffect, isExtension, onClose, onUpdate, onDelete }
 */

class ModalTabRegistry {
  constructor() {
    this._tabs = new Map(); // platform → [{id, label, show, render}]
  }

  /**
   * Register tabs for a platform.
   * Use platform = "*" for tabs that appear on all platforms.
   * Platform-specific tabs are appended after global "*" tabs.
   */
  register(platform, tabs) {
    this._tabs.set(platform, tabs);
  }

  /**
   * Return the resolved tab list for a problem.
   * Order: global "*" tabs first, then platform-specific tabs.
   * Tabs with show(problem) === false are excluded.
   */
  getTabs(platform, problem) {
    const global   = this._tabs.get("*")   || [];
    const specific = this._tabs.get(platform) || [];
    const all = [...global, ...specific];
    return all.filter(tab => !tab.show || tab.show(problem));
  }

  /** Return a tab's render function by id and platform. */
  getRenderer(platform, tabId) {
    const global   = this._tabs.get("*")   || [];
    const specific = this._tabs.get(platform) || [];
    const all = [...global, ...specific];
    return all.find(t => t.id === tabId)?.render || null;
  }
}

export const modalTabRegistry = new ModalTabRegistry();
```

- [ ] **Step 2: Commit**

```bash
git add src/core/modal-tab-registry.js
git commit -m "feat: add modal tab registry for platform-agnostic ProblemModal tabs"
```

---

## Task 9: Create LeetCode modal tabs module

**Files:**
- Create: `src/handlers/platforms/leetcode/modal-tabs.js`

Move all LeetCode-specific tab rendering logic out of `ProblemModal.js` and into this handler file. `ProblemModal.js` will import `modalTabRegistry` and call `getTabs(problem.platform, problem)` instead of its current hardcoded tab list.

- [ ] **Step 1: Create `modal-tabs.js`**

```js
// src/handlers/platforms/leetcode/modal-tabs.js
import { modalTabRegistry } from "../../../core/modal-tab-registry.js";

const IS_EXTENSION = !!globalThis.chrome?.runtime?.id;

modalTabRegistry.register("leetcode", [
  {
    id: "overview",
    label: "Overview",
    always: true,
    render(problem, { html, onRefresh, refreshing }) {
      return html`
        <div class="flex flex-col gap-4">
          ${problem.problemStatement ? html`
            <div
              class="text-sm text-slate-300 leading-relaxed lc-content"
              dangerouslySetInnerHTML=${{ __html: problem.problemStatement }}
            ></div>
          ` : html`
            <div class="flex flex-col items-center justify-center py-8 gap-3 text-center">
              <span class="text-2xl">📄</span>
              <p class="text-slate-400 text-sm">No problem statement cached locally.</p>
              <div class="flex gap-2 mt-3">
                <a href=${"https://leetcode.com/problems/" + problem.titleSlug + "/"} target="_blank" rel="noopener"
                   class="text-xs text-cyan-400 hover:text-cyan-300">Open LeetCode ↗</a>
                <button
                  onClick=${onRefresh}
                  disabled=${refreshing}
                  class="text-[10px] px-3 py-1.5 rounded font-medium transition-all ${refreshing
                    ? "bg-blue-500/20 text-blue-300 border border-blue-500/30 cursor-wait"
                    : "bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 hover:bg-cyan-500/20"}"
                >${refreshing ? "⏳ Fetching…" : "📥 Fetch Description"}</button>
              </div>
            </div>
          `}
          ${problem.hints?.length ? html`
            <div class="mt-2">
              <p class="text-[10px] uppercase tracking-wider text-slate-600 mb-2">Hints</p>
              ${problem.hints.map((h, i) => html`
                <details class="mb-1">
                  <summary class="text-xs text-slate-500 cursor-pointer hover:text-slate-300 select-none">Hint ${i + 1}</summary>
                  <p class="text-xs text-slate-400 mt-1 pl-3 border-l border-white/10">${h}</p>
                </details>
              `)}
            </div>
          ` : ""}
        </div>`;
    },
  },
  {
    id: "code",
    label: "Code",
    show: (p) => !!p.code,
    render(problem, { html, copied, onCopy }) {
      const lang = problem.lang?.name || "Solution";
      return html`
        <div class="flex flex-col gap-2">
          <div class="flex justify-between items-center">
            <span class="text-[10px] uppercase tracking-wider text-slate-600">${lang}</span>
            <button
              onClick=${onCopy}
              class="text-[10px] px-2.5 py-1 rounded bg-white/5 border border-white/10 text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            >${copied ? "✓ Copied" : "Copy"}</button>
          </div>
          <pre class="text-xs font-mono text-slate-300 bg-black/40 rounded-lg p-4 overflow-x-auto leading-relaxed">${problem.code}</pre>
        </div>`;
    },
  },
  {
    id: "review",
    label: "AI Review",
    show: (p) => !!p.aiReview,
    render(problem, { html, AIMarkdownRenderer }) {
      return html`<${AIMarkdownRenderer} content=${problem.aiReview} />`;
    },
  },
  {
    id: "similar",
    label: (p) => `Similar (${p.similar?.length || 0})`,
    show: (p) => p.similar?.length > 0,
    render(problem, { html }) {
      return html`
        <div class="flex flex-col gap-2">
          ${problem.similar.map(s => html`
            <a
              href=${"https://leetcode.com/problems/" + s.titleSlug + "/"}
              target="_blank" rel="noopener"
              class="flex items-center gap-2 p-2 rounded-lg bg-white/3 border border-white/5 hover:bg-white/8 transition-colors"
            >
              <span class="text-xs text-slate-300">${s.title || s.titleSlug}</span>
              <span class="ml-auto text-[10px] ${s.difficulty === "Easy" ? "text-emerald-400" : s.difficulty === "Hard" ? "text-rose-400" : "text-amber-400"}">${s.difficulty}</span>
            </a>
          `)}
        </div>`;
    },
  },
  ...(IS_EXTENSION ? [{
    id: "chat",
    label: "Ask AI",
    render(problem, { html, chatMessages, chatInput, setChatInput, sendChat, chatPending, chatError, MultiLineAIChatInput }) {
      return html`
        <div class="flex flex-col h-full gap-3">
          <div class="flex-1 overflow-y-auto flex flex-col gap-3 min-h-0">
            ${chatMessages.length === 0 ? html`
              <p class="text-slate-500 text-xs text-center py-8">Ask anything about this problem or your solution.</p>
            ` : chatMessages.map(m => html`
              <div class="flex flex-col gap-1 ${m.role === "user" ? "items-end" : "items-start"}">
                <div class="max-w-[85%] px-3 py-2 rounded-xl text-xs leading-relaxed ${m.role === "user"
                  ? "bg-cyan-500/15 text-cyan-100 border border-cyan-500/20"
                  : "bg-white/5 text-slate-300 border border-white/8"}"
                >${m.content}</div>
              </div>
            `)}
            ${chatPending ? html`<p class="text-slate-500 text-xs animate-pulse">AI thinking…</p>` : ""}
            ${chatError ? html`<p class="text-rose-400 text-xs">${chatError}</p>` : ""}
          </div>
          <${MultiLineAIChatInput}
            value=${chatInput}
            onChange=${(v) => setChatInput(v)}
            onSubmit=${sendChat}
            disabled=${chatPending}
            placeholder="Ask about this problem…"
          />
        </div>`;
    },
  }] : []),
]);
```

- [ ] **Step 2: Auto-register on import**

The file registers itself when imported. It needs to be imported at extension startup. In `src/handlers/init.js` (or wherever handlers are initialized), add:

```js
import "../handlers/platforms/leetcode/modal-tabs.js";
```

If `src/handlers/init.js` doesn't exist yet, add the import to `src/background/service-worker.js` at the top.

- [ ] **Step 3: Commit**

```bash
git add src/handlers/platforms/leetcode/modal-tabs.js
git commit -m "feat(leetcode): extract modal tabs to handler-owned module"
```

---

## Task 10: Refactor `ProblemModal.js` to use the tab registry

**Files:**
- Modify: `src/library/components/ProblemModal.js`

Remove all hardcoded tab definitions. Replace them with a call to `modalTabRegistry.getTabs(problem.platform, problem)`.

- [ ] **Step 1: Add import**

```js
import { modalTabRegistry } from "../../core/modal-tab-registry.js";
```

- [ ] **Step 2: Replace hardcoded tabs array**

Find the current `const tabs = [...]` block (lines ~363-370):

```js
// REMOVE the old hardcoded tabs array:
// const tabs = [
//   { id: "overview", label: "Overview" },
//   ...(problem.code ? [{ id: "code", label: "Code" }] : []),
//   ...

// REPLACE with:
const registryTabs = modalTabRegistry.getTabs(problem.platform, problem);

// Always append Notes and Edit at the end (registered globally below)
const tabs = registryTabs.map(tab => ({
  id: tab.id,
  label: typeof tab.label === "function" ? tab.label(problem) : tab.label,
}));
```

- [ ] **Step 3: Replace tab content renderer**

Replace the current large inline `${activeTab === "overview" ? ...}` block with a dynamic renderer:

```js
<!-- ── Tab content ── -->
<div class="flex-1 overflow-y-auto p-5 min-h-0">
  ${(() => {
    const renderer = modalTabRegistry.getRenderer(problem.platform, activeTab);
    if (!renderer) return html`<p class="text-slate-500 text-sm">No content.</p>`;

    // Build the context object the renderer receives
    const ctx = {
      html,
      isExtension,
      onClose,
      onUpdate,
      onDelete,
      refreshing,
      onRefresh: handleRefreshData,
      copied,
      onCopy: copyCode,
      chatMessages, chatInput, setChatInput,
      sendChat: handleSendChat,
      chatPending, chatError,
      AIMarkdownRenderer,
      MultiLineAIChatInput,
    };
    return renderer(problem, ctx);
  })()}
</div>
```

- [ ] **Step 4: Register global tabs (Notes + Edit) at bottom of file**

After the `ProblemModal` function definition, register the always-present global tabs. Notes tab calls `problem.notes` (new field); Edit tab renders the metadata editor.

```js
// Register global tabs that appear for all platforms
import { modalTabRegistry } from "../../core/modal-tab-registry.js";

modalTabRegistry.register("*", [
  {
    id: "notes",
    label: "Notes",
    show: (p) => !!p.notes,
    render(problem, { html }) {
      return html`
        <div class="prose prose-invert prose-sm max-w-none">
          <pre class="whitespace-pre-wrap text-sm text-slate-300 font-sans leading-relaxed">${problem.notes}</pre>
        </div>`;
    },
  },
  {
    id: "edit",
    label: "Edit",
    always: true,
    render(problem, { html, onUpdate, onDelete }) {
      // The Edit tab component is self-contained (uses its own local state via a sub-component)
      return html`<${EditTab} problem=${problem} onUpdate=${onUpdate} onDelete=${onDelete} />`;
    },
  },
]);
```

Create a `EditTab` sub-component inside `ProblemModal.js` that contains the edit form state (`editTitle`, `editDifficulty`, `editTags`, `editNotes`, `editSaving`, etc.) — this is essentially the same code as the current Edit tab, but extracted into its own function component so it manages its own state cleanly:

```js
function EditTab({ problem, onUpdate, onDelete }) {
  const [title, setTitle]           = useState(problem.title || "");
  const [difficulty, setDifficulty] = useState(problem.difficulty || "Unknown");
  const [tags, setTags]             = useState((problem.tags || []).join(", "));
  const [notes, setNotes]           = useState(problem.notes || "");
  const [saving, setSaving]         = useState(false);
  const [saved, setSaved]           = useState(false);
  const [error, setError]           = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting]     = useState(false);

  const save = async () => {
    setSaving(true); setError("");
    try {
      const updated = {
        ...problem,
        title: title.trim() || problem.title,
        difficulty,
        tags: tags.split(",").map(t => t.trim()).filter(Boolean),
        notes: notes.trim(),
      };
      await Storage.saveProblem(updated);
      await Storage.markPendingProblemKey(`${updated.titleSlug}::${updated.lang?.slug || ""}`)
        .catch(() => {});
      onUpdate?.(updated);
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } catch (e) { setError(e.message); }
    finally { setSaving(false); }
  };

  const doDelete = async () => {
    setDeleting(true);
    try {
      await Storage.deleteProblem(problem.id);
      onDelete?.(problem);
    } catch (e) { setError(e.message); setDeleting(false); }
  };

  return html`
    <div class="flex flex-col gap-5">
      <!-- Title -->
      <label class="flex flex-col gap-1.5">
        <span class="text-[10px] uppercase tracking-wider text-slate-500">Title</span>
        <input value=${title} onInput=${e => setTitle(e.target.value)}
          class="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500/50" />
      </label>

      <!-- Difficulty -->
      <label class="flex flex-col gap-1.5">
        <span class="text-[10px] uppercase tracking-wider text-slate-500">Difficulty</span>
        <select value=${difficulty} onChange=${e => setDifficulty(e.target.value)}
          class="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500/50">
          ${["Easy","Medium","Hard","Unknown"].map(d => html`<option value=${d}>${d}</option>`)}
        </select>
      </label>

      <!-- Tags -->
      <label class="flex flex-col gap-1.5">
        <span class="text-[10px] uppercase tracking-wider text-slate-500">Tags (comma-separated)</span>
        <input value=${tags} onInput=${e => setTags(e.target.value)}
          placeholder="dynamic-programming, arrays, …"
          class="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500/50" />
      </label>

      <!-- Platform metadata (read-only display) -->
      <div class="flex flex-col gap-1">
        <span class="text-[10px] uppercase tracking-wider text-slate-500">Platform Metadata</span>
        <div class="grid grid-cols-2 gap-2 text-xs">
          <div class="bg-white/3 rounded p-2">
            <span class="text-slate-500">Platform</span>
            <p class="text-slate-300 mt-0.5">${problem.platform || "—"}</p>
          </div>
          <div class="bg-white/3 rounded p-2">
            <span class="text-slate-500">Language</span>
            <p class="text-slate-300 mt-0.5">${problem.lang?.name || "—"}</p>
          </div>
          <div class="bg-white/3 rounded p-2">
            <span class="text-slate-500">Runtime</span>
            <p class="text-slate-300 mt-0.5">${problem.runtime || "—"}</p>
          </div>
          <div class="bg-white/3 rounded p-2">
            <span class="text-slate-500">Memory</span>
            <p class="text-slate-300 mt-0.5">${problem.memory || "—"}</p>
          </div>
          <div class="bg-white/3 rounded p-2">
            <span class="text-slate-500">Accept Rate</span>
            <p class="text-slate-300 mt-0.5">${problem.acRate ? problem.acRate.toFixed(1) + "%" : "—"}</p>
          </div>
          <div class="bg-white/3 rounded p-2">
            <span class="text-slate-500">Solved</span>
            <p class="text-slate-300 mt-0.5">${problem.timestamp ? new Date(problem.timestamp).toLocaleDateString() : "—"}</p>
          </div>
        </div>
      </div>

      <!-- Notes -->
      <label class="flex flex-col gap-1.5">
        <span class="text-[10px] uppercase tracking-wider text-slate-500">Notes</span>
        <textarea
          value=${notes}
          onInput=${e => setNotes(e.target.value)}
          rows="5"
          placeholder="Personal notes, approach explanation, key insights…"
          class="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500/50 resize-y font-sans"
        ></textarea>
      </label>

      <!-- Save -->
      <div class="flex gap-2">
        <button onClick=${save} disabled=${saving}
          class="flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${saving
            ? "bg-cyan-500/20 text-cyan-300/50 cursor-wait"
            : "bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 hover:bg-cyan-500/25"}"
        >${saving ? "Saving…" : saved ? "✓ Saved" : "Save Changes"}</button>
      </div>

      ${error ? html`<p class="text-rose-400 text-xs">${error}</p>` : ""}

      <!-- Danger zone -->
      <div class="mt-4 pt-4 border-t border-white/5">
        <p class="text-[10px] uppercase tracking-wider text-slate-600 mb-2">Danger Zone</p>
        ${!confirmDelete ? html`
          <button onClick=${() => setConfirmDelete(true)}
            class="px-3 py-1.5 rounded text-xs text-rose-400 border border-rose-500/20 hover:bg-rose-500/10 transition-colors"
          >Delete this problem</button>
        ` : html`
          <div class="flex flex-col gap-2">
            <p class="text-xs text-rose-300">This will delete the local record only (not the GitHub commit).</p>
            <div class="flex gap-2">
              <button onClick=${doDelete} disabled=${deleting}
                class="px-3 py-1.5 rounded text-xs bg-rose-500/15 border border-rose-500/30 text-rose-300 hover:bg-rose-500/25 transition-colors"
              >${deleting ? "Deleting…" : "Yes, delete"}</button>
              <button onClick=${() => setConfirmDelete(false)}
                class="px-3 py-1.5 rounded text-xs text-slate-400 hover:text-white border border-white/10 hover:bg-white/5 transition-colors"
              >Cancel</button>
            </div>
          </div>
        `}
      </div>
    </div>`;
}
```

- [ ] **Step 5: Clean up ProblemModal state**

Remove state variables that are now owned by `EditTab`: `editTitle`, `editDifficulty`, `editTags`, `editSaving`, `editSaved`, `editError`, `confirmDelete`, `deleting`.

- [ ] **Step 6: Commit**

```bash
git add src/library/components/ProblemModal.js
git commit -m "refactor(ProblemModal): use tab registry; move Edit into self-contained sub-component; add Notes tab"
```

---

## Task 11: Fix `knowledge-graph.js` — remove topic-topic ring edges

**Files:**
- Modify: `src/core/knowledge-graph.js`

The topic-topic ring edges (lines 181-193) exist to keep disconnected topic clusters from drifting. Without them, the graph physics will keep everything connected via the shared center gravity — that's sufficient.

- [ ] **Step 1: Delete the ring edge block**

Find and remove lines 181-193 in `knowledge-graph.js`:

```js
// DELETE this entire block:
// Backbone: connect all topic nodes in a ring so no cluster can fully detach.
const topicNodeIds = [...nodes.values()]
  .filter((n) => n.type === "topic")
  .map((n) => n.id);
for (let i = 0; i < topicNodeIds.length; i++) {
  edges.push({
    source: topicNodeIds[i],
    target: topicNodeIds[(i + 1) % topicNodeIds.length],
    type: "topic-topic",
  });
}
```

Also remove `"topic-topic"` from the `LINK_DIST` and `LINK_STR` constants in `GraphView.js` (they are no longer needed) and from `EDGE_COLOR` / `EDGE_GLOW_COLOR`.

- [ ] **Step 2: Commit**

```bash
git add src/core/knowledge-graph.js src/library/views/GraphView.js
git commit -m "fix(graph): remove topic-topic ring edges — topics were incorrectly connected to each other"
```

---

## Task 12: Fix `GraphView.js` — filter correctness and single-topic node layout

**Files:**
- Modify: `src/library/views/GraphView.js`

**Issue 1:** When filtering by difficulty, topic nodes from OTHER difficulty problems bleed through via `topic-topic` edges in the edge walk. Now that topic-topic edges are removed (Task 11), this is partially fixed. But the edge walk `if (visibleProblemIds.has(e.source)) drawNodeIds.add(e.target)` still adds ALL connected topic nodes — including those connected to the filtered problem from OTHER edges. We need to only add topic nodes that are connected to a MATCHING problem.

**Issue 2:** Problems connected to only one topic should orbit their topic, not drift toward the global center. The fix: apply a stronger per-topic "home" attraction for single-topic problem nodes.

- [ ] **Step 1: Fix `getVisibleGraphData` edge walk to be direction-aware**

Replace the current edge walk (lines ~564-577) with:

```js
const drawNodeIds = new Set(visibleProblemIds);

// Add topic nodes only if they're directly connected to a visible PROBLEM node.
// Do NOT follow topic-problem edges from topic → other problems (that would re-add hidden problems).
for (const e of edges) {
  if (e.type !== "topic-problem") continue; // only follow problem↔topic connections
  if (visibleProblemIds.has(e.target)) drawNodeIds.add(e.source); // topic node
  if (visibleProblemIds.has(e.source)) drawNodeIds.add(e.target); // topic node
}

// Also keep topic nodes that match the search query directly (even if no matching problems yet).
if (query) {
  for (const n of nodes) {
    if (n.type === "topic" && String(n.label || "").toLowerCase().includes(query)) {
      drawNodeIds.add(n.id);
    }
  }
}
```

- [ ] **Step 2: Strengthen single-topic attraction in `simulationStep`**

In `simulationStep`, after the main attraction loop, add a second pass that applies extra pull for problem nodes that have exactly one topic connection:

```js
// Extra topic pull for problems with only one topic — keeps them near their topic, away from center.
// Build a map: problemId → topicId (only for single-topic problems)
const singleTopicMap = new Map();
const problemTopicCount = new Map();
for (const e of edges) {
  if (e.type !== "topic-problem") continue;
  const pId = e.target; // convention: source=topic, target=problem
  problemTopicCount.set(pId, (problemTopicCount.get(pId) || 0) + 1);
  singleTopicMap.set(pId, e.source); // will be overwritten if there are multiple topics
}

const nodeMap2 = new Map(nodes.map(n => [n.id, n]));
for (const [problemId, topicId] of singleTopicMap) {
  if ((problemTopicCount.get(problemId) || 0) !== 1) continue;
  const p = nodeMap2.get(problemId);
  const t = nodeMap2.get(topicId);
  if (!p || !t) continue;
  const dx = t.x - p.x;
  const dy = t.y - p.y;
  const d  = Math.sqrt(dx * dx + dy * dy) || 1;
  const desiredDist = 80; // orbit radius
  const pull = (d - desiredDist) * 0.012 * alpha;
  p.fx += (pull * dx) / d;
  p.fy += (pull * dy) / d;
}
```

Note: pass `edges` into `simulationStep` signature — it currently takes `(nodes, edges, alpha)` so this already works.

- [ ] **Step 3: Add filter chip visual indicator**

In the filter controls section of `GraphView` component JSX, add a "Filters active" badge when any filter is non-default:

```js
const hasActiveFilters = filterDifficultyGraph !== "All" || filterPlatformGraph !== "All"
  || filterTopicGraph !== "All" || filterSolved || graphSearch.trim();
```

Then near the filter controls:
```js
${hasActiveFilters ? html`
  <button
    onClick=${() => {
      setFilterDifficultyGraph("All");
      setFilterPlatformGraph("All");
      setFilterTopicGraph("All");
      setFilterSolved(false);
      setGraphSearch("");
    }}
    class="px-2 py-1 rounded text-[10px] bg-rose-500/15 border border-rose-500/30 text-rose-300 hover:bg-rose-500/25 transition-colors"
  >✕ Clear filters</button>
` : ""}
```

- [ ] **Step 4: Commit**

```bash
git add src/library/views/GraphView.js
git commit -m "fix(graph): correct filter edge-walk; strengthen single-topic node attraction; add clear-filters button"
```

---

## Task 13: Create `src/core/platform-timer.js`

**Files:**
- Create: `src/core/platform-timer.js`
- Modify: `src/handlers/_base/BasePlatformHandler.js`
- Modify: `src/handlers/platforms/leetcode/index.js`
- Modify: `src/content/handler-loader.js`

- [ ] **Step 1: Create `platform-timer.js`**

```js
// src/core/platform-timer.js
/**
 * Platform-agnostic timer abstraction.
 *
 * Handlers that have a native timer (e.g. LeetCode) override getNativeElapsed().
 * All other platforms get the custom floating timer automatically via handler-loader.
 */

export class PlatformTimer {
  /** @param {import('../handlers/_base/BasePlatformHandler').BasePlatformHandler} handler */
  constructor(handler) {
    this._handler  = handler;
    this._floating = null;
  }

  /**
   * Whether the handler has a native on-page timer.
   * If true, no floating timer is injected.
   */
  hasNative() {
    return typeof this._handler.getNativeElapsed === "function"
      && this._handler.getNativeElapsed() !== null;
  }

  /**
   * Inject the custom floating timer for this slug.
   * Called by handler-loader only if !hasNative().
   */
  async injectFloating(slug, opts = {}) {
    if (this._floating) return;
    const { createFloatingTimer } = await import("../ui/floating-timer.js");
    this._floating = createFloatingTimer(slug, opts);
  }

  /** Get elapsed seconds from native timer or floating timer. */
  getElapsed() {
    if (this._handler.getNativeElapsed) {
      const secs = this._handler.getNativeElapsed();
      if (secs !== null && secs !== undefined) return secs;
    }
    return this._floating?.getElapsed() || null;
  }

  destroy() {
    this._floating?.destroy();
    this._floating = null;
  }
}
```

- [ ] **Step 2: Add `getNativeElapsed()` stub to `BasePlatformHandler.js`**

In `src/handlers/_base/BasePlatformHandler.js`, add a method that returns `null` by default:

```js
/**
 * Override in handlers that have a native on-page timer.
 * Return elapsed seconds as a number, or null if not available.
 * @returns {number|null}
 */
getNativeElapsed() {
  return null;
}
```

- [ ] **Step 3: Override `getNativeElapsed()` in LeetCode handler**

In `src/handlers/platforms/leetcode/index.js`, add:

```js
getNativeElapsed() {
  const timerEl = document.querySelector(".select-none.text-sm.text-sd-blue-400");
  if (!timerEl) return null;
  const text  = timerEl.textContent || "";
  const match = text.match(/\b(\d{1,2}:\d{2}(?::\d{2})?)\b/);
  if (!match) return null;
  const parts = match[1].split(":").map(Number);
  if (parts.some(isNaN)) return null;
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  return null;
}
```

Remove `_getNativeTimerElement()` and `_getElapsedSeconds()` from the LeetCode handler — they're replaced by `getNativeElapsed()` above.

In `_processSubmission`, replace `const elapsedSeconds = this._getElapsedSeconds();` with:
```js
const elapsedSeconds = this.getNativeElapsed();
```

- [ ] **Step 4: Update `handler-loader.js` to inject timer**

```js
// src/content/handler-loader.js
import { PlatformTimer } from "../core/platform-timer.js";

async function loadHandler() {
  const hostname = window.location.hostname;
  let handler = null;

  try {
    const debugUrl = chrome.runtime.getURL("lib/debug.js");
    const { initDebug } = await import(debugUrl);
    await initDebug();
  } catch (_) {}

  try {
    if (isHost("leetcode.com", hostname)) {
      const url = chrome.runtime.getURL("handlers/platforms/leetcode/index.js");
      const { LeetCodeHandler } = await import(url);
      handler = new LeetCodeHandler();
    } else if (isHost("geeksforgeeks.org", hostname)) {
      const url = chrome.runtime.getURL("handlers/platforms/geeksforgeeks/index.js");
      const { GFGHandler } = await import(url);
      handler = new GFGHandler();
    } else if (isHost("codeforces.com", hostname)) {
      const url = chrome.runtime.getURL("handlers/platforms/codeforces/index.js");
      const { CodeforcesHandler } = await import(url);
      handler = new CodeforcesHandler();
    }

    if (!handler) return;

    await handler.init();

    // Inject floating timer only for platforms without a native timer.
    // LeetCode has its own contest timer — don't overlay ours.
    const timer = new PlatformTimer(handler);
    if (!timer.hasNative()) {
      const slug = new URLSearchParams(window.location.search).get("problem")
        || window.location.pathname.split("/").filter(Boolean).pop()
        || "unknown";
      await timer.injectFloating(slug);
    }
    // Store timer on handler so it can read elapsed on solve events.
    handler._timer = timer;

  } catch (err) {
    console.error("[CodeLedger] Failed to load platform handler:", err);
  }
}

loadHandler();
```

- [ ] **Step 5: Remove direct floating-timer imports from GFG/Codeforces handlers**

In `src/handlers/platforms/geeksforgeeks/index.js`, remove:
```js
import { createFloatingTimer } from "../../../ui/floating-timer.js";
```
And remove any `this._timer = createFloatingTimer(...)` calls from `init()`.

Do the same for `src/handlers/platforms/codeforces/index.js`.

Update any `this._timer?.getElapsed()` calls in those handlers to use `this._timer?.getElapsed()` — the interface is the same (`getElapsed()`) so calls stay valid.

- [ ] **Step 6: Commit**

```bash
git add src/core/platform-timer.js src/handlers/_base/BasePlatformHandler.js \
  src/handlers/platforms/leetcode/index.js src/handlers/platforms/geeksforgeeks/index.js \
  src/handlers/platforms/codeforces/index.js src/content/handler-loader.js
git commit -m "feat: platform-agnostic timer — native timer for LeetCode, floating timer for other platforms"
```

---

## Task 14: Code cleanup — remove all remaining dead code

**Files:**
- Modify: `src/background/service-worker.js`
- Modify: `src/handlers/platforms/leetcode/index.js`
- Modify: `src/library/views/GraphView.js`

- [ ] **Step 1: Remove stale `cl-row-sync` cleanup guard from LeetCode handler**

In `src/handlers/platforms/leetcode/index.js`, find in `_syncButtonsForCurrentPage`:
```js
// Clean up deprecated row-sync buttons from old versions
document.querySelectorAll(".cl-row-sync").forEach((el) => el.remove());
```
Delete those two lines — the old buttons no longer exist in any user's DOM after enough time.

- [ ] **Step 2: Remove legacy `checkSubmission` / `fetchGraphQL` / `getProblemMetadata` compatibility shims**

At the bottom of `leetcode/index.js`, find and remove:
```js
async checkSubmission() { return this._checkSubmission(); }
async fetchGraphQL(q, v) { return this._gql(q, v); }
async getProblemMetadata(slug) { return this._fetchMetadata(slug); }
```
These were never called externally after the handler refactor.

- [ ] **Step 3: Remove unused `LINK_DIST["topic-topic"]` and `LINK_STR["topic-topic"]` from GraphView**

In `src/library/views/GraphView.js`:
```js
// BEFORE:
const LINK_DIST = { "topic-problem": 100, similar: 80, canonical: 60, "topic-topic": 220 };
const LINK_STR  = { "topic-problem": 0.45, similar: 0.08, canonical: 0.5, "topic-topic": 0.25 };

// AFTER:
const LINK_DIST = { "topic-problem": 100, similar: 80, canonical: 60 };
const LINK_STR  = { "topic-problem": 0.45, similar: 0.08, canonical: 0.5 };
```

Also remove `"topic-topic"` entries from `EDGE_COLOR` and `EDGE_GLOW_COLOR`.

- [ ] **Step 4: Remove `_formatHints` empty method from LeetCode handler**

Find and remove the method that does nothing:
```js
_formatHints(meta, settings) {
  if (settings.leetcode_sync_hints || !meta?.hints?.length) return "";
  return "";  // hints go in separate file when that setting is on
}
```
The call sites in `_buildFileSet` already pass `settings` to the hints file logic directly — no wrapper needed.

- [ ] **Step 5: Commit**

```bash
git add src/background/service-worker.js src/handlers/platforms/leetcode/index.js \
  src/library/views/GraphView.js
git commit -m "chore: remove dead code — row-sync guard, legacy shims, empty methods, unused edge types"
```

---

## Task 15: Reorganise `docs/FEATURE_REQUESTS.md` and create `docs/PROGRESS.md`

**Files:**
- Create: `docs/FEATURE_REQUESTS_COMPLETED.md`
- Modify: `docs/FEATURE_REQUESTS.md`
- Create: `docs/PROGRESS.md`

- [ ] **Step 1: Create `docs/FEATURE_REQUESTS_COMPLETED.md`**

Move the entire **Completed ✅** table from `FEATURE_REQUESTS.md` into this new file:

```markdown
# CodeLedger — Completed Features Archive

All features listed here are shipped and merged to `main`.
For active work see [FEATURE_REQUESTS.md](./FEATURE_REQUESTS.md).

| Feature                               | Notes |
| ------------------------------------- | ----- |
| Language detection fix (py/undefined) | ...   |
[... paste full completed table here ...]
```

- [ ] **Step 2: Trim `docs/FEATURE_REQUESTS.md`**

Remove the completed section entirely. Keep only:
- **In Progress 🔄** table
- **Bugs to Fix 🐛** table
- **Pending 📋** section (all sub-tables: Math, Diagram, AI, Graph, Modal, MCP, etc.)
- **Won't Do** table

Add a reference header at the top:
```markdown
# CodeLedger — Feature Requests & Backlog

> Completed features have been moved to [FEATURE_REQUESTS_COMPLETED.md](./FEATURE_REQUESTS_COMPLETED.md).

Track tasks in [PROGRESS.md](./PROGRESS.md).
```

Update the in-progress table to reflect work done in this overhaul:
- Mark "Graph search/sort/layering UI" as `done` with note "Filter fix, topic-topic edge removal, single-topic node orbit fix"
- Add new rows for SP1-SP6 work completed

- [ ] **Step 3: Create `docs/PROGRESS.md`**

```markdown
# CodeLedger — Project Progress

> This file is updated after every work session.
> Add your requests/notes below the **Inbox** section — they will be moved to the
> appropriate table on the next session.

---

## Inbox (add requests here)

<!-- Add free-text requests below this line. They will be processed in the next session. -->


---

## Active Sprint

| Task                                        | Status | Notes                                         |
| ------------------------------------------- | ------ | --------------------------------------------- |
| SP1: Flat canonical-slug storage structure  | ✅ done | path-builder.js; problems_dir setting         |
| SP2: GitHub canonical rename pipeline       | ✅ done | atomic delete+create; maintenance commits     |
| SP3: Platform-agnostic modal tabs           | ✅ done | modal-tab-registry; LeetCode tabs extracted   |
| SP3: Notes tab in modal + improved Edit tab | ✅ done | EditTab sub-component; notes field            |
| SP4: Graph — remove topic-topic edges       | ✅ done | knowledge-graph.js ring edges removed         |
| SP4: Graph — filter correctness             | ✅ done | edge walk scoped to topic-problem only        |
| SP4: Graph — single-topic node orbit        | ✅ done | extra pull for single-topic problems          |
| SP5: Platform-agnostic timer                | ✅ done | platform-timer.js; LeetCode uses native timer |
| SP6: Dead code cleanup                      | ✅ done | handleLeetCodeImport removed; shims removed   |

---

## Upcoming

| Task                                   | Priority | Notes                                       |
| -------------------------------------- | -------- | ------------------------------------------- |
| Problem multi-select + bulk CRUD       | high     | Checkbox mode in Solutions view             |
| Per-problem topic tag editor (chip UI) | high     | Modal Edit tab — add/remove individual tags |
| AI submission context (test vs submit) | high     | Detect test failures, auto-fetch errors     |
| Math/Mermaid rendering in AI responses | high     | Marked.js or KaTeX integration              |
| AI command palette full implementation | high     | Dropdown, fuzzy search, keyboard nav        |

---

## Blocked / Investigating

| Task                                        | Blocker                                                                     |
| ------------------------------------------- | --------------------------------------------------------------------------- |
| LeetCode submission auto-detect reliability | MutationObserver may miss some React render cycles — needs controlled repro |

---

## Decisions Log

| Date       | Decision                                           | Reason                                                                                                                                       |
| ---------- | -------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------- |
| 2026-05-05 | No LangChain/LangGraph in extension                | Browser extensions can't run Node.js libs; current BaseAIHandler chain is sufficient; move advanced pipelines to Cloudflare Worker if needed |
| 2026-05-05 | Flat `problems/{slug}/` storage (no topic subdirs) | Topics change; slugs are stable. Canonical ID is the correct primary key.                                                                    |
| 2026-05-05 | LeetCode native contest timer — no custom overlay  | LeetCode already shows a timer; injecting ours is redundant and noisy                                                                        |
```

- [ ] **Step 4: Commit**

```bash
git add docs/FEATURE_REQUESTS.md docs/FEATURE_REQUESTS_COMPLETED.md docs/PROGRESS.md
git commit -m "docs: archive completed features; create PROGRESS.md project tracker"
```

---

## Self-Review

### Spec coverage check

| Requirement                               | Covered by task                                                |
| ----------------------------------------- | -------------------------------------------------------------- |
| Flat `problems/{slug}/` storage           | Tasks 1, 3, 4, 5                                               |
| Configurable root dir                     | Tasks 1, 7                                                     |
| Platform subdir for canonical problems    | Task 1 (path-builder rules)                                    |
| Canonical ID rename pipeline              | Task 6                                                         |
| README / index always up to date          | Task 3 (getProblemFiles includes readme)                       |
| Missing infra auto-recover                | Already in github/index.js `_getMissingInfraFiles` — preserved |
| Metadata update commit                    | Task 10 (EditTab marks pending on save)                        |
| Modal platform-agnostic tabs              | Tasks 8, 9, 10                                                 |
| Notes tab in modal                        | Task 10                                                        |
| Improved Edit tab (all metadata)          | Task 10                                                        |
| Remove topic-topic edges                  | Task 11                                                        |
| Filter correctness (Hard shows only Hard) | Task 12                                                        |
| Single-topic node orbit                   | Task 12                                                        |
| Platform timer abstraction                | Task 13                                                        |
| LeetCode uses native timer                | Task 13                                                        |
| Dead code cleanup                         | Tasks 3, 14                                                    |
| PROGRESS.md                               | Task 15                                                        |
| Feature requests reorganisation           | Task 15                                                        |

### Placeholder scan
No TBD or TODO placeholders found in task steps. All code blocks are complete.

### Type consistency
- `path-builder.js` exports `solutionPath`, `readmePath`, `hintsPath`, `buildProblemFiles`, `problemBase`, `rebasePath` — all referenced correctly in Tasks 3-5.
- `modalTabRegistry.getTabs(platform, problem)` and `modalTabRegistry.getRenderer(platform, tabId)` — used in Task 10, defined in Task 8.
- `PlatformTimer.getElapsed()` returns `number | null` — used in LeetCode handler `_processSubmission`, consistent.
- `getNativeElapsed()` on `BasePlatformHandler` returns `number | null` — overridden in LeetCode, used in `PlatformTimer.hasNative()`.
