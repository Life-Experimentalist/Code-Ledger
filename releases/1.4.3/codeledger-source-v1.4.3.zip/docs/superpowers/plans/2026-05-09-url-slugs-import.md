# Platform Slugs + URL-ification + GitHub Import Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Give every problem a cross-platform-unique id (`lc-two-sum`, `gfg-two-sum`, `cf-1234a`), make all UI state (filters, tabs, modals, analytics drill-downs) survive a page reload via URL params, and add mandatory GitHub repo import with per-item conflict resolution on first connect.

**Architecture:** The id change is foundational and touches every layer — do Tasks 1-5 first and in order. URL tasks (6-10) are independent of each other once the id is stable. The import feature (11-15) builds on the id scheme and a new `ConflictResolutionModal` component.

**Tech Stack:** Preact + htm, IndexedDB, `url-state.js` (`getQueryParam` / `updateQueryParams`), GitHub Contents API, existing `path-builder.js` / `migration-manager.js`.

---

## File Map

| Action | File |
|--------|------|
| Modify | `src/core/constants.js` |
| Modify | `src/core/path-builder.js` |
| Modify | `src/core/storage.js` |
| Modify | `src/background/migration-manager.js` |
| Modify | `src/background/service-worker.js` |
| Modify | `src/background/sync-engine.js` |
| Modify | `src/handlers/platforms/leetcode/index.js` |
| Modify | `src/handlers/platforms/geeksforgeeks/index.js` |
| Modify | `src/handlers/platforms/codeforces/index.js` |
| Modify | `src/library/views/SettingsPageView.js` |
| Modify | `src/library/views/ProblemsView.js` |
| Modify | `src/library/views/AnalyticsView.js` |
| Modify | `src/library/views/GraphView.js` |
| Modify | `src/library/components/ProblemModal.js` |
| Modify | `src/library/library.js` |
| Modify | `src/ui/components/GitHubOnboardingModal.js` |
| Modify | `src/library/settings-panels/PanelGit.js` |
| Modify | `docs/OPENAPI.yaml` |
| Create | `src/library/components/ConflictResolutionModal.js` |

---

## Task 1: Platform code map + `makeProblemId` helper

**Files:**
- Modify: `src/core/constants.js`

- [ ] **Step 1: Add `PLATFORM_CODE` map and helper to constants.js**

Find the `PLATFORMS` block (around line 150) and add directly after the closing `},` of the `PLATFORMS` object:

```js
  PLATFORM_CODE: {
    leetcode:      "lc",
    geeksforgeeks: "gfg",
    codeforces:    "cf",
  },
```

Then add a pure helper at the very bottom of the file, before the closing `};` of `CONSTANTS`:

```js
  /** Returns the platform-scoped unique id, e.g. "lc-two-sum". */
  makeProblemId(platform, titleSlug) {
    const code = this.PLATFORM_CODE[platform] || platform.slice(0, 3).toLowerCase();
    return `${code}-${titleSlug}`;
  },
```

- [ ] **Step 2: Verify in browser console (load extension, open library, DevTools console)**

```js
CONSTANTS.makeProblemId("leetcode", "two-sum")      // → "lc-two-sum"
CONSTANTS.makeProblemId("geeksforgeeks", "reverse")  // → "gfg-reverse"
CONSTANTS.makeProblemId("codeforces", "1234a")        // → "cf-1234a"
```

- [ ] **Step 3: Commit**

```bash
git add src/core/constants.js
git commit -m "feat: add PLATFORM_CODE map and makeProblemId() helper to constants"
```

---

## Task 2: Update `path-builder.js` to use platform-scoped id

**Files:**
- Modify: `src/core/path-builder.js`

The current `problemBase()` uses `titleSlug` as the folder name when no canonical is set. After this task it uses the full platform-scoped id (`lc-two-sum`), eliminating cross-platform folder collisions.

- [ ] **Step 1: Update `problemBase` signature and logic**

Replace the current `problemBase` function:

```js
export function problemBase(titleSlug, canonical, settings = {}) {
  const root = (settings?.problems_dir || "problems").replace(/\/+$/, "");
  const dir  = canonical?.canonicalId || titleSlug;
  return `${root}/${dir}`;
}
```

With (first arg renamed `id` — the platform-scoped slug):

```js
export function problemBase(id, canonical, settings = {}) {
  const root = (settings?.problems_dir || "problems").replace(/\/+$/, "");
  const dir  = canonical?.canonicalId || id;
  return `${root}/${dir}`;
}
```

- [ ] **Step 2: Update `solutionPath` first arg and internal call**

Replace:

```js
export function solutionPath(titleSlug, platform, lang, canonical, settings = {}) {
  const base = problemBase(titleSlug, canonical, settings);
  const slug = canonical?.canonicalId || titleSlug;
```

With:

```js
export function solutionPath(id, platform, lang, canonical, settings = {}) {
  const base = problemBase(id, canonical, settings);
  const slug = canonical?.canonicalId || id;
```

- [ ] **Step 3: Update `readmePath` and `hintsPath` first arg**

```js
export function readmePath(id, canonical, settings = {}) {
  return `${problemBase(id, canonical, settings)}/README.md`;
}

export function hintsPath(id, canonical, settings = {}) {
  return `${problemBase(id, canonical, settings)}/hints.md`;
}
```

- [ ] **Step 4: Update `buildProblemFiles` to pass `id` instead of `titleSlug`**

In `buildProblemFiles`, replace `problem.titleSlug || problem.id` with `problem.id || problem.titleSlug` everywhere:

```js
export function buildProblemFiles(problem, settings = {}) {
  const canonical = problem.canonical || null;
  const lang      = problem.lang || { verbose: "Solution", name: "solution", ext: "txt" };
  const ext       = lang.ext || "txt";
  const normalLang = { verbose: lang.verbose || lang.name || "Solution", name: lang.name || "solution", ext };
  const id        = problem.id || problem.titleSlug || "unknown";   // ← platform-scoped
  const files = [];

  if (problem.code) {
    files.push({
      path: solutionPath(id, problem.platform || "unknown", normalLang, canonical, settings),
      content: problem.code,
    });
  }
  if (problem.readmeContent) {
    files.push({
      path: readmePath(id, canonical, settings),
      content: problem.readmeContent,
    });
  }
  if (problem.hintsContent) {
    files.push({
      path: hintsPath(id, canonical, settings),
      content: problem.hintsContent,
    });
  }
  return files;
}
```

- [ ] **Step 5: Update `migration-manager.js` — replace `titleSlug` with `id` in path calls**

In `src/background/migration-manager.js`, find every call to `solutionPath`, `readmePath`, `hintsPath` that passes `p.titleSlug || p.id` as first arg and replace with `p.id || p.titleSlug`:

```js
// In migrateRepo() and resetRepo(), change:
const solPath = solutionPath(p.titleSlug || p.id, ...
// To:
const solPath = solutionPath(p.id || p.titleSlug, ...

// Same for readmePath and hintsPath calls
```

- [ ] **Step 6: Update `service-worker.js` — replace `titleSlug` with `id` in path fallback**

In `src/background/service-worker.js` function `getProblemFiles`, find:
```js
const slug = problem.titleSlug || String(problem.id || "unknown");
```
Replace with:
```js
const slug = problem.id || problem.titleSlug || "unknown";
```

Also in the canonical rename detection block (around line 155), change:
```js
const expectedBase = problemBase(data.titleSlug || data.id, ...
```
To:
```js
const expectedBase = problemBase(data.id || data.titleSlug, ...
```

- [ ] **Step 7: Commit**

```bash
git add src/core/path-builder.js src/background/migration-manager.js src/background/service-worker.js
git commit -m "feat: path-builder uses platform-scoped id as folder name"
```

---

## Task 3: Data migration — rekey existing IDB records to platform-scoped ids

**Files:**
- Modify: `src/background/migration-manager.js`
- Modify: `src/background/service-worker.js`

Existing problems may have ids like `"two-sum"` (GFG/CF) or `"two-sum::py"` (LeetCode bulk) or `null` (GFG bug). This migration adds the platform prefix and strips the `::lang` suffix, keeping the record with the latest timestamp when two collapse to the same id.

- [ ] **Step 1: Add `migrateProblemIds()` to `migration-manager.js`**

Add this export after the existing imports:

```js
import { Storage } from "../core/storage.js";
import { CONSTANTS } from "../core/constants.js";
```

Then add the function:

```js
/**
 * One-time migration: rekey problem records to platform-scoped ids.
 * Old formats handled:
 *   "two-sum"        → "lc-two-sum" / "gfg-two-sum" / "cf-two-sum"
 *   "two-sum::py"    → "lc-two-sum"   (LeetCode bulk import style)
 *   null / ""        → "gfg-{titleSlug}" (GFG bug fallback)
 *
 * Idempotent: records already matching /^(lc|gfg|cf)-/ are skipped.
 */
export async function migrateProblemIds() {
  const ALREADY_MIGRATED = /^(lc|gfg|cf)-/;
  const problems = await Storage.getAllProblems();
  const toMigrate = problems.filter(p => !ALREADY_MIGRATED.test(p.id || ""));
  if (toMigrate.length === 0) return;

  dbg.log(`migrateProblemIds: migrating ${toMigrate.length} records`);

  // Group by new id — keep the record with the latest timestamp when multiple collapse
  const byNewId = new Map();
  for (const p of toMigrate) {
    const rawId = String(p.id || p.titleSlug || "unknown");
    // Strip ::lang suffix if present
    const titleSlug = rawId.includes("::") ? rawId.split("::")[0] : rawId;
    const platform  = p.platform || "unknown";
    const newId     = CONSTANTS.makeProblemId(platform, titleSlug);
    const existing  = byNewId.get(newId);
    if (!existing || (p.timestamp || 0) > (existing.timestamp || 0)) {
      byNewId.set(newId, { ...p, id: newId, titleSlug });
    }
  }

  // Delete old records and insert rekeyed ones
  const store = await Storage.getAllProblems(); // fresh read for safety
  const oldIds = new Set(toMigrate.map(p => p.id || p.titleSlug));
  for (const oldId of oldIds) {
    await Storage.deleteProblem(oldId).catch(() => {});
  }
  for (const [, record] of byNewId) {
    await Storage.saveProblem(record);
  }

  // Migrate committedSlugLangs map: rekey from "slug::lang" to "newId::lang"
  const key = "cl.committed.sluglangs";
  const { [key]: map = {} } = await Storage._raw().catch(() => ({}));
  if (Object.keys(map).length > 0) {
    const newMap = {};
    for (const [k, v] of Object.entries(map)) {
      const [rawSlug, lang] = k.split("::");
      if (!rawSlug) continue;
      // Try to match to a migrated record by titleSlug
      const migrated = [...byNewId.values()].find(p => p.titleSlug === rawSlug);
      const newKey = migrated ? `${migrated.id}::${lang}` : k;
      newMap[newKey] = v;
    }
    // Re-save using direct storage set (Storage.setRaw or direct chrome.storage)
    await Storage._setRaw(key, newMap).catch(() => {});
  }

  dbg.log(`migrateProblemIds: done — ${byNewId.size} records rekeyed`);
}
```

- [ ] **Step 2: Add `_raw()` and `_setRaw()` to `Storage` in `src/core/storage.js`**

These are needed by the migration to access the committedSlugLangs map directly. Add after `getCommittedSlugLangs()`:

```js
  async _raw() {
    return browserStorage.local.get(null);
  },

  async _setRaw(key, value) {
    return browserStorage.local.set({ [key]: value });
  },
```

- [ ] **Step 3: Call `migrateProblemIds()` on app startup in `service-worker.js`**

Find the `init()` or startup block in `service-worker.js` (where `alarm-manager` and other inits run). Add the import and call:

At top of file, add import:
```js
import { migrateProblemIds } from "./migration-manager.js";
```

In the startup/install listener, after existing migrations:
```js
migrateProblemIds().catch(e => coreDebug.error("migrateProblemIds failed", e));
```

- [ ] **Step 4: Verify (load extension, check DevTools → Application → IndexedDB → codeledger → problems)**

All problem records should now have ids starting with `lc-`, `gfg-`, or `cf-`.

- [ ] **Step 5: Commit**

```bash
git add src/background/migration-manager.js src/core/storage.js src/background/service-worker.js
git commit -m "feat: migrate problem IDs to platform-scoped format (lc/gfg/cf prefix)"
```

---

## Task 4: Platform handlers — emit platform-scoped ids

**Files:**
- Modify: `src/handlers/platforms/leetcode/index.js`
- Modify: `src/handlers/platforms/geeksforgeeks/index.js`
- Modify: `src/handlers/platforms/codeforces/index.js`

- [ ] **Step 1: Import CONSTANTS in each handler (if not already imported)**

All three handlers need:
```js
import { CONSTANTS } from "../../../core/constants.js";
```

Check if already imported — if yes, skip.

- [ ] **Step 2: Fix LeetCode bulk import id (around line 890)**

In `src/handlers/platforms/leetcode/index.js`, find:
```js
id:             `${sub.titleSlug}::${lang.slug}`,
```
Replace with:
```js
id:             CONSTANTS.makeProblemId("leetcode", sub.titleSlug),
```

- [ ] **Step 3: Fix LeetCode real-time emit id (around line 1199)**

Find:
```js
id: `${slug}::${lang.slug}`,
```
Replace with:
```js
id: CONSTANTS.makeProblemId("leetcode", slug),
```

- [ ] **Step 4: Fix LeetCode `markSlugLangCommitted` calls**

In `service-worker.js` (around line 258), the call is:
```js
await Storage.markSlugLangCommitted(titleSlug, langName).catch(() => { });
```
Change to use the platform-scoped id. The `data` object already has `data.id` at this point:
```js
await Storage.markSlugLangCommitted(data.id || titleSlug, langName).catch(() => { });
```

And for the `isSlugLangCommitted` check — find where it's used to guard double-commits and update the same way.

- [ ] **Step 5: Fix GFG handler id**

In `src/handlers/platforms/geeksforgeeks/index.js`, find the `eventBus.emit("problem:solved", {` block and replace:
```js
id: meta.platformId || null,
```
With:
```js
id: CONSTANTS.makeProblemId("geeksforgeeks", slug),
```

Also find the earlier `Storage.saveProblem({ id: String(slug), ...` pattern (around line 108) and change:
```js
id: String(slug),
```
To:
```js
id: CONSTANTS.makeProblemId("geeksforgeeks", String(slug)),
```

- [ ] **Step 6: Fix CF handler id**

In `src/handlers/platforms/codeforces/index.js`, find all occurrences of:
```js
id: String(slug),
```
Replace with:
```js
id: CONSTANTS.makeProblemId("codeforces", String(slug)),
```

- [ ] **Step 7: Verify — solve a problem (or use the LeetCode sync button) and check IndexedDB**

The saved record's `id` field should now show e.g. `lc-two-sum`.

- [ ] **Step 8: Commit**

```bash
git add src/handlers/platforms/leetcode/index.js src/handlers/platforms/geeksforgeeks/index.js src/handlers/platforms/codeforces/index.js src/background/service-worker.js
git commit -m "feat: platform handlers emit platform-scoped problem ids (lc/gfg/cf)"
```

---

## Task 5: Update URL param `?problem=` to use platform-scoped id

**Files:**
- Modify: `src/library/views/ProblemsView.js`
- Modify: `src/library/views/AnalyticsView.js`
- Modify: `src/library/library.js`

The `?problem=` param now carries the platform-scoped id (`lc-two-sum`). All lookup code must match by `p.id` first, then fall back to `p.titleSlug` for backwards compatibility with old URLs.

- [ ] **Step 1: Update `ProblemsView.js` — emit `p.id` in URL, restore by id**

Find `handleSelectProblem`:
```js
updateQueryParams({ problem: problem.titleSlug || problem.id });
```
Change to:
```js
updateQueryParams({ problem: problem.id || problem.titleSlug });
```

Find the restore `useEffect` (around line 82):
```js
const found = problems.find(p => (p.id === problemId || p.titleSlug === problemId));
```
This already handles both — leave it as-is.

- [ ] **Step 2: Update `AnalyticsView.js` — emit `p.id` when opening modal**

Find the drill-down problem click (around line 572):
```js
onClick=${() => { setModalProblem(p); setModalProblemList(drilldown.problems); setDrilldown(null); }}
```
After setting modal problem, also update URL. Wrap in a handler function by replacing the `onClick` with:

First add the import at the top of the file if missing:
```js
import { getQueryParam, updateQueryParams } from "../../core/url-state.js";
```

Then change the onClick:
```js
onClick=${() => {
  setModalProblem(p);
  setModalProblemList(drilldown.problems);
  setDrilldown(null);
  updateQueryParams({ problem: p.id || p.titleSlug });
}}
```

And the `onClose` for the modal (around line 593):
```js
onClose=${() => { setModalProblem(null); setModalProblemList([]); updateQueryParams({ problem: null }); }}
```

- [ ] **Step 3: Update `library.js` — restore problem modal by id from URL**

Find where `enrichedProblems` and the `?problem=` param are used to restore the modal on load. The lookup should prefer `p.id`:

```js
const found = enrichedProblems.find(p => p.id === problemId || p.titleSlug === problemId);
```

This is likely already correct from Task 1 — verify it and leave as-is if so.

- [ ] **Step 4: Commit**

```bash
git add src/library/views/ProblemsView.js src/library/views/AnalyticsView.js src/library/library.js
git commit -m "feat: ?problem= URL param uses platform-scoped id"
```

---

## Task 6: URL persistence — Settings tab

**Files:**
- Modify: `src/library/views/SettingsPageView.js`

Currently `activePanel` always initialises to `"general"`. After this task it reads `settingsTab` from the URL on mount.

- [ ] **Step 1: Add URL param import**

At the top of `SettingsPageView.js`, add:
```js
import { getQueryParam, updateQueryParams } from "../../core/url-state.js";
```

- [ ] **Step 2: Initialise `activePanel` from URL**

Change:
```js
const [activePanel, setActivePanel] = useState("general");
```
To:
```js
const VALID_PANELS = new Set(["general", "ai", "git", "platforms", "backups", "advanced"]);
const initPanel = getQueryParam("settingsTab", "general");
const [activePanel, setActivePanel] = useState(VALID_PANELS.has(initPanel) ? initPanel : "general");
```

- [ ] **Step 3: Update URL on tab click**

Replace the existing `onClick` in the tab button:
```js
onClick=${() => setActivePanel(id)}
```
With:
```js
onClick=${() => { setActivePanel(id); updateQueryParams({ settingsTab: id }); }}
```

- [ ] **Step 4: Verify**

1. Open library → Settings → click "Git" tab
2. URL should now contain `?settingsTab=git`
3. Reload the page — "Git" tab should still be active

- [ ] **Step 5: Commit**

```bash
git add src/library/views/SettingsPageView.js
git commit -m "feat: settings tab persists in URL via ?settingsTab="
```

---

## Task 7: URL persistence — Solutions filters

**Files:**
- Modify: `src/library/views/ProblemsView.js`

Currently filter dropdowns (difficulty, platform, language, tag, sort) are in-memory only. After this task they survive reload.

- [ ] **Step 1: Init all filter state from URL params**

Replace the current filter `useState` initializations (lines 61-67):

```js
const [filterDifficulty, setFilterDifficulty] = useState("All");
const [filterPlatform,   setFilterPlatform]   = useState("All");
const [filterLanguage,   setFilterLanguage]   = useState("All");
const [filterTag,        setFilterTag]         = useState("All");
const [filterOverview,   setFilterOverview]   = useState("All");
const [query,            setQuery]             = useState(searchQuery || "");
const [sortBy,           setSortBy]            = useState("newest");
```

With:

```js
const [filterDifficulty, setFilterDifficulty] = useState(getQueryParam("difficulty", "All"));
const [filterPlatform,   setFilterPlatform]   = useState(getQueryParam("platform", "All"));
const [filterLanguage,   setFilterLanguage]   = useState(getQueryParam("language", "All"));
const [filterTag,        setFilterTag]         = useState(getQueryParam("tag", "All"));
const [filterOverview,   setFilterOverview]   = useState("All");  // not URL-persisted (niche)
const [query,            setQuery]             = useState(searchQuery || getQueryParam("q", ""));
const [sortBy,           setSortBy]            = useState(getQueryParam("sort", "newest"));
```

- [ ] **Step 2: Sync each filter setter to URL**

Add a `useEffect` that fires whenever any filter changes, to write them to the URL:

```js
useEffect(() => {
  updateQueryParams({
    difficulty: filterDifficulty !== "All" ? filterDifficulty : null,
    platform:   filterPlatform   !== "All" ? filterPlatform   : null,
    language:   filterLanguage   !== "All" ? filterLanguage   : null,
    tag:        filterTag        !== "All" ? filterTag        : null,
    sort:       sortBy           !== "newest" ? sortBy        : null,
  });
}, [filterDifficulty, filterPlatform, filterLanguage, filterTag, sortBy]);
```

- [ ] **Step 3: Verify**

1. Open solutions, set difficulty = "Hard", platform = "leetcode"
2. URL should contain `?difficulty=Hard&platform=leetcode`
3. Reload — filters should still be active and list should be filtered

- [ ] **Step 4: Commit**

```bash
git add src/library/views/ProblemsView.js
git commit -m "feat: solutions filter state persists in URL params"
```

---

## Task 8: URL persistence — Analytics sections

**Files:**
- Modify: `src/library/views/AnalyticsView.js`

When a user opens a drill-down panel (e.g. clicks a language segment), `?section=language&sectionFilter=Python` is written to the URL. On reload, the drill-down is restored.

- [ ] **Step 1: Import url-state (if not already imported)**

```js
import { getQueryParam, updateQueryParams } from "../../core/url-state.js";
```

- [ ] **Step 2: Restore drill-down from URL on mount**

Add a `useEffect` after `openDrilldown` is defined. This must run after `problems` is available:

```js
useEffect(() => {
  if (!problems?.length) return;
  const section = getQueryParam("section");
  const sectionFilter = getQueryParam("sectionFilter");
  if (!section || !sectionFilter) return;

  // Re-open the right drill-down based on section type
  if (section === "difficulty") {
    openDrilldown(sectionFilter, (p) => {
      const cat = mapDifficulty(p.difficulty, userMap);
      if (sectionFilter === "Unknown") return !cat || cat === "Unknown";
      return cat === sectionFilter;
    });
  } else if (section === "language") {
    openDrilldown(sectionFilter, (p) => normalizeLang(p.lang?.name || p.language || "") === sectionFilter);
  } else if (section === "platform") {
    openDrilldown(sectionFilter, (p) => (PLATFORM_META[p.platform]?.name || p.platform) === sectionFilter);
  } else if (section === "topic") {
    openDrilldown(sectionFilter, (p) => (p.tags || []).includes(sectionFilter) || p.topic === sectionFilter);
  }
}, [problems?.length]);  // only on initial load
```

- [ ] **Step 3: Write section to URL when drill-down opens**

Update `openDrilldown`:
```js
const openDrilldown = useCallback((label, filterFn, sectionType) => {
  setDrilldown({ label, problems: problems.filter(filterFn), sectionType });
  if (sectionType) updateQueryParams({ section: sectionType, sectionFilter: label });
}, [problems]);
```

Update every `openDrilldown` call to pass the section type as third arg:
```js
// handleDifficultyClick:
openDrilldown(label, filterFn, "difficulty");

// handleLanguageClick:
openDrilldown(label, (p) => normalizeLang(p.lang?.name || p.language || "") === label, "language");

// handlePlatformClick:
openDrilldown(label, (p) => (PLATFORM_META[p.platform]?.name || p.platform) === label, "platform");

// handleTopicClick:
openDrilldown(topic, (p) => (p.tags || []).includes(topic) || p.topic === topic, "topic");
```

- [ ] **Step 4: Clear section from URL when drill-down closes**

Find the `setDrilldown(null)` calls and add URL clear:
```js
// X button:
onClick=${() => { setDrilldown(null); updateQueryParams({ section: null, sectionFilter: null }); }}

// Background click:
onClick=${(e) => { if (e.target === e.currentTarget) { setDrilldown(null); updateQueryParams({ section: null, sectionFilter: null }); } }}
```

- [ ] **Step 5: Verify**

1. Open analytics → click "Python" in the languages chart
2. URL: `?tab=analytics&section=language&sectionFilter=Python`
3. Reload → Python drill-down panel reopens automatically

- [ ] **Step 6: Commit**

```bash
git add src/library/views/AnalyticsView.js
git commit -m "feat: analytics drill-down section persists in URL params"
```

---

## Task 9: Analytics — "View N problems" button opens ProblemModal

**Files:**
- Modify: `src/library/views/AnalyticsView.js`

The drill-down panel currently lists problems as clickable rows that open the modal one at a time. This task adds a "View all in modal →" button to the panel header that opens the first problem in ProblemModal with the full drill-down list for ←/→ navigation.

- [ ] **Step 1: Add button to drill-down panel header**

Find the drilldown panel header section (around line 558):
```js
<div class="flex items-center justify-between px-5 py-4 border-b border-white/5 shrink-0">
  <div class="flex flex-col">
    <span class="text-sm font-bold text-white">${drilldown.label}</span>
    <span class="text-[11px] text-slate-500">${drilldown.problems.length} problem...
  </div>
  <button onClick=${() => setDrilldown(null)} ...>✕</button>
</div>
```

Replace with:
```js
<div class="flex items-center justify-between px-5 py-4 border-b border-white/5 shrink-0">
  <div class="flex flex-col">
    <span class="text-sm font-bold text-white">${drilldown.label}</span>
    <span class="text-[11px] text-slate-500">${drilldown.problems.length} problem${drilldown.problems.length !== 1 ? "s" : ""}</span>
  </div>
  <div class="flex items-center gap-2">
    ${drilldown.problems.length > 0 ? html`
      <button
        class="text-xs px-3 py-1.5 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 hover:bg-cyan-500/20 transition-colors"
        onClick=${() => {
          const first = drilldown.problems[0];
          setModalProblem(first);
          setModalProblemList(drilldown.problems);
          setDrilldown(null);
          updateQueryParams({ section: null, sectionFilter: null, problem: first?.id || first?.titleSlug });
        }}
      >Browse ←→</button>
    ` : ""}
    <button onClick=${() => { setDrilldown(null); updateQueryParams({ section: null, sectionFilter: null }); }} class="text-slate-500 hover:text-white text-xl leading-none px-1">✕</button>
  </div>
</div>
```

- [ ] **Step 2: Verify**

1. Open analytics → click difficulty segment "Hard"
2. Drill-down panel appears with "Browse ←→" button
3. Click "Browse ←→" → ProblemModal opens on first hard problem
4. Use left/right buttons in modal to cycle through only hard problems (once keyboard nav is added in Task 10)

- [ ] **Step 3: Commit**

```bash
git add src/library/views/AnalyticsView.js
git commit -m "feat: analytics drill-down panel has 'Browse' button to open ProblemModal with list"
```

---

## Task 10: ProblemModal — keyboard ←/→ navigation

**Files:**
- Modify: `src/library/components/ProblemModal.js`

The modal already has prev/next buttons wired to `onNavigateProblem`. This task adds keyboard support: `ArrowLeft` = prev, `ArrowRight` = next. The `Escape` handler already exists as a model to follow.

- [ ] **Step 1: Add arrow key handler alongside the Escape handler**

Find the existing Escape `useEffect` (around line 136):
```js
useEffect(() => {
  if (!problem) return;
  const onKey = (e) => { if (e.key === "Escape") onClose(); };
  window.addEventListener("keydown", onKey);
  return () => window.removeEventListener("keydown", onKey);
}, [problem, onClose]);
```

Add a separate `useEffect` directly below it:

```js
useEffect(() => {
  if (!problem || !canNavigate) return;
  const onKey = (e) => {
    if (e.key === "ArrowLeft")  { e.preventDefault(); onNavigateProblem?.(problemList[(problemIndex - 1 + problemList.length) % problemList.length]); }
    if (e.key === "ArrowRight") { e.preventDefault(); onNavigateProblem?.(problemList[(problemIndex + 1) % problemList.length]); }
  };
  window.addEventListener("keydown", onKey);
  return () => window.removeEventListener("keydown", onKey);
}, [problem, canNavigate, problemIndex, problemList, onNavigateProblem]);
```

Note: `canNavigate` and `problemIndex` are already computed at lines 171-172 of the existing file.

- [ ] **Step 2: Verify**

1. Open a problem modal from solutions view with a filter active (e.g. Hard problems)
2. Press `←` / `→` — should cycle through only hard problems
3. Escape still closes the modal

- [ ] **Step 3: Commit**

```bash
git add src/library/components/ProblemModal.js
git commit -m "feat: ProblemModal arrow key navigation (← prev, → next within list)"
```

---

## Task 11: GraphView — URL-persist layout and pass filtered list to modal

**Files:**
- Modify: `src/library/views/GraphView.js`

Two fixes: (1) `layoutMode` writes to URL so reload restores it; (2) the modal receives only the graph-filtered problem list instead of all problems.

- [ ] **Step 1: Import url-state**

At the top of `GraphView.js`, add:
```js
import { getQueryParam, updateQueryParams } from "../../core/url-state.js";
```

- [ ] **Step 2: Init `layoutMode` from URL**

Change:
```js
const [layoutMode, setLayoutMode] = useState("layered");
```
To:
```js
const VALID_LAYOUTS = new Set(["layered", "circular", "force"]);
const initLayout = getQueryParam("graphLayout", "layered");
const [layoutMode, setLayoutMode] = useState(VALID_LAYOUTS.has(initLayout) ? initLayout : "layered");
```

- [ ] **Step 3: Write layoutMode to URL on change**

Find all `setLayoutMode(...)` calls and wrap them to also update URL. Likely in button click handlers (around line 1003). Replace:
```js
onClick=${() => setLayoutMode(mode.id)}
```
With:
```js
onClick=${() => { setLayoutMode(mode.id); updateQueryParams({ graphLayout: mode.id }); }}
```

- [ ] **Step 4: Compute filtered problem list for modal**

Add a `useMemo` that applies the active graph filters to `problems`, to be passed to ProblemModal:

```js
const graphFilteredProblems = useMemo(() => {
  let out = problems || [];
  if (filterDifficultyGraph !== "All") out = out.filter(p => p.difficulty === filterDifficultyGraph);
  if (filterPlatformGraph   !== "All") out = out.filter(p => p.platform   === filterPlatformGraph);
  if (filterTopicGraph      !== "All") out = out.filter(p => (p.tags || []).includes(filterTopicGraph) || p.topic === filterTopicGraph);
  if (filterSolved) out = out.filter(p => !!p.id); // all stored problems are "solved"
  if (graphSearch) {
    const q = graphSearch.toLowerCase();
    out = out.filter(p => (p.title || "").toLowerCase().includes(q) || (p.titleSlug || "").toLowerCase().includes(q));
  }
  return out;
}, [problems, filterDifficultyGraph, filterPlatformGraph, filterTopicGraph, filterSolved, graphSearch]);
```

- [ ] **Step 5: Pass `graphFilteredProblems` to ProblemModal**

Find the `<${ProblemModal}` render in GraphView (around line 1194) and change:
```js
problemList=${problems || []}
```
To:
```js
problemList=${graphFilteredProblems}
```

Also add URL update when modal opens. Find where `setModalProblem` is called on node click and add:
```js
setModalProblem(node);
updateQueryParams({ problem: node.id || node.titleSlug });
```

And when modal closes:
```js
onClose=${() => { setModalProblem(null); updateQueryParams({ problem: null }); }}
```

- [ ] **Step 6: Verify**

1. Graph with filter set to "Hard" only
2. Click a node → modal opens
3. Arrow keys / nav buttons cycle only through hard problems

- [ ] **Step 7: Commit**

```bash
git add src/library/views/GraphView.js
git commit -m "feat: graph layout persists in URL, modal nav scoped to filtered problem list"
```

---

## Task 12: `ConflictResolutionModal` component

**Files:**
- Create: `src/library/components/ConflictResolutionModal.js`

A reusable provider-agnostic modal. Shows pairs of conflicting problems (local vs remote), lets user pick keep-local or keep-remote per pair, and has bulk shortcuts.

- [ ] **Step 1: Create the file**

```js
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { h, useState, useMemo } from "../../vendor/preact-bundle.js";
import { htm } from "../../vendor/preact-bundle.js";
const html = htm.bind(h);

/**
 * ConflictResolutionModal
 *
 * Props:
 *   conflicts    — Array<{ local: Problem, remote: Problem }>
 *   remoteOnly   — Problem[]  (auto-imported after resolution, shown as info)
 *   onResolve    — (resolved: Problem[]) => void
 *   onCancel     — () => void
 *   providerName — string  e.g. "GitHub"
 */
export function ConflictResolutionModal({ conflicts, remoteOnly = [], onResolve, onCancel, providerName = "Remote" }) {
  // per-conflict choice: "local" | "remote" | null (unresolved)
  const [choices, setChoices] = useState(() => new Array(conflicts.length).fill(null));

  const allResolved = choices.every(c => c !== null);
  const resolvedCount = choices.filter(Boolean).length;

  function choose(i, side) {
    setChoices(prev => { const n = [...prev]; n[i] = side; return n; });
  }

  function acceptAll(side) {
    setChoices(new Array(conflicts.length).fill(side));
  }

  function handleApply() {
    const resolved = conflicts.map((c, i) => choices[i] === "remote" ? c.remote : c.local);
    // Include remoteOnly problems (no conflict, just not in local)
    onResolve([...resolved, ...remoteOnly]);
  }

  const DIFF_FIELDS = ["title", "difficulty", "code", "aiReview", "tags", "lang"];

  function diffSummary(local, remote) {
    return DIFF_FIELDS.filter(k => {
      const l = typeof local[k] === "object" ? JSON.stringify(local[k]) : String(local[k] ?? "");
      const r = typeof remote[k] === "object" ? JSON.stringify(remote[k]) : String(remote[k] ?? "");
      return l !== r;
    });
  }

  return html`
    <div class="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div class="bg-[#0a0a0f] border border-cyan-500/20 rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl">

        <!-- Header -->
        <div class="px-6 py-5 border-b border-white/5 flex items-center justify-between shrink-0">
          <div>
            <h2 class="text-lg font-bold text-white">Import from ${providerName}</h2>
            <p class="text-xs text-slate-500 mt-0.5">
              ${conflicts.length} conflict${conflicts.length !== 1 ? "s" : ""} · ${resolvedCount} resolved
              ${remoteOnly.length > 0 ? html` · ${remoteOnly.length} new problem${remoteOnly.length !== 1 ? "s" : ""} will be auto-imported` : ""}
            </p>
          </div>
          <div class="flex gap-2">
            <button onClick=${() => acceptAll("local")}  class="text-xs px-3 py-1.5 rounded-lg border border-white/10 text-slate-400 hover:text-white hover:border-white/20 transition-colors">Keep all local</button>
            <button onClick=${() => acceptAll("remote")} class="text-xs px-3 py-1.5 rounded-lg border border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10 transition-colors">Keep all remote</button>
          </div>
        </div>

        <!-- Conflict list -->
        <div class="overflow-y-auto flex-1 px-4 py-3 flex flex-col gap-3">
          ${conflicts.map((c, i) => {
            const diffs = diffSummary(c.local, c.remote);
            const choice = choices[i];
            return html`
              <div key=${c.local.id || i} class="border border-white/8 rounded-xl overflow-hidden">
                <!-- Problem header -->
                <div class="px-4 py-2.5 bg-white/[0.02] flex items-center justify-between">
                  <span class="text-sm font-medium text-slate-200">${c.local.title || c.local.id}</span>
                  <span class="text-[10px] text-slate-500">differs: ${diffs.join(", ") || "timestamps only"}</span>
                </div>
                <!-- Side-by-side -->
                <div class="grid grid-cols-2 divide-x divide-white/5">
                  ${["local", "remote"].map(side => {
                    const p = c[side];
                    const active = choice === side;
                    return html`
                      <button
                        onClick=${() => choose(i, side)}
                        class="text-left px-4 py-3 transition-colors ${active ? "bg-cyan-500/10 border-l-2 border-cyan-500" : "hover:bg-white/[0.03]"}"
                      >
                        <div class="flex items-center gap-2 mb-1.5">
                          <span class="text-[11px] font-semibold uppercase tracking-wide ${active ? "text-cyan-400" : "text-slate-500"}">${side}</span>
                          ${active ? html`<span class="text-[10px] text-cyan-400">✓ selected</span>` : ""}
                        </div>
                        <div class="text-[11px] text-slate-400 space-y-0.5">
                          <div>${p.difficulty || "?"} · ${p.lang?.name || "?"}</div>
                          <div class="text-slate-600">${new Date(p.timestamp || 0).toLocaleDateString()}</div>
                          ${p.code ? html`<div class="font-mono text-[10px] text-slate-600 truncate max-w-[220px]">${p.code.slice(0, 60)}…</div>` : ""}
                        </div>
                      </button>
                    `;
                  })}
                </div>
              </div>
            `;
          })}
        </div>

        <!-- Footer -->
        <div class="px-6 py-4 border-t border-white/5 flex items-center justify-between shrink-0">
          <button onClick=${onCancel} class="text-sm text-slate-500 hover:text-slate-300 transition-colors">Cancel</button>
          <button
            onClick=${handleApply}
            disabled=${!allResolved}
            class="px-5 py-2 rounded-xl text-sm font-medium transition-colors ${allResolved ? "bg-cyan-500 text-black hover:bg-cyan-400" : "bg-white/5 text-slate-600 cursor-not-allowed"}"
          >
            Apply & Import ${remoteOnly.length + conflicts.length} problem${(remoteOnly.length + conflicts.length) !== 1 ? "s" : ""}
          </button>
        </div>
      </div>
    </div>
  `;
}
```

- [ ] **Step 2: Verify the component renders (will be wired in Task 14)**

No runtime test yet — just ensure no syntax errors by importing it in the browser console or linting with `npm run lint`.

- [ ] **Step 3: Commit**

```bash
git add src/library/components/ConflictResolutionModal.js
git commit -m "feat: ConflictResolutionModal component for provider-agnostic import conflicts"
```

---

## Task 13: `importFromRepo()` in `sync-engine.js`

**Files:**
- Modify: `src/background/sync-engine.js`

Implement the import algorithm: fetch `index.json`, compare with local, return categorised results.

- [ ] **Step 1: Add imports to `sync-engine.js`**

```js
import { Storage } from "../core/storage.js";
import { CONSTANTS } from "../core/constants.js";
import { registry } from "../core/handler-registry.js";
import { createDebugger } from "../lib/debug.js";

const dbg = createDebugger("SyncEngine");
```

- [ ] **Step 2: Implement `importFromRepo()`**

Add this export:

```js
/**
 * Fetch index.json from the connected repo and categorise remote problems.
 * Returns { remoteOnly, conflicts } — does NOT write to storage (caller decides).
 *
 * @param {string} owner
 * @param {string} repo
 * @param {string} token
 * @returns {Promise<{ remoteOnly: Problem[], conflicts: Array<{local, remote}> }>}
 */
export async function importFromRepo(owner, repo, token) {
  const git = registry.getGitProvider("github");
  if (!git) throw new Error("GitHub provider not registered");

  // 1. Fetch index.json
  const res = await git.apiFetch(`/repos/${owner}/${repo}/contents/index.json`, token);
  const raw = atob((res.content || "").replace(/\n/g, ""));
  const index = JSON.parse(raw);
  const rawRemote = Array.isArray(index.problems) ? index.problems : [];

  // 2. Ensure all remote problems have platform-scoped ids
  const remoteProblems = rawRemote.map(p => {
    if (!p.id || !/^(lc|gfg|cf)-/.test(p.id)) {
      return { ...p, id: CONSTANTS.makeProblemId(p.platform || "unknown", p.titleSlug || "unknown") };
    }
    return p;
  });

  // 3. Load local
  const localProblems = await Storage.getAllProblems();
  const localById = new Map(localProblems.map(p => [p.id, p]));

  // 4. Categorise
  const COMPARE_FIELDS = ["title", "difficulty", "code", "tags", "lang", "aiReview"];
  const remoteOnly = [];
  const conflicts  = [];

  for (const remote of remoteProblems) {
    const local = localById.get(remote.id);
    if (!local) {
      remoteOnly.push(remote);
      continue;
    }
    // Check if any compare field differs
    const differs = COMPARE_FIELDS.some(k => {
      const l = typeof local[k]  === "object" ? JSON.stringify(local[k])  : String(local[k]  ?? "");
      const r = typeof remote[k] === "object" ? JSON.stringify(remote[k]) : String(remote[k] ?? "");
      return l !== r;
    });
    if (differs) conflicts.push({ local, remote });
  }

  dbg.log(`importFromRepo: ${remoteOnly.length} new, ${conflicts.length} conflicts`);
  return { remoteOnly, conflicts };
}

/**
 * Bulk-save resolved problems into local storage.
 * Call this after user resolves conflicts in ConflictResolutionModal.
 */
export async function applyImport(resolvedProblems) {
  for (const p of resolvedProblems) {
    await Storage.saveProblem(p);
  }
  dbg.log(`applyImport: saved ${resolvedProblems.length} problems`);
}
```

- [ ] **Step 3: Implement real `performSync()`**

Replace the stub:

```js
export const SyncEngine = {
  async performSync() {
    dbg.log("Initiating periodic cross-browser sync");
    const settings = await Storage.getSettings();
    if (settings.gitEnabled === false || settings.gitEnabled === 0) return;

    const git = registry.getGitProvider(settings.gitProvider || "github");
    if (!git) return;
    const token = await git.getToken().catch(() => null);
    if (!token) return;

    const owner = settings.github_owner || settings.github_username;
    const repo  = settings.github_repo  || settings.gitRepo;
    if (!owner || !repo) return;

    try {
      const { remoteOnly, conflicts } = await importFromRepo(owner, repo, token);

      if (conflicts.length > 0) {
        // Store pending conflicts so PanelGit can surface a banner
        await Storage.setSettings({ ...settings, _pendingConflicts: conflicts.length });
        dbg.warn(`Sync: ${conflicts.length} conflict(s) detected — user action required in Git settings`);
        return;
      }

      // Auto-merge: insert remoteOnly (no conflicts)
      await applyImport(remoteOnly);
      dbg.log(`Sync complete: imported ${remoteOnly.length} new problems`);
    } catch (e) {
      dbg.error("Sync failed", e.message);
    }
  },
};
```

- [ ] **Step 4: Commit**

```bash
git add src/background/sync-engine.js
git commit -m "feat: sync-engine implements importFromRepo() and real performSync()"
```

---

## Task 14: Wire import into `GitHubOnboardingModal` (mandatory)

**Files:**
- Modify: `src/ui/components/GitHubOnboardingModal.js`

When `linkExistingRepo()` finds a repo that already has `index.json`, it currently just saves the config and shows "done". After this task it runs the import and — if there are conflicts — shows `ConflictResolutionModal` before reaching "done".

- [ ] **Step 1: Import sync-engine functions and ConflictResolutionModal**

At top of `GitHubOnboardingModal.js`:
```js
import { importFromRepo, applyImport } from "../../background/sync-engine.js";
import { ConflictResolutionModal } from "../../library/components/ConflictResolutionModal.js";
```

- [ ] **Step 2: Add state for import UI**

After existing `useState` declarations in `GitHubOnboardingModal`:
```js
const [importData, setImportData] = useState(null); // { remoteOnly, conflicts, owner, repo }
```

- [ ] **Step 3: Update `linkExistingRepo()` to run import**

Find the section in `linkExistingRepo()` that saves config and sets step to "done" (around line 229):

```js
await saveRepoConfig(repoData.owner.login, repoData.name);
setFinalRepo(repoData.name);
setProgress("Repository linked!");
setStep("done");
```

Replace with:

```js
await saveRepoConfig(repoData.owner.login, repoData.name);
setFinalRepo(repoData.name);

// If repo has data, import it (mandatory)
if (Array.isArray(contents) && contents.some(f => f.name === "index.json")) {
  setProgress("Reading existing problems from repository…");
  const { remoteOnly, conflicts } = await importFromRepo(repoData.owner.login, repoData.name, token);

  if (conflicts.length > 0) {
    // Show conflict UI — do not proceed to "done" until resolved
    setImportData({ remoteOnly, conflicts, owner: repoData.owner.login, repo: repoData.name });
    setBusy(false);
    return; // ConflictResolutionModal renders below, handles completion
  }

  await applyImport(remoteOnly);
  setProgress(`Imported ${remoteOnly.length} problem${remoteOnly.length !== 1 ? "s" : ""} from repository`);
}

setProgress("Repository linked!");
setStep("done");
```

- [ ] **Step 4: Render ConflictResolutionModal and handle resolution**

In the component's return, before the main modal div, add:

```js
${importData ? html`
  <${ConflictResolutionModal}
    conflicts=${importData.conflicts}
    remoteOnly=${importData.remoteOnly}
    providerName="GitHub"
    onResolve=${async (resolved) => {
      setBusy(true);
      await applyImport(resolved);
      setImportData(null);
      setProgress(`Imported ${resolved.length} problem${resolved.length !== 1 ? "s" : ""} from repository`);
      setStep("done");
      setBusy(false);
    }}
    onCancel=${() => {
      // User cancelled — still link the repo but skip import
      setImportData(null);
      setStep("done");
    }}
  />
` : ""}
```

- [ ] **Step 5: Verify**

1. Have a GitHub repo with an existing CodeLedger `index.json` containing 3 problems
2. Open onboarding → "Link existing repository" → select that repo
3. If local has 0 problems: all 3 imported automatically, "done" screen appears
4. If local has 2 overlapping problems: ConflictResolutionModal shows with 2 conflict rows + "1 new problem will be auto-imported"
5. Choose keep-local/keep-remote per conflict → Apply → "done" screen appears

- [ ] **Step 6: Commit**

```bash
git add src/ui/components/GitHubOnboardingModal.js
git commit -m "feat: repo import is mandatory during onboarding, shows ConflictResolutionModal on conflicts"
```

---

## Task 15: PanelGit — manual import button + conflict indicator

**Files:**
- Modify: `src/library/settings-panels/PanelGit.js`

Add a "Import from GitHub" button so users can re-run the import at any time. Also show a banner when `_pendingConflicts` is set in settings (written by `performSync()` in Task 13).

- [ ] **Step 1: Import sync-engine and ConflictResolutionModal**

At top of `PanelGit.js`:
```js
import { importFromRepo, applyImport } from "../../background/sync-engine.js";
import { ConflictResolutionModal } from "../components/ConflictResolutionModal.js";
```

- [ ] **Step 2: Add state**

Inside `PanelGit` component:
```js
const [importData,    setImportData]    = useState(null);
const [importing,     setImporting]     = useState(false);
const [importMsg,     setImportMsg]     = useState("");
```

- [ ] **Step 3: Add `handleImport` function**

```js
const handleImport = async () => {
  setImporting(true);
  setImportMsg("");
  try {
    const git   = registry.getGitProvider(settings.gitProvider || "github");
    const token = await git.getToken();
    const owner = settings.github_owner || settings.github_username;
    const repo  = settings.github_repo  || settings.gitRepo;
    const { remoteOnly, conflicts } = await importFromRepo(owner, repo, token);

    if (conflicts.length > 0) {
      setImportData({ remoteOnly, conflicts });
    } else {
      await applyImport(remoteOnly);
      setImportMsg(`Imported ${remoteOnly.length} new problem${remoteOnly.length !== 1 ? "s" : ""}`);
      // Clear pending conflict flag if it was set
      await onSettingsChange({ _pendingConflicts: 0 });
    }
  } catch (e) {
    setImportMsg(`Import failed: ${e.message}`);
  } finally {
    setImporting(false);
  }
};
```

- [ ] **Step 4: Add conflict banner and import button to the JSX**

Find the existing section in PanelGit where Git status/actions are shown. Add before the return's closing tag:

```js
${settings._pendingConflicts > 0 ? html`
  <div class="flex items-center gap-3 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20">
    <span class="text-amber-400 text-sm">⚠ ${settings._pendingConflicts} conflict${settings._pendingConflicts !== 1 ? "s" : ""} detected during background sync.</span>
    <button onClick=${handleImport} class="text-xs text-amber-300 underline hover:no-underline">Resolve now</button>
  </div>
` : ""}

<!-- Import button -->
${settings.github_repo || settings.gitRepo ? html`
  <div class="flex items-center justify-between">
    <div>
      <p class="text-sm font-medium text-slate-200">Import from repository</p>
      <p class="text-xs text-slate-500">Pull all problems from your connected repo into the local library.</p>
    </div>
    <button
      onClick=${handleImport}
      disabled=${importing}
      class="px-4 py-2 rounded-xl text-sm font-medium bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 transition-colors disabled:opacity-50"
    >
      ${importing ? "Importing…" : "Import"}
    </button>
  </div>
  ${importMsg ? html`<p class="text-xs text-cyan-400">${importMsg}</p>` : ""}
` : ""}

${importData ? html`
  <${ConflictResolutionModal}
    conflicts=${importData.conflicts}
    remoteOnly=${importData.remoteOnly}
    providerName="GitHub"
    onResolve=${async (resolved) => {
      await applyImport(resolved);
      setImportData(null);
      setImportMsg(`Imported ${resolved.length} problem${resolved.length !== 1 ? "s" : ""}`);
      await onSettingsChange({ _pendingConflicts: 0 });
    }}
    onCancel=${() => setImportData(null)}
  />
` : ""}
```

- [ ] **Step 5: Verify**

1. Open Settings → Git
2. "Import" button visible when a repo is connected
3. Click it → imports new problems or shows ConflictResolutionModal if conflicts exist
4. After `performSync()` detects conflicts, a warning banner appears on next Settings → Git visit

- [ ] **Step 6: Commit**

```bash
git add src/library/settings-panels/PanelGit.js
git commit -m "feat: PanelGit has manual import button and conflict warning banner"
```

---

## Task 16: OPENAPI.yaml — extension URL scheme appendix

**Files:**
- Modify: `docs/OPENAPI.yaml`

The OPENAPI.yaml covers the Cloudflare Worker HTTP API. Add an `x-extension-urls` extension field documenting the browser extension's internal URL param scheme.

- [ ] **Step 1: Append to `docs/OPENAPI.yaml`**

Add at the end of the file:

```yaml
x-extension-urls:
  description: >
    Browser extension internal URL params (library.html page, not HTTP endpoints).
    All params use window.history.replaceState — no page reload occurs on change.
  base: chrome-extension://{ext-id}/library/library.html
  params:
    tab:
      values: [solutions, analytics, graph, ai-chats, canonical, settings, search]
      description: Active top-level view
    settingsTab:
      values: [general, ai, git, platforms, backups, advanced]
      description: Active settings panel tab (only when tab=settings)
    problem:
      format: "{platformCode}-{titleSlug}"
      example: "lc-two-sum"
      description: Open ProblemModal for this problem id
    q:
      description: Search query (solutions view)
    difficulty:
      values: [Easy, Medium, Hard]
      description: Difficulty filter (solutions view)
    platform:
      values: [leetcode, geeksforgeeks, codeforces]
      description: Platform filter (solutions view)
    language:
      description: Language filter, matches lang.name (solutions view)
    sort:
      values: [newest, oldest, diff-asc, diff-desc, title, platform, tags]
      description: Sort order (solutions view)
    tag:
      description: Tag/topic filter (solutions view)
    section:
      values: [difficulty, language, platform, topic]
      description: Open analytics drill-down panel (only when tab=analytics)
    sectionFilter:
      description: Value for the section filter, e.g. "Python" or "Hard"
    graphLayout:
      values: [layered, circular, force]
      description: Graph layout mode (only when tab=graph)
  examples:
    - url: "library.html?tab=settings&settingsTab=git"
      description: Open settings directly on the Git tab
    - url: "library.html?tab=solutions&difficulty=Hard&platform=leetcode"
      description: Solutions filtered to hard LeetCode problems
    - url: "library.html?tab=solutions&problem=lc-two-sum"
      description: Open Two Sum modal (LeetCode)
    - url: "library.html?tab=analytics&section=language&sectionFilter=Python"
      description: Analytics with Python drill-down panel open
    - url: "library.html?tab=graph&graphLayout=force&problem=lc-two-sum"
      description: Graph in force layout with Two Sum modal open
```

- [ ] **Step 2: Commit**

```bash
git add docs/OPENAPI.yaml
git commit -m "docs: add x-extension-urls scheme to OPENAPI.yaml"
```

---

## Self-Review Notes

**Spec coverage:**
- ✅ Platform-scoped ids (`lc-`, `gfg-`, `cf-`) — Tasks 1-4
- ✅ Data migration — Task 3
- ✅ path-builder updated — Task 2
- ✅ Settings tab URL persistence — Task 6
- ✅ Solutions filter URL persistence — Task 7
- ✅ Analytics section URL persistence — Task 8
- ✅ Analytics "View problems" button — Task 9
- ✅ Graph layout URL persistence — Task 11
- ✅ Graph modal uses filtered list — Task 11
- ✅ Keyboard ←/→ in ProblemModal — Task 10
- ✅ ConflictResolutionModal — Task 12
- ✅ importFromRepo() + applyImport() — Task 13
- ✅ Real performSync() — Task 13
- ✅ Mandatory import in onboarding — Task 14
- ✅ Manual import in PanelGit — Task 15
- ✅ OPENAPI.yaml — Task 16

**Type/name consistency check:**
- `makeProblemId` — defined Task 1, used Tasks 3, 4, 13 ✅
- `importFromRepo(owner, repo, token)` — defined Task 13, used Tasks 14, 15 ✅
- `applyImport(resolvedProblems)` — defined Task 13, used Tasks 14, 15 ✅
- `ConflictResolutionModal` props: `conflicts`, `remoteOnly`, `providerName`, `onResolve`, `onCancel` — defined Task 12, used Tasks 14, 15 ✅
- `graphFilteredProblems` — defined and used in Task 11 ✅
- `problemBase(id, canonical, settings)` first arg renamed — updated in Task 2, all callers updated ✅
