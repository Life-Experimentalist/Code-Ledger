# Release Quick Start

This is an archived quick reference. The canonical release walkthrough lives in [../guides/RELEASE_GUIDE.md](../guides/RELEASE_GUIDE.md).

## Fast Path

1. Update the changelog in [../archive/changelog.md](../archive/changelog.md).
2. Bump the version in both [../../src/manifest.json](../../src/manifest.json) and [../../package.json](../../package.json).
3. Run `npm run release`.

## Preview

Run `npm run release -- --dry-run` to validate everything without creating release artifacts or git tags.

## Versioning

The policy details live in [../guides/release-versioning.md](../guides/release-versioning.md).
