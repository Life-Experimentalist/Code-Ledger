# CodeLedger — AI, Settings & Theming Overhaul

> **For agentic workers:** Use `superpowers:subagent-driven-development` or `superpowers:executing-plans` to execute this plan. Steps use checkbox (`- [ ]`) syntax. Work phases in order; do not start Phase N+1 until Phase N is verified.

**Goal:** Deliver five coordinated improvements — (1) AI chat polish with correct timezone, command expansion, real markdown/math/mermaid rendering, and model visibility; (2) editor-embedded AI with live code and test-failure context; (3) a GitHub-backed AI behaviour bank; (4) a coherent settings overhaul following the Ranobe Gemini pattern; and (5) a modular theming system covering every UI surface — library, popup, floating panels, and injected content-script buttons.

**Guiding constraints:**
- No bundler. Pure ES6 modules. CDN vendor shims via `src/vendor/`.
- All browser APIs go through `src/lib/browser-compat.js`.
- No `console.log` — use `createDebugger()`.
- Preact + htm for all new Preact components.
- Tailwind only for `compiled.css`; new CSS surfaces that need theming use CSS custom properties (not Tailwind utilities).

---

## Reference Material

| Resource | Purpose |
|----------|---------|
| `env/Ranobe-gemini_v4.6.0_source/src/utils/theme-config.js` | Source of truth for `THEME_PRESETS`, `resolveMode`, `setThemeVariables`, `applyThemeFromStorage` — copy and adapt for CodeLedger |
| `env/Ranobe-gemini_v4.6.0_source/src/library/library-settings.html` | Settings page layout pattern: sidebar nav + `ls-panel` sections |
| `src/lib/chat-variables.js` | Existing command definitions + `expandChatVariables()` |
| `src/core/ai-prompts.js` | Prompt templates per platform |
| `src/ui/components/AIMarkdownRenderer.js` | Current regex-based renderer — extend in-place |
| `src/library/components/ProblemModal.js` | Problem modal tab registry + chat surface |
| `src/ui/floating-ai.js` | Content-script floating AI panel |
| `src/ui/components/SettingsSchema.js` | Current schema-driven settings renderer (to be replaced) |
| `src/library/views/SettingsView.js` | Settings page wrapper (to be overhauled) |
| `src/handlers/platforms/leetcode/index.js` | Timestamp normalisation at line 992 |
| `src/ui/components/HeatMap.js` | `toDateStr` (local) / `fmtDateLabel` (UTC bug at line 23) |
| `src/library/views/AnalyticsView.js` | Date grouping for problem lists |
| `src/core/storage.js` | Storage abstraction — add theme key |
| `src/core/constants.js` | Add `SK.THEME`, `SK.BEHAVIOR_BANK` keys |
| `src/background/service-worker.js` | Handle `AI_CHAT`, `BEHAVIOR_BANK_SYNC` messages |

---

## File Map

### New files

| Path | Purpose |
|------|---------|
| `src/core/theme-engine.js` | Ported + adapted from Ranobe `theme-config.js` — all preset definitions, `resolveMode`, `setThemeVariables`, `applyThemeFromStorage`, `setupThemeListener` |
| `src/vendor/mermaid-stub.js` | Lazy-loads mermaid from CDN (`https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.min.js`); exposes `renderMermaid(id, src)` → Promise\<svg\> |
| `src/vendor/katex-stub.js` | Lazy-loads KaTeX from CDN; exposes `renderMath(tex, display)` → HTML string |
| `src/ui/components/ThemePicker.js` | Preact component: mode pills (Dark/Light/Auto), auto-behavior radios, preset skin dropdown, live preview strip, color pickers, save-as-custom, font-size slider |
| `src/ui/components/ModelStatusBar.js` | Compact bar showing current provider + model + fallback badge; used in AI chat surfaces |
| `src/ui/components/AIPromptModeSelector.js` | Floating AI prompt-mode tabs: Tutor / Debug / Optimize / Review / Custom |
| `src/core/behavior-bank.js` | Read/write user behaviour records to IndexedDB; sync to GitHub as `config/behavior-bank.json` |
| `src/library/views/SettingsPageView.js` | New settings page: sidebar nav + panel rendering, replaces current `SettingsView.js` logic |
| `src/library/settings-panels/PanelGeneral.js` | Theme, font size, display preferences |
| `src/library/settings-panels/PanelAI.js` | AI provider, models (primary + fallback), API keys, rotation, temperature, prompt templates, model status |
| `src/library/settings-panels/PanelGit.js` | GitHub repo setup, PAT / OAuth toggle, commit message template, problems dir, mirrors (correct push-mirror pattern), GitHub-stored config |
| `src/library/settings-panels/PanelPlatforms.js` | Per-platform overrides (LeetCode, GFG, Codeforces): auto-commit toggle, difficulty map, branch, tag prefix |
| `src/library/settings-panels/PanelBackups.js` | Local rolling backups (browser storage, last 5), manual export/import, periodic GitHub backup |
| `src/library/settings-panels/PanelAdvanced.js` | Telemetry, debug mode, behavior bank opt-in, factory reset |
| `src/ui/styles/theme-variables.css` | CSS custom property declarations used by non-Tailwind surfaces (floating-ai, timer, injected buttons) |

### Modified files

| Path | Changes |
|------|---------|
| `src/core/constants.js` | Add `SK.THEME = "themeSettings"`, `SK.BEHAVIOR_BANK = "behaviorBank"`, `SK.ROLLING_BACKUPS = "rollingBackups"` |
| `src/core/storage.js` | Add `getTheme()`, `setTheme()`, `getBehaviorBank()`, `setBehaviorBank()`, `getRollingBackups()`, `addRollingBackup()` |
| `src/ui/components/AIMarkdownRenderer.js` | Replace mermaid stub block with real `renderMermaid()` call; replace math stub block with real KaTeX call; export updated `parseMarkdown` |
| `src/lib/chat-variables.js` | `expandChatVariables` — add live editor-code reader + DOM-sourced test failures as context inputs |
| `src/lib/ai-chat-context.js` | Add `promptMode` field to context object; route to different system prompt based on mode |
| `src/library/components/ProblemModal.js` | Call `expandChatVariables(text, ctx)` before sending; enrich Overview tab with constraints / similar / hints sub-sections |
| `src/library/views/AIChatsView.js` | Call `expandChatVariables` before sending; show `ModelStatusBar` above chat input |
| `src/library/views/GraphView.js` | Problem node click → open `ProblemModal` (currently broken) |
| `src/ui/floating-ai.js` | Add prompt-mode selector; read test-failure DOM; pass `promptMode` in context |
| `src/ui/floating-timer.js` | Read `--primary-color` from CSS vars for glow color instead of hardcoded cyan |
| `src/handlers/platforms/leetcode/index.js` | Fix `tsMs` line 993: guard against already-ms timestamps properly (current check is at line 722 for REST but not for the live submission path) |
| `src/ui/components/HeatMap.js` | Fix `fmtDateLabel` line 23: change `"T00:00:00Z"` → `"T12:00:00"` (no Z, local noon avoids DST edge) |
| `src/library/views/AnalyticsView.js` | Audit all `new Date(ts)` + `toLocaleDateString` for UTC boundary issues; use same `toDateStr` from HeatMap |
| `src/library/library.js` | On startup: call `applyThemeFromStorage()` + `setupThemeListener()`; render new `SettingsPageView` for settings tab |
| `src/popup/popup.js` | On load: call `applyThemeFromStorage()` + `setupThemeListener()` |
| `src/content/handler-loader.js` | After platform handler init: inject theme CSS vars into page for floating panels |
| `src/background/service-worker.js` | Add `BEHAVIOR_BANK_SYNC` message handler; add `PERIODIC_BACKUP` alarm handler |
| `src/background/alarm-manager.js` | Register `periodic-backup` alarm (configurable interval, default 24h) |
| `src/handlers/git/github/index.js` | Add `pushMirrors(commitSha)` helper: after every commit replicate to configured GitLab/Bitbucket mirrors; add `storeConfigFiles()` for GitHub-stored config |
| `src/ui/styles/compiled.css` | Regenerate after Tailwind changes (`npm run build:css`) |
| `docs/CLAUDE.md` (project) | Add theming section, settings architecture note, behavior bank note |

---

## Phase 1 — AI Chat Polish

**Goal:** Fix timezone grouping, expand chat commands properly, render markdown/math/mermaid correctly, show model status, enrich problem description panel.

---

### Task 1.1 — Timezone date grouping fix

**Files:** `src/ui/components/HeatMap.js`, `src/library/views/AnalyticsView.js`

**Root cause:** `fmtDateLabel` at `HeatMap.js:23` does `new Date(dateStr + "T00:00:00Z")` which forces UTC midnight interpretation. For IST (UTC+5:30) a date key of `"2024-01-15"` becomes `2024-01-15 05:30 AM IST`, so `toLocaleDateString` displays the correct date — but if the user's clock is behind UTC (e.g. UTC-5) the heatmap label shows the **previous** local date. Fix: parse as local noon to avoid DST and timezone edge cases.

**`AnalyticsView.js`:** audit for any direct `new Date(ts).toUTCString()` or UTC-based date keys.

- [ ] In `HeatMap.js:23` change `dateStr + "T00:00:00Z"` → `dateStr + "T12:00:00"` (no Z suffix; local noon)
- [ ] In `AnalyticsView.js` find any date grouping that does `.toISOString().slice(0,10)` (returns UTC date) and replace with the same local `toDateStr()` helper imported from HeatMap
- [ ] Verify `toDateStr` in `HeatMap.js:40` uses `getFullYear()`, `getMonth()`, `getDate()` (local — already correct)

---

### Task 1.2 — Command expansion before send

**Files:** `src/library/components/ProblemModal.js`, `src/library/views/AIChatsView.js`

**Root cause:** Both send surfaces call the AI with the raw text string. `expandChatVariables(text, ctx)` exists in `chat-variables.js` but is never called in these two surfaces; the SW receives un-expanded `/mycode` literals instead of actual code.

- [ ] In `ProblemModal.js` `sendChat()`: call `expandChatVariables(text, { problem, userCode: problem.code, hints: problem.hints, similar: problem.similar, constraints: problem.constraints })` before building `userMsg`
- [ ] In `AIChatsView.js` `sendNewChat()` and `sendReplyToSelectedChat()`: call `expandChatVariables(text, context)` using the assembled `context` object (which already has `code`, `problemStatement`, etc.)
- [ ] Ensure `expandChatVariables` is async — it already is; `await` it

---

### Task 1.3 — Real mermaid rendering

**Files:** `src/vendor/mermaid-stub.js` (new), `src/ui/components/AIMarkdownRenderer.js`

Mermaid currently renders as a styled `<pre>` block with the source text. We need actual SVG diagrams.

**Approach:** Lazy-load mermaid from CDN on first diagram encounter. In a content-script-safe context (extension pages + library page) CDN fetches work. Floating AI panels run in the page context — also fine.

- [ ] Create `src/vendor/mermaid-stub.js`:
  ```js
  let _mermaid = null;
  const CDN = "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.min.js";
  export async function renderMermaid(id, src) {
    if (!_mermaid) {
      await new Promise((res, rej) => {
        const s = document.createElement("script");
        s.src = CDN; s.onload = res; s.onerror = rej;
        document.head.appendChild(s);
      });
      _mermaid = window.mermaid;
      _mermaid.initialize({ startOnLoad: false, theme: "dark" });
    }
    const { svg } = await _mermaid.render(id, src);
    return svg;
  }
  ```
- [ ] In `AIMarkdownRenderer.js` `parseMarkdown`: replace the mermaid stash block with an async-capable placeholder. Because `parseMarkdown` is sync, use a two-pass approach: stash `data-mermaid-src` attributes, then after `dangerouslySetInnerHTML` fires, run a `useEffect` that finds those placeholders and calls `renderMermaid` to replace them with SVG.
- [ ] Add `useEffect` in `AIMarkdownRenderer` component to find `[data-mermaid-pending]` divs and render them after mount/update

---

### Task 1.4 — Real KaTeX math rendering

**Files:** `src/vendor/katex-stub.js` (new), `src/ui/components/AIMarkdownRenderer.js`

Current math rendering substitutes `\times` → `×` etc. but leaves raw LaTeX otherwise. KaTeX renders it properly.

- [ ] Create `src/vendor/katex-stub.js`:
  ```js
  let _katex = null;
  const CSS_CDN = "https://cdn.jsdelivr.net/npm/katex@0.16/dist/katex.min.css";
  const JS_CDN = "https://cdn.jsdelivr.net/npm/katex@0.16/dist/katex.min.js";
  export async function ensureKatex() {
    if (_katex) return _katex;
    if (!document.querySelector(`link[href="${CSS_CDN}"]`)) {
      const l = document.createElement("link");
      l.rel = "stylesheet"; l.href = CSS_CDN;
      document.head.appendChild(l);
    }
    await new Promise((res, rej) => {
      const s = document.createElement("script");
      s.src = JS_CDN; s.onload = res; s.onerror = rej;
      document.head.appendChild(s);
    });
    _katex = window.katex;
    return _katex;
  }
  export function renderMath(tex, display = false) {
    if (!_katex) return `<span class="math-pending" data-tex="${tex.replace(/"/g,'&quot;')}" data-display="${display}"></span>`;
    try { return _katex.renderToString(tex, { throwOnError: false, displayMode: display }); }
    catch { return `<code>${tex}</code>`; }
  }
  ```
- [ ] `parseMarkdown`: keep the stash approach for `$$...$$` (display) and `$...$` (inline); call `renderMath(tex, true/false)` synchronously (it returns pending span if KaTeX not yet loaded)
- [ ] `AIMarkdownRenderer` `useEffect`: call `ensureKatex()` on mount, then replace `.math-pending` spans with rendered KaTeX

---

### Task 1.5 — Model status bar

**Files:** `src/ui/components/ModelStatusBar.js` (new), `src/library/views/AIChatsView.js`, `src/library/components/ProblemModal.js`, `src/ui/floating-ai.js`

Show which AI provider + model is active, and which is the fallback. This reads from `settings.aiProvider`, `settings.aiPrimaryModel`, `settings.aiSecondary`, `settings.aiSecondaryModel`.

- [ ] Create `ModelStatusBar.js` — a compact Preact component:
  - Primary: `{providerBadge} {modelName}` in cyan
  - If fallback configured: `→ {fallbackProvider} {fallbackModel}` in slate
  - On hover: tooltip showing full model IDs
  - Props: `settings` object
- [ ] Add `<ModelStatusBar settings={settings} />` above the chat input in `AIChatsView.js`
- [ ] Add the same bar above the chat input in `ProblemModal.js` chat tab
- [ ] In `floating-ai.js` add a small `[provider/model]` text indicator in the panel header (vanilla JS, no Preact — use a `<span>` with `data-cl-model` attribute, populated from `Storage.getSettings()`)

---

### Task 1.6 — Problem description panel enrichment

**Files:** `src/handlers/platforms/leetcode/modal-tabs.js`

The Overview tab already renders `problem.problemStatement` when cached. Add collapsible sub-sections for Constraints, Hints (already exist as `<details>`), Similar Problems, and Topics.

- [ ] Add Constraints sub-section below `problemStatement` if `problem.constraints` is non-empty:
  ```
  <div class="mt-3 border-t border-white/5 pt-3">
    <p class="text-[10px] uppercase tracking-wider text-slate-600 mb-1">Constraints</p>
    <pre class="text-xs text-slate-400 font-mono whitespace-pre-wrap">{problem.constraints}</pre>
  </div>
  ```
- [ ] Add Similar Problems sub-section if `problem.similar?.length > 0`: list of clickable links
- [ ] Hints: already rendered as `<details>` — keep but style consistently
- [ ] Topics row: already rendered above the tab bar in `ProblemModal.js` header — no duplicate needed

---

## Phase 2 — Editor AI + Cross-Problem Context

**Goal:** Floating AI panel reads live code and test failures from the page DOM; supports prompt modes; allows attaching stored problems as context.

---

### Task 2.1 — Live test failure ingestion

**Files:** `src/ui/floating-ai.js`, `src/lib/chat-variables.js`

When the user runs "Test" or "Submit" on LeetCode, test case results appear in the DOM. The floating AI should capture them.

**LeetCode test result DOM paths (observed):**
- Wrong Answer: `.result-error`, `[data-e2e-locator="console-result"]`
- Runtime Error: `.runtime-error`, `.error-container`
- Compile Error: `.compile-error`

- [ ] In `floating-ai.js` add `readTestFailures()` function:
  ```js
  function readTestFailures() {
    const resultEl = document.querySelector('[data-e2e-locator="console-result"]')
      || document.querySelector('.result-error');
    if (!resultEl) return [];
    const statusEl = document.querySelector('[data-e2e-locator="submission-result"]');
    const status = statusEl?.textContent?.trim() || "Unknown";
    const input = document.querySelector('.testcase-input-area')?.textContent?.trim() || "";
    const expected = document.querySelector('.expected-output')?.textContent?.trim() || "";
    const actual = resultEl.textContent?.trim() || "";
    return [{ status, input, expected, actual }];
  }
  ```
- [ ] Pass `failures` into `buildAIChatContext` as `errors` field
- [ ] Update `expandChatVariables` to use `failures` when expanding `/errors`

---

### Task 2.2 — Prompt mode selector

**Files:** `src/ui/components/AIPromptModeSelector.js` (new), `src/ui/floating-ai.js`, `src/lib/ai-chat-context.js`

Modes: **Tutor** (explain step-by-step), **Debug** (find what's wrong), **Optimize** (improve complexity), **Review** (code quality), **Custom** (raw).

Each mode prepends a different system instruction into the AI context.

- [ ] Create `AIPromptModeSelector.js`: horizontal tab strip with 5 modes; returns selected mode ID via `onChange` prop
- [ ] In `floating-ai.js`: render mode tabs above the text input (vanilla DOM, no framework); store selected mode in panel state; pass `promptMode` to `buildAIChatContext`
- [ ] In `ai-chat-context.js` `buildAIChatContext`: add `promptMode` to returned context object; map modes to system instruction strings:
  ```
  tutor:    "You are a DSA tutor. Explain concepts step-by-step. Do not give full solutions."
  debug:    "You are a debugger. Identify the exact bug and explain why it fails."
  optimize: "You are an algorithm optimizer. Suggest time/space complexity improvements."
  review:   "You are a code reviewer. Comment on style, correctness, and edge cases."
  custom:   "" (no system prefix)
  ```
- [ ] `MultiLineAIChatInput.js`: add optional `promptMode` prop and show the mode selector inline
- [ ] In `ProblemModal.js` chat tab and `AIChatsView.js`: add mode selector above chat input

---

### Task 2.3 — Cross-problem context attachment from floating AI

**Files:** `src/ui/floating-ai.js`

Currently the floating AI only attaches the current problem. Allow attaching stored problems by slug.

- [ ] Add a collapsible "Attach problem context" section in the floating panel (vanilla DOM)
- [ ] On expand: load last 10 solved problems from IndexedDB via `chrome.runtime.sendMessage({ type: "GET_PROBLEMS" })` (or directly via `Storage` if accessible)
- [ ] Render as clickable chips; selected problems are appended to context in `buildAIChatContext` under `attachedProblems`
- [ ] Cap at 3 attachments to keep prompt size reasonable

---

## Phase 3 — AI Behaviour Bank

**Goal:** Opt-in tracking of user solve patterns, stored locally and synced to GitHub as `config/behavior-bank.json`.

---

### Task 3.1 — Core behaviour bank module

**Files:** `src/core/behavior-bank.js` (new), `src/core/constants.js`, `src/core/storage.js`

A behaviour record captures per-problem data: attempts, time-to-solve, commands used, AI modes used, hints viewed, AI review requested, whether solution passed on first submit.

```js
// Schema for one record
{
  slug: string,
  platform: string,
  attempts: number,           // incremented each time problem:solved fires
  firstSolveMs: number,       // timestamp of first solve
  lastSolveMs: number,
  totalElapsedSeconds: number,
  commandsUsed: string[],     // union of all /commands used across chats
  modesUsed: string[],        // tutor/debug/optimize/review
  hintsViewed: number,
  aiChatsCount: number,
  passedFirstSubmit: boolean,
}
```

- [ ] Add `SK.BEHAVIOR_BANK = "cl-behavior-bank"` to `constants.js`
- [ ] Add `getBehaviorBank()`, `setBehaviorBank()`, `updateBehaviorRecord(slug, delta)` to `storage.js`
- [ ] Create `behavior-bank.js`:
  - `recordSolve(problemData)` — called by SW on `problem:solved`
  - `recordChatInteraction(slug, commands, mode)` — called by SW on `AI_CHAT`
  - `recordHintView(slug)` — called by ProblemModal hints tab
  - `getRecord(slug)` / `getAllRecords()` / `exportJSON()`
- [ ] Wire `recordSolve` in `service-worker.js` after successful commit (opt-in check first)
- [ ] Wire `recordChatInteraction` in SW `AI_CHAT` handler

---

### Task 3.2 — GitHub sync for behaviour bank

**Files:** `src/handlers/git/github/index.js`, `src/background/service-worker.js`

Store the bank as `config/behavior-bank.json` in the user's repo. Sync on a schedule (default: after every 5 solves, or daily alarm).

- [ ] In `GitHubHandler`: add `storeConfigFile(path, content)` — single-file commit to `config/` dir using Contents API (small file, no need for Trees API overhead)
- [ ] Add `BEHAVIOR_BANK_SYNC` message in SW: export JSON, call `storeConfigFile("config/behavior-bank.json", json)`
- [ ] Add alarm `behavior-bank-sync` in `alarm-manager.js` (fires every 24h if opt-in enabled)
- [ ] On SW startup: check if opt-in and register alarm

---

### Task 3.3 — Opt-in toggle in settings

**Files:** `src/library/settings-panels/PanelAdvanced.js`

- [ ] Add toggle `"Enable AI Behaviour Bank"` with description "Tracks your solve patterns (time, hints, AI usage) per problem. Data stays in your GitHub repo under `config/behavior-bank.json`."
- [ ] Add `"Sync now"` button that triggers `BEHAVIOR_BANK_SYNC`
- [ ] Add `"Clear local data"` that calls `setBehaviorBank({})`

---

## Phase 4 — Settings Overhaul

**Goal:** Replace the current schema-driven flat settings with a Ranobe Gemini–style sidebar + panels layout. Fix Git mirrors. Add periodic backup. Store config files in GitHub.

---

### Task 4.1 — Settings page architecture

**Files:** `src/library/views/SettingsPageView.js` (new), `src/library/library.js`

Follow the Ranobe Gemini pattern exactly:
- Sticky left sidebar with icon + label nav items
- Main content area with `ls-panel` sections
- Each panel is a separate file under `src/library/settings-panels/`

**Sidebar tabs:**

| ID | Icon | Label |
|----|------|-------|
| `general` | 🎨 | General (Theme + Display) |
| `ai` | 🤖 | AI (Providers, Models, Keys, Prompts) |
| `git` | 🔗 | Git (Repos, Mirrors, Config Storage) |
| `platforms` | 🌐 | Platforms (LeetCode, GFG, Codeforces) |
| `backups` | 💾 | Backups (Local rolling, GitHub periodic) |
| `advanced` | ⚙️ | Advanced (Telemetry, Debug, Behaviour Bank, Reset) |

- [ ] Create `SettingsPageView.js`: renders sidebar + active panel; active panel stored in URL hash (`#settings-ai` etc.) so browser back/forward works
- [ ] Update `library.js` to render `SettingsPageView` instead of `SettingsView` for the settings tab
- [ ] Keep `SettingsSchema.js` alive for the popup (popup uses a subset of settings rendered in-place)

---

### Task 4.2 — Panel: General (Theme)

**Files:** `src/library/settings-panels/PanelGeneral.js`

Port the Ranobe Gemini General/Theme panel structure:

- [ ] **Mode pills**: Dark / Light / Auto (toggle buttons)
- [ ] **Auto-behavior panel** (shown when Auto selected):
  - Radio: Follow OS / Sunrise-Sunset (timezone-estimated, no geolocation) / Custom Schedule
  - Custom schedule: two `<input type="time">` fields (Light from / Dark from)
- [ ] **Preset skin dropdown**: populated from `theme-engine.js` `getPresetList()`; grouped by `meta.group` (`default` / `skin` / `creative` / `custom`)
- [ ] **Live preview strip**: 4 colour swatches (bg, surface, accent, text)
- [ ] **Color pickers**: Accent, Background, Text — sync `<input type=color>` + hex text input
- [ ] **Advanced overrides** (`<details>`): Accent Secondary/Hover, Background Surface, Background Card — each with reset-to-auto button
- [ ] **Save as custom preset**: name input + Save button; saved to `themeSettings.customPresets`
- [ ] **Delete custom preset**: visible only when a custom preset is selected
- [ ] **Font size slider**: 80–150%, affects `document.documentElement.style.fontSize`
- [ ] Save button calls `Storage.setTheme(theme)` which triggers `setupThemeListener` to auto-apply everywhere

---

### Task 4.3 — Panel: AI

**Files:** `src/library/settings-panels/PanelAI.js`

Replace the current scattered AI settings with coherent sections:

**Section: Primary Provider**
- Provider select (Gemini / OpenAI / Claude / DeepSeek / Ollama / OpenRouter)
- Model select (fetched live, or static for Ollama)
- API key(s) with rotation strategy (Off / Round Robin / Random) — multi-key support like Ranobe
- Test key button
- Temperature slider (0.0–2.0)
- Max tokens (for providers that support it)

**Section: Fallback Provider**
- Same fields as primary but for fallback
- Enable/disable toggle
- "Used when primary fails or rate-limits"

**Section: Model Status (read-only display)**
- Current active model (updated live from last AI call)
- Last error if any
- "Test connection" button

**Section: Prompt Templates**
- Per-platform prompt textareas (LeetCode / GFG / Codeforces) with Reset to Default buttons
- AI review prompt template

- [ ] Implement all sections listed above
- [ ] Ensure `ModelSelector.js` component is reused where possible
- [ ] Key rotation strategy stored at `settings.aiKeyRotation`
- [ ] Fallback settings at `settings.aiSecondary`, `settings.aiSecondaryModel`, `settings.aiSecondaryKey`

---

### Task 4.4 — Panel: Git (mirrors fix + GitHub config storage)

**Files:** `src/library/settings-panels/PanelGit.js`, `src/handlers/git/github/index.js`, `src/ui/components/MirrorsPanel.js`

**Current problem with mirrors:** The existing `MirrorsPanel.js` treats mirrors as equal peers and tries to commit to them directly. The correct model is:

- **Primary repo** (GitHub): all writes go here via the Git Tree API
- **Push mirrors** (GitLab / Bitbucket): after each GitHub commit succeeds, replicate using a simple `git push --mirror` equivalent via each provider's REST API or via a `git` subprocess in the extension's service worker (not viable for MV3) — **correct approach for MV3: after GitHub commit, use each mirror's Contents/Commits API to create an equivalent commit using the same code + metadata**

Because full tree mirroring via API is complex and slow, the practical approach for an extension is:
- Store the raw file contents of each commit
- For each enabled mirror, create the same file at the same path using that provider's API
- This means mirrors see individual file pushes, not a full git history mirror
- Label this honestly in the UI: "Content mirrors (file sync, not git history)"

**Section: GitHub Connection**
- OAuth status badge (Connected / Disconnected)
- Repository name + owner (auto-filled after OAuth)
- Problems directory (default: `topics/`)
- Main branch (default: `main`)
- Commit message template with tokens: `{platform}`, `{title}`, `{difficulty}`, `{lang}`, `{date}`

**Section: GitHub Config Storage**
- Toggle: "Store settings and config in GitHub" (default: on for users who have repo)
- Stored files: `config/settings.json`, `config/theme.json`, `config/prompts.json`, `config/behavior-bank.json`
- "Push config now" button
- "Pull config from GitHub" button (merge, not replace)
- Note: `config/` dir is separate from `topics/` — never mixed with code commits

**Section: Push Mirrors**
- Add mirror button: opens sub-form with Provider (GitLab / Bitbucket), Token, Repo slug
- Each mirror listed with: status badge, enable/disable toggle, delete button
- Mirror fires after each successful GitHub commit (async, non-blocking — failure does not block the primary commit)

- [ ] Replace `MirrorsPanel.js` with new implementation matching the above spec
- [ ] Add `pushMirrors(files)` in `github/index.js` that calls `gitlab/index.js` and `bitbucket/index.js` `commitFiles()` helpers
- [ ] `settings.git_mirrors = [{provider, token, repo, enabled}]`
- [ ] Add `storeConfigFiles(settings, theme, prompts)` in `github/index.js` — commits `config/*.json` with message `"config: update CodeLedger configuration"`

---

### Task 4.5 — Panel: Platforms

**Files:** `src/library/settings-panels/PanelPlatforms.js`

Per-platform toggles currently buried in the schema-driven view:

- [ ] **LeetCode section**: auto-commit toggle, detect submissions via GraphQL toggle, detect via DOM toggle, fallback selectors enable/disable, extended detection timeout (ms)
- [ ] **GeeksForGeeks section**: auto-commit toggle, profile URL (for import)
- [ ] **Codeforces section**: auto-commit toggle
- [ ] **Difficulty map** (existing `DifficultyMapPanel.js`): embed here instead of in the AI tab
- [ ] **Import profile** buttons: LeetCode (existing flow), GFG (existing flow)

---

### Task 4.6 — Panel: Backups

**Files:** `src/library/settings-panels/PanelBackups.js`, `src/background/alarm-manager.js`, `src/background/service-worker.js`

**Section: Local Backup**
- Export full backup (problems + settings + theme) as JSON download
- Import from JSON file (merge or replace)
- Auto rolling backups: toggle + frequency slider (every N hours, default 24)
- Rolling backup list: last 5, each with timestamp + restore button + delete button
- Max 5 rolling backups kept in `chrome.storage.local` under `SK.ROLLING_BACKUPS`

**Section: GitHub Periodic Backup**
- Toggle: "Periodic GitHub backup"
- Frequency: daily / weekly / on every solve
- Stores `config/backup-{date}.json` in GitHub under `config/backups/` (keeps last 7)
- Last backup timestamp display

- [ ] `Storage.addRollingBackup(payload)` — enforce max-5 with FIFO eviction
- [ ] `alarm-manager.js`: register `local-rolling-backup` alarm (default 24h)
- [ ] SW: handle `local-rolling-backup` alarm → call `addRollingBackup`
- [ ] SW: handle `github-periodic-backup` alarm → call `storeConfigFiles` + backup payload

---

### Task 4.7 — Panel: Advanced

**Files:** `src/library/settings-panels/PanelAdvanced.js`

- [ ] Telemetry toggle (existing `telemetryOptIn` setting)
- [ ] Debug mode toggle + sub-options (existing)
- [ ] Copyable text setting (existing)
- [ ] AI behaviour bank section (opt-in toggle, sync now, clear data — from Task 3.3)
- [ ] **Maintenance section**: "Refresh missing metadata" (existing background refresh — fix the "message port closed" error: use a persistent SW keepalive during the refresh loop)
- [ ] **Danger zone**: Factory reset with confirmation

**Fix for "message port closed" error during metadata refresh:**
The background refresh sends messages to the SW which closes before all responses arrive. Fix: use `chrome.runtime.sendMessage` with a keepalive port held open during the refresh, or batch all refresh work inside a single SW message handler that processes sequentially without round-trips.

---

## Phase 5 — Theming System

**Goal:** CSS-variable–based theming covering all surfaces, using the Ranobe Gemini preset catalogue adapted for CodeLedger.

---

### Task 5.1 — Theme engine

**Files:** `src/core/theme-engine.js` (new), `src/core/constants.js`, `src/core/storage.js`

Port `env/Ranobe-gemini_v4.6.0_source/src/utils/theme-config.js` with these changes:
- Replace `browser.storage` → `Storage.getTheme()` / `Storage.setTheme()` (which uses `browser-compat.js`)
- Keep all 18 presets verbatim: Material Dark, Material Light, Ocean, Forest, Sunset, Nord, Dracula, Solarized, Cyberpunk, Rose Gold, Ayu Mirage, High Contrast, Sepia Reader, Tokyo Night, Catppuccin Mocha, Catppuccin Latte, Synthwave, Gruvbox, Nord Snow, GitHub
- Export: `DEFAULT_THEME`, `THEME_PRESETS`, `resolveMode`, `getThemePalette`, `setThemeVariables`, `applyThemeFromStorage`, `setupThemeListener`, `getPresetList`

**CodeLedger-specific CSS vars to add** (on top of Ranobe's palette):
```
--cl-accent         = primary-color
--cl-accent-hover   = primary-hover
--cl-bg             = bg-primary
--cl-surface        = bg-secondary
--cl-card           = bg-card
--cl-text           = text-primary
--cl-text-muted     = text-muted
--cl-border         = border-color
```

- [ ] Create `src/core/theme-engine.js` as described above
- [ ] Add `SK.THEME = "cl-themeSettings"` to `constants.js`
- [ ] Add `getTheme()`, `setTheme(theme)` to `storage.js`
- [ ] Add `DEFAULT_THEME` export: default preset = `"github-light"` in light mode (suits the current dark-slate aesthetic of the extension — or `"material-dark"` which matches current colours)

---

### Task 5.2 — Theme CSS variables file

**Files:** `src/ui/styles/theme-variables.css` (new)

This CSS file declares fallback values and is injected into extension pages via `<link>` and into content-script surfaces via `style` injection.

```css
:root {
  --cl-accent: #22d3ee;        /* cyan-400 — current CodeLedger default */
  --cl-accent-hover: #06b6d4;
  --cl-bg: #030712;
  --cl-surface: #0f172a;
  --cl-card: #1e293b;
  --cl-text: #e5e7eb;
  --cl-text-muted: #6b7280;
  --cl-border: #1e293b;
}
```

- [ ] Create the file with the fallback values above
- [ ] Reference in `library.html`, `popup.html` via `<link rel="stylesheet">`
- [ ] In `handler-loader.js`: inject `<style>` tag with `:root { --cl-* }` values into the host page (for floating-ai and timer) using current theme from storage

---

### Task 5.3 — Apply theme to all surfaces

**Surface coverage checklist:**

- [ ] **Library page** (`library.html`): call `applyThemeFromStorage()` in `library.js` before first render; `setupThemeListener()` for live updates
- [ ] **Popup** (`popup.html` / `popup.js`): call `applyThemeFromStorage()` on load
- [ ] **Floating AI panel** (`floating-ai.js`): read theme from storage on init; inject `--cl-*` vars into the shadow DOM or panel container `style` attribute; re-inject on storage change event
- [ ] **Floating timer** (`floating-timer.js`): replace hardcoded `#06b6d4` / cyan with `var(--cl-accent)`
- [ ] **Injected LeetCode buttons** (in `qol.js` / handler `init`): buttons use `background: var(--cl-accent)` and `color: var(--cl-bg)` instead of hardcoded colours
- [ ] **Problem modal** (rendered inside library page): inherits from library page vars — no extra work
- [ ] **Welcome page** (`welcome.js`): call `applyThemeFromStorage()`

**How theme propagates to content-script surfaces:**
1. `handler-loader.js` calls `Storage.getTheme()` after `handler.init()`
2. Calls `setThemeVariables(theme)` — but this targets `document.documentElement` of the host page (LeetCode etc.)
3. This is intentional: it only sets `--cl-*` vars scoped to the injected panel's container, not the full page root
4. Implementation: `panel.style.setProperty("--cl-accent", palette["primary-color"])` etc. for each `--cl-*` var on the panel's root element

- [ ] Update `floating-ai.js` to accept + apply `--cl-*` vars on the panel container
- [ ] Update `floating-timer.js` to accept + apply `--cl-*` vars on the timer element
- [ ] Update `qol.js` button styles to use `--cl-accent` / `--cl-bg` vars

---

### Task 5.4 — Storage-change propagation

For live theme switching without page reload:

- [ ] In `library.js`: `setupThemeListener()` listens to `chrome.storage.onChanged` for `SK.THEME`; calls `setThemeVariables(newValue)` — updates CSS vars in real time
- [ ] Same in `popup.js`
- [ ] For content-script surfaces: SW broadcasts a `THEME_CHANGED` message on storage change; `handler-loader.js` listens and re-injects vars into panel containers

---

## Implementation Notes

### Maintenance refresh "message port closed" fix (Task 4.7)

The refresh handler (`src/background/refresh-metadata-handler.js`) processes problems one at a time via `chrome.runtime.sendMessage` round-trips. The SW times out between messages. Fix: expose a single `REFRESH_ALL_METADATA` handler in the SW that runs the entire loop internally (no client round-trips), reports progress via `chrome.runtime.sendMessage` from SW → UI (not UI → SW).

### Git config storage structure

When `settings.storeConfigInGit` is enabled, the following files are committed to `config/`:

```
config/
├── settings.json         # all settings except API keys and tokens
├── theme.json            # full themeSettings object
├── prompts.json          # AI prompt templates per platform
├── behavior-bank.json    # (Phase 3) per-problem behaviour records
└── backups/
    ├── backup-2026-05-01.json
    └── backup-2026-05-06.json   # last 7 kept
```

API keys and OAuth tokens are **never** committed to GitHub.

### LangChain / LangGraph decision

**Not needed.** The current architecture (direct provider API calls from service worker, `buildAIChatContext` for prompt assembly, `expandChatVariables` for command injection) covers all planned features without an orchestration layer. LangGraph would only add value for multi-agent workflows with shared state, which is not in scope. The behaviour bank (Phase 3) is a simple JSON append, not a vector-search RAG system.

If vector-based problem search is added in a future phase, a lightweight IndexedDB + cosine similarity approach is preferred over pulling in LangChain's browser bundle (which is large and CSP-hostile in MV3).

---

## Verification Checklist

Before closing each phase, verify:

### Phase 1
- [ ] Heatmap shows problems in local timezone (test by changing system clock offset)
- [ ] `/mycode` in chat expands to actual code, not the literal string
- [ ] Mermaid fenced code block renders as a diagram (not raw text)
- [ ] `$O(n \log n)$` renders as styled math
- [ ] ModelStatusBar shows current provider and model name
- [ ] Problem Overview tab shows constraints + similar problems when cached

### Phase 2
- [ ] Floating AI shows "Wrong Answer" test case details after a failed submit
- [ ] Prompt mode tabs visible; switching modes changes the system instruction
- [ ] Attaching a stored problem appends its description to the AI context

### Phase 3
- [ ] Behaviour bank record created after first problem solve (with opt-in enabled)
- [ ] `config/behavior-bank.json` created in GitHub repo after sync
- [ ] Opt-out deletes local data and does not sync

### Phase 4
- [ ] Settings page has sidebar + 6 panels; URL hash navigation works
- [ ] Git mirrors: GitLab mirror receives same file as GitHub after a commit
- [ ] Rolling backups: after 6 saves, oldest is evicted (max 5)
- [ ] Config files pushed to `config/` in GitHub after "Push config now"

### Phase 5
- [ ] Switching to "Tokyo Night" preset changes colours in library, popup, AND floating AI panel
- [ ] Custom preset saved, appears in dropdown, survives page reload
- [ ] "Auto + Sunrise/Sunset" switches to light mode during daytime (using timezone estimation)
- [ ] Floating timer glow colour matches current accent
- [ ] Injected LeetCode buttons use theme accent colour

---

## Build & Deploy Notes

```bash
# After any CSS changes
npm run build:css

# Verify TypeScript (no transpile)
npm run lint

# Package for Chrome
node dev/package-chrome.js

# Package for Firefox
node dev/package-firefox.js
```

No new dependencies are required. All CDN libraries (mermaid, KaTeX) are loaded lazily at runtime and do not affect the extension bundle size.
