# GFG Alpha Label + Codeforces Full Platform Handler Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Label GFG as Alpha (activate its handler), implement Codeforces as a full Alpha-quality platform handler with submit-hook-based submission detection, copy button, floating AI panel, and README generation — matching GFG feature parity.

**Architecture:** Codeforces has no CORS-accessible API from content scripts and does not return source code in its API. Detection uses a MutationObserver on `span[submissionverdict="OK"]` (CF's DOM attribute) combined with a submit-button hook that saves code to sessionStorage at click time. Files are split into `lang-utils.js`, `submission-detector.js`, and `qol.js` mirroring the GFG module structure. Both platforms are labeled ALPHA in `constants.js` and the `PanelPlatforms.js` settings UI now renders status badges.

**Tech Stack:** Pure ES6 modules, no bundler. Preact + htm from CDN for settings panels. Browser extension Manifest V3, Chrome + Firefox. `browser-compat.js` only for all browser API calls.

---

## File Map

**Modified:**
- `src/core/constants.js` — GFG + CF status → ALPHA; add CF `apiBase` + `contestsBase`
- `src/library/settings-panels/PanelPlatforms.js` — render status badge in platform card header
- `src/content/handler-loader.js` — activate GFG and CF handlers (replace "under construction" stubs)
- `src/handlers/platforms/codeforces/dom-selectors.js` — full selector rewrite
- `src/handlers/platforms/codeforces/page-detector.js` — add MY_SUBMISSIONS + PROFILE; fix slug to include contestId
- `src/handlers/platforms/codeforces/index.js` — full handler (replaces 138-line stub)

**Created:**
- `src/handlers/platforms/codeforces/lang-utils.js` — CF language string → ext + rating → Easy/Medium/Hard
- `src/handlers/platforms/codeforces/submission-detector.js` — submit hook + MutationObserver verdict watcher
- `src/handlers/platforms/codeforces/qol.js` — copy button + AI trigger button

---

## Task A: Alpha status labels in constants.js + settings UI badge

**Files:**
- Modify: `src/core/constants.js`
- Modify: `src/library/settings-panels/PanelPlatforms.js`

- [ ] **Step 1: Update GFG and CF status in constants.js**

In `src/core/constants.js`, change both platform statuses from `UNDER_CONSTRUCTION` to `ALPHA`. Also add missing CF URL constants:

Find the `geeksforgeeks` platform block (around line 209) and change:
```js
status: FEATURE_STATUS.UNDER_CONSTRUCTION,
```
to:
```js
status: FEATURE_STATUS.ALPHA,
```

Find the `codeforces` platform block (around line 224) and change:
```js
status: FEATURE_STATUS.UNDER_CONSTRUCTION,
```
to:
```js
status: FEATURE_STATUS.ALPHA,
apiBase: "https://codeforces.com/api",
contestsBase: "https://codeforces.com/contest/",
```

- [ ] **Step 2: Add status badge rendering to PanelPlatforms.js**

In `src/library/settings-panels/PanelPlatforms.js`, the platform card header currently has:

```js
<!-- Header -->
<div class="flex items-center gap-3">
    <span
        class="w-2.5 h-2.5 rounded-full shrink-0"
        style=${"background:" + p.color}
    ></span>
    <span
        class="text-sm font-semibold text-slate-200 flex-1"
        >${p.name}</span
    >
    <button
        onClick=${() => togglePlatform(p.id)}
```

Replace that block with (adds status badge between name and toggle):

```js
<!-- Header -->
<div class="flex items-center gap-3">
    <span
        class="w-2.5 h-2.5 rounded-full shrink-0"
        style=${"background:" + p.color}
    ></span>
    <span
        class="text-sm font-semibold text-slate-200 flex-1"
        >${p.name}</span
    >
    ${p.status && p.status !== CONSTANTS.FEATURE_STATUS.STABLE && (() => {
        const meta = CONSTANTS.FEATURE_STATUS_META[p.status];
        return meta ? html`<span class="text-[10px] font-medium px-1.5 py-0.5 rounded border ${meta.className}">${meta.label}</span>` : null;
    })()}
    <button
        onClick=${() => togglePlatform(p.id)}
```

- [ ] **Step 3: Lint**

```powershell
cd "v:\Code\ProjectCode\CodeLedger" && npm run lint
```
Expected: no errors.

- [ ] **Step 4: Commit**

```powershell
git add src/core/constants.js src/library/settings-panels/PanelPlatforms.js
git commit -m "feat(platforms): label GFG + CF as Alpha, show status badge in settings"
```

---

## Task B: Activate GFG handler in handler-loader.js

**Files:**
- Modify: `src/content/handler-loader.js`

- [ ] **Step 1: Replace GFG stub with real handler load**

In `src/content/handler-loader.js`, find and replace the GFG branch:

Old:
```js
} else if (isHost("geeksforgeeks.org", hostname)) {
    console.log(
        `[CodeLedger:HandlerLoader] loadHandler(): GeeksForGeeks handler is under construction — detection only, no submission capture`
    );
```

New:
```js
} else if (isHost("geeksforgeeks.org", hostname)) {
    console.log(
        `[CodeLedger:HandlerLoader] loadHandler(): platform detected = GeeksForGeeks`
    );
    const url = chrome.runtime.getURL(
        "handlers/platforms/geeksforgeeks/index.js"
    );
    const { GFGHandler } = await import(url);
    const handler = new GFGHandler();
    console.log(
        `[CodeLedger:HandlerLoader] loadHandler(): initializing GFGHandler...`
    );
    await handler.init();
    console.log(
        `[CodeLedger:HandlerLoader] loadHandler(): ✓ GFGHandler initialized`
    );
```

- [ ] **Step 2: Lint**

```powershell
npm run lint
```
Expected: no errors.

- [ ] **Step 3: Commit**

```powershell
git add src/content/handler-loader.js
git commit -m "feat(gfg): activate GFG handler — Alpha release"
```

---

## Task C: Codeforces dom-selectors.js + page-detector.js

**Files:**
- Modify: `src/handlers/platforms/codeforces/dom-selectors.js`
- Modify: `src/handlers/platforms/codeforces/page-detector.js`

- [ ] **Step 1: Rewrite dom-selectors.js**

Replace the entire content of `src/handlers/platforms/codeforces/dom-selectors.js`:

```js
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Codeforces DOM selectors — verified against current CF HTML (2026-05-21).
 *
 * CF uses server-rendered HTML with stable class names (not hashed).
 * Submission verdict is detected via the `submissionverdict` attribute on <span>.
 */

export const SELECTORS = {
    version: "2026-05-21",

    page: {
        isProblemPage: ".problem-statement",
    },

    problem: {
        title: ".problem-statement .header .title",
        description: ".problem-statement",
        timeLimit: ".problem-statement .header .time-limit",
        memoryLimit: ".problem-statement .header .memory-limit",
        tags: ".roundbox .tag-box, .problemTags .tag-box",
    },

    submission: {
        acceptedVerdict: 'span[submissionverdict="OK"]',
        submissionRow: "tr[data-submission-id]",
        verdictCell: ".status-verdict-cell",
        code: "#program-source-text",
        editor: "#editor",
        submitButton: [
            "#singlePageSubmitButton",
            '.submit-form button[type="submit"]',
            'form.submit-form input[type="submit"]',
            ".submitButton",
        ].join(", "),
        languageSelector: '#programTypeForTesting, select[name="programTypeId"]',
    },

    qol: {
        editorContainer: "#editor",
    },

    profile: {
        handle: ".main-info .user-name",
    },
};

export const DOMAINS = ["codeforces.com"];
```

- [ ] **Step 2: Rewrite page-detector.js**

Replace the entire content of `src/handlers/platforms/codeforces/page-detector.js`:

```js
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Codeforces page detection.
 *
 * Problem slug format: "${contestId}${letter}" (e.g. "1234A", "gym5678B").
 * This matches CONSTANTS.makeProblemId("codeforces", slug) → "cf-1234A".
 */

import { createDebugger } from "../../../lib/debug.js";

const dbg = createDebugger("CodeforcesPageDetector");

export const PAGE_TYPES = {
    PROBLEM: "problem",
    SUBMISSION: "submission",
    MY_SUBMISSIONS: "mysubmissions",
    PROFILE: "profile",
    UNKNOWN: "unknown",
};

export function detectPage(pathname) {
    // /contest/{id}/problem/{letter}  — must check before /contest/{id}/my
    const contestProblem = pathname.match(
        /\/contest\/(\d+)\/problem\/([A-Za-z0-9]+)/
    );
    if (contestProblem) {
        const [, contestId, letter] = contestProblem;
        dbg.log(`Contest problem: contestId=${contestId} letter=${letter}`);
        return {
            type: PAGE_TYPES.PROBLEM,
            contestId,
            letter,
            slug: `${contestId}${letter}`,
        };
    }

    // /gym/{id}/problem/{letter}
    const gym = pathname.match(/\/gym\/(\d+)\/problem\/([A-Za-z0-9]+)/);
    if (gym) {
        const [, contestId, letter] = gym;
        dbg.log(`Gym problem: contestId=${contestId} letter=${letter}`);
        return {
            type: PAGE_TYPES.PROBLEM,
            contestId,
            letter,
            slug: `gym${contestId}${letter}`,
        };
    }

    // /problemset/problem/{contestId}/{letter}
    const problemset = pathname.match(
        /\/problemset\/problem\/(\d+)\/([A-Za-z0-9]+)/
    );
    if (problemset) {
        const [, contestId, letter] = problemset;
        dbg.log(`Problemset problem: contestId=${contestId} letter=${letter}`);
        return {
            type: PAGE_TYPES.PROBLEM,
            contestId,
            letter,
            slug: `${contestId}${letter}`,
        };
    }

    // /contest/{id}/submission/{submissionId}
    const submission = pathname.match(/\/contest\/(\d+)\/submission\/(\d+)/);
    if (submission) {
        return {
            type: PAGE_TYPES.SUBMISSION,
            contestId: submission[1],
            submissionId: submission[2],
        };
    }

    // /contest/{id}/my  or  /contest/{id}/my/page/{n}
    const my = pathname.match(/\/contest\/(\d+)\/my/);
    if (my) {
        return { type: PAGE_TYPES.MY_SUBMISSIONS, contestId: my[1] };
    }

    // /profile/{handle}
    const profile = pathname.match(/\/profile\/([^/]+)/);
    if (profile) {
        return { type: PAGE_TYPES.PROFILE, handle: profile[1] };
    }

    return { type: PAGE_TYPES.UNKNOWN };
}

export function isSolveCapablePage(pathname) {
    const t = detectPage(pathname).type;
    return t === PAGE_TYPES.PROBLEM || t === PAGE_TYPES.MY_SUBMISSIONS;
}
```

- [ ] **Step 3: Lint**

```powershell
npm run lint
```
Expected: no errors.

- [ ] **Step 4: Commit**

```powershell
git add src/handlers/platforms/codeforces/dom-selectors.js src/handlers/platforms/codeforces/page-detector.js
git commit -m "feat(codeforces): update dom-selectors + page-detector (contestId slug, MY_SUBMISSIONS)"
```

---

## Task D: Codeforces lang-utils.js

**Files:**
- Create: `src/handlers/platforms/codeforces/lang-utils.js`

- [ ] **Step 1: Create lang-utils.js**

Create `src/handlers/platforms/codeforces/lang-utils.js` with the full content:

```js
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Codeforces language utilities.
 *
 * CF API returns verbose language strings like "GNU G++17 7.3.0" or "Python 3.12.2".
 * We match by prefix rather than exact string so future compiler version bumps
 * (e.g. "GNU G++23 14.2") are handled automatically.
 *
 * Rating normalisation: CF uses 800–3500 numeric ratings, not Easy/Medium/Hard.
 * Community standard: ≤1200 Easy, 1201–1900 Medium, ≥1901 Hard.
 */

export function resolveLang(rawLang) {
    if (!rawLang) return { name: "unknown", ext: "txt", slug: "txt" };

    const l = rawLang.toLowerCase();
    let ext = "txt";

    if (/\bc\b/.test(l) && !/c\+\+|c#|csharp|cpp/.test(l)) ext = "c";
    else if (/c\+\+|cpp|g\+\+|clang\+\+|msvc/.test(l)) ext = "cpp";
    else if (/c#|csharp/.test(l)) ext = "cs";
    else if (/\bjava\b/.test(l) && !/javascript/.test(l)) ext = "java";
    else if (/kotlin/.test(l)) ext = "kt";
    else if (/scala/.test(l)) ext = "scala";
    else if (/python|pypy/.test(l)) ext = "py";
    else if (/javascript|node\.js|node js/.test(l)) ext = "js";
    else if (/typescript/.test(l)) ext = "ts";
    else if (/\bgo\b/.test(l)) ext = "go";
    else if (/rust/.test(l)) ext = "rs";
    else if (/ruby/.test(l)) ext = "rb";
    else if (/haskell/.test(l)) ext = "hs";
    else if (/ocaml/.test(l)) ext = "ml";
    else if (/\bf#/.test(l)) ext = "fs";
    else if (/pascal|delphi/.test(l)) ext = "pas";
    else if (/php/.test(l)) ext = "php";
    else if (/perl/.test(l)) ext = "pl";
    else if (/\bd\b/.test(l) && !/node/.test(l)) ext = "d";

    return { name: rawLang, ext, slug: ext };
}

/**
 * Convert a numeric CF rating to Easy / Medium / Hard.
 * Returns "Unknown" for unrated problems.
 */
export function normalizeCFRating(rating) {
    if (rating === null || rating === undefined || isNaN(+rating)) return "Unknown";
    const r = +rating;
    if (r <= 1200) return "Easy";
    if (r <= 1900) return "Medium";
    return "Hard";
}
```

- [ ] **Step 2: Lint**

```powershell
npm run lint
```
Expected: no errors.

- [ ] **Step 3: Commit**

```powershell
git add src/handlers/platforms/codeforces/lang-utils.js
git commit -m "feat(codeforces): add lang-utils (language → ext, rating → difficulty)"
```

---

## Task E: Codeforces submission-detector.js

**Files:**
- Create: `src/handlers/platforms/codeforces/submission-detector.js`

- [ ] **Step 1: Create submission-detector.js**

Create `src/handlers/platforms/codeforces/submission-detector.js`:

```js
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Codeforces submission detection.
 *
 * Architecture:
 *   1. hookSubmitButton() intercepts the submit click and saves code + metadata
 *      to sessionStorage BEFORE the page navigates away.
 *   2. watchForVerdict() sets up a MutationObserver watching for
 *      span[submissionverdict="OK"] in the DOM — this fires whether the user is
 *      on the problem page (inline submissions table) or the /my page
 *      (after a full navigation from a contest problem page).
 *   3. readPendingSubmission() / clearPendingSubmission() manage sessionStorage.
 *
 * Why sessionStorage?
 *   CF does full page reloads between problem page and /my page. sessionStorage
 *   persists across same-origin navigations in the same tab, so code captured on
 *   the problem page is available on the /my page content-script instance.
 */

import { createDebugger } from "../../../lib/debug.js";

const dbg = createDebugger("CFSubmissionDetector");

const KEYS = {
    SLUG: "cl_cf_pending_slug",
    CODE: "cl_cf_pending_code",
    LANG: "cl_cf_pending_lang",
    TS:   "cl_cf_pending_ts",
};

const SUBMIT_SELECTORS = [
    "#singlePageSubmitButton",
    '.submit-form button[type="submit"]',
    'form.submit-form input[type="submit"]',
    ".submitButton",
];

/**
 * Hook the submit button so we capture code + language at click time.
 * Returns a cleanup function that removes the listener.
 */
export function hookSubmitButton(page) {
    if (page.type !== "problem") return () => {};

    const savePending = () => {
        const code = document.querySelector("#editor")?.value || "";
        const langSel = document.querySelector(
            '#programTypeForTesting, select[name="programTypeId"]'
        );
        const opt = langSel?.options?.[langSel.selectedIndex];
        const lang = ((opt?.textContent || opt?.value || "").trim()) || "C++";

        dbg.log("Submit fired — saving pending code", { slug: page.slug, lang });
        sessionStorage.setItem(KEYS.SLUG, page.slug || "");
        sessionStorage.setItem(KEYS.CODE, code);
        sessionStorage.setItem(KEYS.LANG, lang);
        sessionStorage.setItem(KEYS.TS, String(Date.now()));
    };

    const tryHook = () => {
        for (const sel of SUBMIT_SELECTORS) {
            const btn = document.querySelector(sel);
            if (btn && !btn._clHooked) {
                btn.addEventListener("click", savePending, true);
                btn._clHooked = true;
                dbg.log("Submit button hooked via", sel);
                return btn;
            }
        }
        return null;
    };

    const btn = tryHook();
    if (btn) {
        return () => btn.removeEventListener("click", savePending, true);
    }

    // Button not yet in DOM — wait for it
    const obs = new MutationObserver(() => {
        const found = tryHook();
        if (found) obs.disconnect();
    });
    obs.observe(document.body, { childList: true, subtree: true });
    return () => obs.disconnect();
}

/**
 * Watch for span[submissionverdict="OK"] appearing anywhere in the DOM.
 * Calls onAccepted(submissionId, contestId) when a new accepted verdict is found.
 * Returns the MutationObserver (call .disconnect() to stop).
 */
export function watchForVerdict(onAccepted) {
    const processedIds = new Set();

    const check = () => {
        const okSpans = document.querySelectorAll('span[submissionverdict="OK"]');
        for (const span of okSpans) {
            const row = span.closest("tr[data-submission-id]");
            const submissionId = row?.getAttribute("data-submission-id");
            if (!submissionId || processedIds.has(submissionId)) continue;

            const contestIdMatch = window.location.pathname.match(/\/contest\/(\d+)\//);
            const contestId = contestIdMatch?.[1] || null;

            dbg.log("Accepted verdict detected", { submissionId, contestId });
            processedIds.add(submissionId);
            onAccepted(submissionId, contestId);
        }
    };

    // Check immediately in case page already has results (e.g. /my page loaded with OK verdict)
    setTimeout(check, 600);

    const obs = new MutationObserver(check);
    obs.observe(document.body, { childList: true, subtree: true });
    return obs;
}

export function readPendingSubmission() {
    const slug = sessionStorage.getItem(KEYS.SLUG);
    const code = sessionStorage.getItem(KEYS.CODE);
    const lang = sessionStorage.getItem(KEYS.LANG);
    const ts   = sessionStorage.getItem(KEYS.TS);
    if (!slug && !code) return null;
    return { slug, code, lang, ts: ts ? +ts : Date.now() };
}

export function clearPendingSubmission() {
    Object.values(KEYS).forEach((k) => sessionStorage.removeItem(k));
}
```

- [ ] **Step 2: Lint**

```powershell
npm run lint
```
Expected: no errors.

- [ ] **Step 3: Commit**

```powershell
git add src/handlers/platforms/codeforces/submission-detector.js
git commit -m "feat(codeforces): add submission-detector (submit hook + MutationObserver verdict watcher)"
```

---

## Task F: Codeforces qol.js

**Files:**
- Create: `src/handlers/platforms/codeforces/qol.js`

- [ ] **Step 1: Create qol.js**

Create `src/handlers/platforms/codeforces/qol.js`:

```js
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Codeforces Quality-of-Life buttons: copy code + AI panel toggle.
 * Injected above the #editor textarea on problem pages.
 */

import { createDebugger } from "../../../lib/debug.js";

const dbg = createDebugger("CFQoL");

const MAX_ATTEMPTS = 16;
const RETRY_MS = 500;

let _retryTimer = null;

export async function injectCFQoL({ showCopy, showAI, onAIClick } = {}) {
    if (!showCopy && !showAI) return;

    if (_retryTimer) { clearTimeout(_retryTimer); _retryTimer = null; }

    for (let i = 0; i < MAX_ATTEMPTS; i++) {
        if (document.getElementById("cl-cf-qol")) return;

        const editor = document.querySelector("#editor");
        if (editor?.parentElement) {
            _inject(editor.parentElement, editor, { showCopy, showAI, onAIClick });
            return;
        }
        await new Promise((r) => setTimeout(r, RETRY_MS));
    }
    dbg.warn("Could not find #editor to inject QoL buttons");
}

export function removeCFQoL() {
    document.getElementById("cl-cf-qol")?.remove();
}

function _inject(parent, editor, { showCopy, showAI, onAIClick }) {
    if (document.getElementById("cl-cf-qol")) return;

    const container = document.createElement("div");
    container.id = "cl-cf-qol";
    container.style.cssText =
        "display:flex;gap:6px;padding:4px 0;margin-bottom:6px;flex-wrap:wrap;";

    if (showCopy) {
        container.appendChild(
            _makeBtn("cl-cf-copy", "Copy Code", async (btn) => {
                const code = document.querySelector("#editor")?.value || "";
                try {
                    await navigator.clipboard.writeText(code);
                    const orig = btn.textContent;
                    btn.textContent = "✓ Copied";
                    setTimeout(() => { if (btn.isConnected) btn.textContent = orig; }, 2000);
                } catch (_) {
                    dbg.warn("Clipboard write failed");
                }
            })
        );
    }

    if (showAI && onAIClick) {
        container.appendChild(_makeBtn("cl-cf-ai", "AI Review", () => onAIClick()));
    }

    parent.insertBefore(container, editor);
    dbg.log("CF QoL buttons injected");
}

function _makeBtn(id, label, onClick) {
    const btn = document.createElement("button");
    btn.id = id;
    btn.type = "button";
    btn.textContent = label;
    btn.style.cssText =
        "padding:4px 10px;border-radius:6px;font-size:12px;font-weight:500;" +
        "font-family:inherit;cursor:pointer;border:1px solid rgba(6,182,212,0.35);" +
        "color:#67e8f9;background:rgba(6,182,212,0.08);transition:background 0.2s;" +
        "white-space:nowrap;";
    btn.onmouseenter = () => { btn.style.background = "rgba(6,182,212,0.18)"; };
    btn.onmouseleave = () => { btn.style.background = "rgba(6,182,212,0.08)"; };
    btn.addEventListener("click", () => onClick(btn));
    return btn;
}
```

- [ ] **Step 2: Lint**

```powershell
npm run lint
```
Expected: no errors.

- [ ] **Step 3: Commit**

```powershell
git add src/handlers/platforms/codeforces/qol.js
git commit -m "feat(codeforces): add qol.js (copy button + AI panel trigger)"
```

---

## Task G: Codeforces index.js — full handler

**Files:**
- Modify: `src/handlers/platforms/codeforces/index.js` (replace 138-line stub)

- [ ] **Step 1: Replace index.js with full handler**

Replace the entire content of `src/handlers/platforms/codeforces/index.js`:

```js
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Codeforces platform handler — Alpha.
 *
 * Detection flow:
 *   1. On PROBLEM pages: hookSubmitButton() saves code + slug to sessionStorage.
 *   2. watchForVerdict() observes span[submissionverdict="OK"] on any CF page.
 *   3. On accepted verdict: read saved code, extract metadata from DOM, emit solve.
 *
 * Limitations (Alpha):
 *   - Profile bulk import not yet implemented (CF API is CORS-blocked from content
 *     scripts; would require SW-side API polling with a user-provided handle).
 *   - Gym contest submissions are detected and committed but the problem URL in
 *     the README points to the gym contest, not a permanent problemset URL.
 */

import { BasePlatformHandler } from "../../_base/BasePlatformHandler.js";
import { SELECTORS } from "./dom-selectors.js";
import { detectPage, PAGE_TYPES } from "./page-detector.js";
import { registerPlatformPrompt } from "../../../core/ai-prompts.js";
import { Storage } from "../../../core/storage.js";
import { createDebugger } from "../../../lib/debug.js";
import { runtime } from "../../../lib/browser-compat.js";
import { resolvePrimaryTopic } from "../../../core/topic-resolver.js";
import { solutionPath, readmePath } from "../../../core/path-builder.js";
import { resolveLang, normalizeCFRating } from "./lang-utils.js";
import {
    hookSubmitButton,
    watchForVerdict,
    readPendingSubmission,
    clearPendingSubmission,
} from "./submission-detector.js";
import { injectCFQoL } from "./qol.js";
import { createFloatingAI } from "../../../ui/floating-ai.js";

const dbg = createDebugger("CFHandler");

export class CodeforcesHandler extends BasePlatformHandler {
    constructor() {
        super("codeforces", "Codeforces", {});
        this._enableKey = "cf_enable";
        this._processingLock = false;
        this._cleanupSubmitHook = null;
        this._verdictObserver = null;
        this.lastDetectedId = null;
        this._aiPanel = null;
        this._aiPanelSlug = null;
        registerPlatformPrompt("codeforces", this.getDefaultPrompt());
    }

    getDefaultPrompt() {
        return `Review this {language} competitive programming solution for '{title}'.

Provide:
1. Time complexity (Big-O) and space complexity
2. Will it pass within typical CP constraints (10^8 ops/s)?
3. Potential TLE or MLE risks?
4. One optimisation if applicable

Be concise. Max 200 words.`;
    }

    getSettingsSchema() {
        return {
            id: this.id,
            title: "Codeforces",
            order: 30,
            fields: [
                {
                    key: "cf_enable",
                    label: "Enable tracking",
                    type: "toggle",
                    default: true,
                    description:
                        "Auto-detect accepted Codeforces submissions and save them to CodeLedger.",
                },
                {
                    key: "cf_readme",
                    label: "Include problem description",
                    type: "toggle",
                    default: true,
                    description:
                        "Save the problem statement to README.md alongside your solution.",
                },
                {
                    key: "cf_timer",
                    label: "Show solve timer",
                    type: "toggle",
                    default: true,
                    description:
                        "Display a floating stopwatch overlay while solving Codeforces problems.",
                },
                {
                    key: "cf_copy_btn",
                    label: "Copy code button",
                    type: "toggle",
                    default: true,
                    description:
                        "Inject a copy-to-clipboard button above the Codeforces editor.",
                },
                {
                    key: "cf_ai_panel",
                    label: "Floating AI assistant",
                    type: "toggle",
                    default: true,
                    description:
                        "Show a floating AI chat panel on Codeforces problem pages.",
                },
                {
                    key: "cf_handle",
                    label: "Codeforces handle",
                    type: "text",
                    default: "",
                    description:
                        "Your Codeforces username (handle). Used for future profile import support.",
                    advanced: true,
                    placeholder: "e.g. tourist",
                },
            ],
        };
    }

    async init() {
        dbg.log("CF handler active");
        const page = detectPage(window.location.pathname);

        if (page.type === PAGE_TYPES.PROBLEM) {
            Storage.getSettings()
                .then((s) => {
                    if (s.cf_timer !== false && s.floatingTimerEnabled !== false) {
                        this._timer.startFloating(page.slug || "cf");
                    }
                    const opts = {
                        showCopy: s.cf_copy_btn !== false,
                        showAI:
                            s.cf_ai_panel !== false &&
                            s.floatingAIEnabled !== false,
                        onAIClick: () => this._aiPanel?.expand(),
                    };
                    setTimeout(() => injectCFQoL(opts), 1500);
                    if (page.slug) this._startAIPanel(page.slug);
                })
                .catch(() => {});

            this._cleanupSubmitHook = hookSubmitButton(page);
        }

        // Watch for accepted verdict on ALL CF pages (problem page inline table
        // and /contest/{id}/my page after navigation)
        this._verdictObserver = watchForVerdict((submissionId, contestId) => {
            this._handleAcceptedVerdict(submissionId, contestId, page);
        });

        // On-demand metadata fetch (used by future profile import)
        try {
            const params = new URLSearchParams(window.location.search);
            if (params.get("codeledger_fetch") && page.type === PAGE_TYPES.PROBLEM) {
                await this._handleOnDemandFetch(page);
            }
        } catch (_) {}
    }

    /* ── Submission processing ──────────────────────────────────────────── */

    async _handleAcceptedVerdict(submissionId, contestId, page) {
        if (this._processingLock) return;

        const detectionId = `cf-${submissionId}`;
        if (detectionId === this.lastDetectedId) return;
        this.lastDetectedId = detectionId;

        this._processingLock = true;
        try {
            const settings = await Storage.getSettings();
            if (!this.isEnabled(settings)) {
                clearPendingSubmission();
                return;
            }

            const pending = readPendingSubmission();

            // Resolve slug: pending → current page → MY_SUBMISSIONS page (best effort)
            let slug = pending?.slug;
            if (!slug && page.type === PAGE_TYPES.PROBLEM) slug = page.slug;
            if (!slug) {
                dbg.warn("No slug for accepted verdict, skipping");
                return;
            }

            // Session-level dedup: skip if same submission already committed
            const dedupKey = `cl_committed_cf_${slug}`;
            if (sessionStorage.getItem(dedupKey) === submissionId) {
                dbg.log("Skipping already-committed submission", submissionId);
                clearPendingSubmission();
                return;
            }

            const rawLang = pending?.lang || this._extractLanguage();
            const lang = resolveLang(rawLang);
            const code =
                pending?.code ||
                document.querySelector(SELECTORS.submission.editor)?.value ||
                "";

            if (!code.trim()) {
                dbg.warn("Code extraction failed, skipping commit");
                return;
            }

            const meta = this._extractMetadata(slug, page);
            const topic = resolvePrimaryTopic(meta.tags || []);
            const canonical = await this.resolveCanonical(slug);

            sessionStorage.setItem(dedupKey, submissionId);
            clearPendingSubmission();

            const files = this._buildFileSet(meta, code, lang, settings, slug, canonical);
            const readmeFile = files.find((f) => f.path.endsWith("README.md"));
            const elapsedSeconds = this._timer.getElapsedSeconds();

            this.emitSolved({
                id: this.makeProblemId(slug),
                title: meta.title || slug,
                titleSlug: slug,
                difficulty: meta.difficulty || null,
                topic,
                tags: meta.tags || [],
                canonical: canonical
                    ? { id: canonical.canonicalId, title: canonical.canonicalTitle }
                    : null,
                readmeContent: readmeFile?.content || null,
                code,
                files,
                lang: { name: lang.name, ext: lang.ext, slug: lang.slug },
                runtime: meta.runtime || null,
                memory: meta.memory || null,
                timestamp: pending?.ts || Date.now(),
                elapsedSeconds,
            });

            dbg.log("Solve emitted", { slug, lang: lang.name });
        } catch (err) {
            dbg.error("Failed to process CF submission", err);
        } finally {
            this._processingLock = false;
        }
    }

    /* ── DOM extractors ─────────────────────────────────────────────────── */

    _extractMetadata(slug, page) {
        const titleEl = document.querySelector(SELECTORS.problem.title);
        const rawTitle = (titleEl?.textContent || "").trim();
        // Strip "A. " prefix that CF prepends to problem titles
        const title = rawTitle.replace(/^[A-Za-z0-9]+\.\s+/, "").trim() || rawTitle || slug;

        const rating = this._extractRating();
        const difficulty = rating ? normalizeCFRating(rating) : null;
        const tags = this._extractTags(rating);
        const description = document.querySelector(SELECTORS.problem.description)?.innerHTML || null;

        // Runtime/memory from the first submission row (if inline table visible)
        const firstRow = document.querySelector("tr[data-submission-id]");
        const cells = firstRow ? [...firstRow.querySelectorAll("td")] : [];
        const runtime = cells[4] ? (cells[4].textContent || "").trim() || null : null;
        const memory  = cells[5] ? (cells[5].textContent || "").trim() || null : null;

        return {
            title,
            difficulty,
            rating,
            tags,
            description,
            runtime,
            memory,
            contestId: page?.contestId || null,
            letter: page?.letter || null,
        };
    }

    _extractRating() {
        const els = [...document.querySelectorAll(".tag-box")];
        for (const el of els) {
            const title = el.getAttribute("title") || "";
            if (/Difficulty/i.test(title)) {
                const m = title.match(/(\d{3,4})/);
                if (m) return +m[1];
            }
            const text = (el.textContent || "").trim();
            if (/^\d{3,4}$/.test(text)) return +text;
        }
        return null;
    }

    _extractTags(ratingToExclude = null) {
        const tags = [];
        document.querySelectorAll(".roundbox .tag-box, .problemTags .tag-box").forEach((el) => {
            const t = (el.textContent || "").trim();
            if (!t) return;
            if (ratingToExclude !== null && t === String(ratingToExclude)) return;
            if (/^\d+$/.test(t)) return; // skip pure-numeric ratings
            if (!tags.includes(t)) tags.push(t);
        });
        return tags;
    }

    _extractLanguage() {
        const sel = document.querySelector(SELECTORS.submission.languageSelector);
        const opt = sel?.options?.[sel.selectedIndex];
        return ((opt?.textContent || opt?.value || "").trim()) || "C++";
    }

    /* ── File set builder ───────────────────────────────────────────────── */

    _buildFileSet(meta, code, lang, settings, slug, canonical) {
        const langObj = {
            verbose: lang.name.replace(/[^a-zA-Z0-9]/g, "_"),
            name: lang.name,
            ext: lang.ext,
        };
        const problemId = this.makeProblemId(slug);
        const files = [];

        files.push({
            path: solutionPath(problemId, "codeforces", langObj, canonical, settings),
            content: code,
        });

        if (settings.cf_readme !== false) {
            files.push({
                path: readmePath(problemId, canonical, settings, "codeforces"),
                content: this._buildReadme(meta, lang, slug),
            });
        }

        return files;
    }

    _buildReadme(meta, lang, slug) {
        const ratingStr = meta.rating ? ` (Rating: ${meta.rating})` : "";
        const lines = [
            `# ${meta.title || slug}`,
            "",
            `**Platform:** Codeforces  |  **Difficulty:** ${meta.difficulty || "?"}${ratingStr}`,
        ];

        if (meta.contestId) {
            lines.push(
                `**Contest:** ${meta.contestId}  |  **Problem:** ${meta.letter || slug.replace(String(meta.contestId), "")}`
            );
        }

        if (meta.tags?.length) {
            lines.push("", `**Tags:** ${meta.tags.map((t) => `\`${t}\``).join(", ")}`);
        }

        if (meta.description) {
            const plain = meta.description
                .replace(/<[^>]+>/g, "")
                .replace(/&lt;/g, "<")
                .replace(/&gt;/g, ">")
                .replace(/&amp;/g, "&")
                .replace(/\n{3,}/g, "\n\n")
                .trim()
                .slice(0, 5000);
            lines.push("", "## Problem", "", plain);
        }

        const stats = [];
        if (meta.runtime) stats.push(`Runtime: ${meta.runtime}`);
        if (meta.memory) stats.push(`Memory: ${meta.memory}`);
        if (stats.length) {
            lines.push("", "## My Submission", "", ...stats.map((s) => `- ${s}`));
        }

        const cId = meta.contestId || String(slug).match(/^(\d+)/)?.[1] || "";
        const letter = meta.letter || (cId ? slug.replace(cId, "") : slug);
        if (cId) {
            lines.push("", `**Source:** https://codeforces.com/contest/${cId}/problem/${letter}`);
        }

        return lines.join("\n");
    }

    /* ── AI panel ───────────────────────────────────────────────────────── */

    _startAIPanel(slug) {
        Storage.getSettings()
            .then((settings) => {
                if (settings.cf_ai_panel === false) return;
                if (settings.floatingAIEnabled === false) return;
                if (this._aiPanel && this._aiPanelSlug === slug) return;
                this._stopAIPanel();
                this._aiPanelSlug = slug;
                this._aiPanel = createFloatingAI(slug, {
                    position: { bottom: "20px", right: "20px" },
                    platform: {
                        id: "codeforces",
                        label: "CF AI Assistant",
                        chatPlatform: "codeforces",
                        readPageMeta: () => this._readPageMeta(),
                        readEditorCode: () =>
                            document.querySelector("#editor")?.value || "",
                        readEditorLang: () => this._extractLanguage(),
                        readProblemStatement: () => this._readProblemStatement(),
                        readTestFailures: () => "",
                    },
                });
            })
            .catch(() => {});
    }

    _stopAIPanel() {
        if (this._aiPanel) {
            this._aiPanel.destroy({ force: true });
            this._aiPanel = null;
            this._aiPanelSlug = null;
        }
    }

    _readPageMeta() {
        const titleEl = document.querySelector(SELECTORS.problem.title);
        const rawTitle = (titleEl?.textContent || "").trim();
        const title = rawTitle.replace(/^[A-Za-z0-9]+\.\s+/, "").trim() || rawTitle;
        const rating = this._extractRating();
        const difficulty = rating ? normalizeCFRating(rating) : "";
        return { title, difficulty: difficulty || String(rating || "") };
    }

    _readProblemStatement() {
        const el = document.querySelector(SELECTORS.problem.description);
        return el ? (el.textContent || "").trim().slice(0, 3000) : "";
    }

    /* ── On-demand metadata fetch ───────────────────────────────────────── */

    async _handleOnDemandFetch(page) {
        const params = new URLSearchParams(window.location.search);
        if (!params.get("codeledger_fetch")) return false;
        if (page.type !== PAGE_TYPES.PROBLEM) return false;

        const slug = page.slug;
        if (!slug) return false;

        const meta = this._extractMetadata(slug, page);
        const code = document.querySelector("#editor")?.value || "";
        const rawLang = this._extractLanguage();
        const lang = resolveLang(rawLang);

        const existing = await Storage.getProblem(this.makeProblemId(slug)).catch(() => null);
        await Storage.saveProblem({
            ...(existing || {}),
            platform: "codeforces",
            id: this.makeProblemId(slug),
            title: meta.title || existing?.title || slug,
            titleSlug: slug,
            difficulty: meta.difficulty || existing?.difficulty || null,
            tags: meta.tags?.length ? meta.tags : existing?.tags || [],
            code: code || existing?.code || "",
            lang: code
                ? { name: lang.name, ext: lang.ext, slug: lang.slug }
                : existing?.lang,
            problemStatement: meta.description || existing?.problemStatement || null,
            timestamp: existing?.timestamp || Date.now(),
        }).catch(() => {});

        await new Promise((resolve) => {
            try {
                runtime.sendMessage(
                    { type: "REFRESH_METADATA_DONE", platform: "codeforces", slug },
                    () => resolve()
                );
            } catch (_) {
                resolve();
            }
        });

        try {
            window.close();
        } catch (_) {}
        return true;
    }
}
```

- [ ] **Step 2: Lint**

```powershell
npm run lint
```
Expected: no errors.

- [ ] **Step 3: Commit**

```powershell
git add src/handlers/platforms/codeforces/index.js
git commit -m "feat(codeforces): full Alpha handler — submit hook, verdict detection, AI panel, README"
```

---

## Task H: Activate Codeforces handler in handler-loader.js

**Files:**
- Modify: `src/content/handler-loader.js`

- [ ] **Step 1: Replace CF stub with real handler load**

In `src/content/handler-loader.js`, find and replace the Codeforces branch:

Old:
```js
} else if (isHost("codeforces.com", hostname)) {
    console.log(
        `[CodeLedger:HandlerLoader] loadHandler(): Codeforces handler is under construction — detection only, no submission capture`
    );
```

New:
```js
} else if (isHost("codeforces.com", hostname)) {
    console.log(
        `[CodeLedger:HandlerLoader] loadHandler(): platform detected = Codeforces`
    );
    const url = chrome.runtime.getURL(
        "handlers/platforms/codeforces/index.js"
    );
    const { CodeforcesHandler } = await import(url);
    const handler = new CodeforcesHandler();
    console.log(
        `[CodeLedger:HandlerLoader] loadHandler(): initializing CodeforcesHandler...`
    );
    await handler.init();
    console.log(
        `[CodeLedger:HandlerLoader] loadHandler(): ✓ CodeforcesHandler initialized`
    );
```

- [ ] **Step 2: Lint**

```powershell
npm run lint
```
Expected: no errors.

- [ ] **Step 3: Commit**

```powershell
git add src/content/handler-loader.js
git commit -m "feat(codeforces): activate CodeforcesHandler — Alpha release"
```

---

## Task I: Version bump v1.5.0 + changelog

**Files:**
- Modify: `src/manifest.json`
- Modify: `package.json`
- Modify: `docs/CHANGELOG.md`

- [ ] **Step 1: Bump version in both files**

In `src/manifest.json`, change:
```json
"version": "1.4.0",
```
to:
```json
"version": "1.5.0",
```

In `package.json`, change:
```json
"version": "1.4.0",
```
to:
```json
"version": "1.5.0",
```

- [ ] **Step 2: Add changelog section at top of docs/CHANGELOG.md**

Insert the following block between the `---` separator and the `## [1.4.0]` heading:

```markdown
## [1.5.0] — 2026-05-21

### Added
- **GFG (Alpha):** GeeksForGeeks handler is now active — auto-detects accepted submissions, copy code button, floating AI assistant, floating solve timer, and bulk profile import.
- **Codeforces (Alpha):** Full Codeforces platform handler — submit-hook captures code at click time, MutationObserver detects `span[submissionverdict="OK"]` on problem and `/my` pages, floating AI assistant, copy code button, floating solve timer. Supports contest problems (`/contest/{id}/problem/{A}`), gym problems, and problemset problems.
- **Codeforces:** Language resolution for all current CF compiler strings (G++, PyPy, Kotlin, Rust, Go, etc.) via prefix matching — future compiler version bumps handled automatically.
- **Codeforces:** Rating-to-difficulty normalisation (≤1200 Easy, 1201–1900 Medium, ≥1901 Hard) with raw rating preserved in README.
- **Codeforces:** `cf_handle` advanced setting for future profile import support.
- **Settings UI:** Platform status badge (Alpha/Beta/Under Construction) now rendered in the Platforms settings panel next to each platform name.

### Changed
- GFG and Codeforces `FEATURE_STATUS` updated from `UNDER_CONSTRUCTION` to `ALPHA` in `constants.js`.
- Codeforces page detector now returns `slug: "${contestId}${letter}"` (e.g. "1234A") for consistent problem IDs (`cf-1234A`); previously only returned the letter.

---
```

- [ ] **Step 3: Lint**

```powershell
npm run lint
```
Expected: no errors.

- [ ] **Step 4: Commit and tag**

```powershell
git add src/manifest.json package.json docs/CHANGELOG.md
git commit -m "chore: bump version to 1.5.0, update changelog"
git tag v1.5.0
```

---

## Self-Review Checklist

**Spec coverage:**
- [x] GFG alpha label → Task A (constants.js) + badge in PanelPlatforms.js
- [x] GFG handler activation → Task B (handler-loader.js)
- [x] CF alpha label → Task A (constants.js)
- [x] CF dom-selectors → Task C
- [x] CF page-detector (contestId slug, MY_SUBMISSIONS, PROFILE) → Task C
- [x] CF language resolution → Task D
- [x] CF submit hook (save code at click time) → Task E
- [x] CF verdict detection (MutationObserver on submissionverdict="OK") → Task E
- [x] CF QoL buttons (copy, AI trigger) → Task F
- [x] CF full handler (AI panel, README, emitSolved, on-demand fetch) → Task G
- [x] CF handler activation in handler-loader.js → Task H
- [x] Version bump + changelog → Task I

**Placeholder scan:** No TBD, TODO, or incomplete steps. All code is shown in full.

**Type consistency:**
- `hookSubmitButton(page)` called in Task G with `page` object — matches Task E export signature ✓
- `watchForVerdict(onAccepted)` called with `(submissionId, contestId)` callback — matches Task E ✓
- `resolveLang(rawLang)` returns `{name, ext, slug}` — consumed as `lang.name`, `lang.ext`, `lang.slug` in Task G ✓
- `normalizeCFRating(rating)` takes a number — `_extractRating()` returns number or null ✓
- `injectCFQoL({showCopy, showAI, onAIClick})` — called with these exact keys in Task G ✓
- `solutionPath(problemId, "codeforces", langObj, canonical, settings)` — `langObj` has `{verbose, name, ext}` matching path-builder expectations ✓
