# Pre-Launch Checklist

Use this before any release or store submission.

## Code Quality

- [ ] `npm run lint` passes
- [ ] `npm run build` succeeds
- [ ] `npm run build:css` succeeds
- [ ] No console errors in the browser when the extension loads

## Core Extension Flow

- [ ] Platform detection works for LeetCode, GeeksForGeeks, and Codeforces
- [ ] Accepted problems are detected correctly
- [ ] Code, metadata, and problem files are committed correctly
- [ ] OAuth token storage stays in `auth.tokens`
- [ ] GitHub sync and import flows complete without conflicts
- [ ] AI review runs when enabled

## Documentation

- [ ] [../archive/changelog.md](../archive/changelog.md) has an entry for the release
- [ ] [../guides/release-versioning.md](../guides/release-versioning.md) is still accurate
- [ ] [../guides/RELEASE_GUIDE.md](../guides/RELEASE_GUIDE.md) is still accurate
- [ ] [../store/submission.md](../store/submission.md) covers store requirements
- [ ] [../../PRIVACY.md](../../PRIVACY.md) is current

## Release Readiness

- [ ] Version matches in [../../src/manifest.json](../../src/manifest.json) and [../../package.json](../../package.json)
- [ ] Working tree is clean before running the release
- [ ] `npm run release -- --dry-run` succeeds
- [ ] `npm run release` is ready to run

## Browser Coverage

- [ ] Chrome works
- [ ] Firefox works
- [ ] Edge is acceptable if supported for the current release
